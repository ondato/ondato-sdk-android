package com.ondato.sdk.api.registration

import com.ondato.sdk.api.BackendApi
import com.ondato.sdk.usecase.registration.RegistrationApi

internal class RegistrationService(
    private val api: BackendApi,
) : RegistrationApi {

    override suspend fun sendRegistration(
        identityVerificationId: String,
        registrationRequest: List<RegistrationRequest>,
    ) {
        api.sendRegistration(identityVerificationId, registrationRequest)
    }
}