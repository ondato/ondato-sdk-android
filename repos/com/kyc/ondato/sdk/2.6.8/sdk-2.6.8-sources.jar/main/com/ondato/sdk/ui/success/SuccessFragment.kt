package com.ondato.sdk.ui.success

import android.os.Bundle
import android.view.View
import com.ondato.sdk.R
import com.ondato.sdk.screen.SuccessScreenCallback
import com.ondato.sdk.ui.base.BaseFragment

internal class SuccessFragment : BaseFragment(R.layout.ondato_fragment_success) {
    private var callback: SuccessScreenCallback? = null

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        R.id.ondatoCloseButton.onClick { callback?.onCompleted() }
    }

    companion object {
        fun newInstance(callback: SuccessScreenCallback) = SuccessFragment().apply {
            this.callback = callback
        }
    }
}