package com.ondato.sdk.usecase.session.restart

import com.ondato.sdk.enums.Language
import com.ondato.sdk.usecase.session.Session
import com.ondato.sdk.usecase.session.configuration.Steps
import com.ondato.sdk.usecase.session.identification.RestartIdentificationApi
import com.ondato.sdk.usecase.session.token.Token

internal class RestartSessionUseCase(
    private val restartIdentificationApi: RestartIdentificationApi,
    private val session: Session,
) {

    suspend fun restart() {
        restartIdentificationApi.restartIdentification(session.kycId)

        session.restart()

//        val kycId = session.kycId
//        val token = session.token
//        val language = session.language
//        val termsAgreed = session.areTermsAgreed
//        val availableDocumentTypes = session.availableDocumentTypes
//        val shouldShowRegistrationScreen = session.shouldShowRegistrationScreen
//        val shouldShowProofOfAddressScreen = session.showProofOfAddressStep
//        val kycSteps = session.kycSteps
//
//        session.clear()
//
//        session.kycSteps = kycSteps
//        session.kycId = kycId
//        session.token = token
//        session.language = language
//        session.areTermsAgreed = termsAgreed
//        session.availableDocumentTypes = availableDocumentTypes
//        session.shouldShowRegistrationScreen = shouldShowRegistrationScreen
//        session.showProofOfAddressStep = shouldShowProofOfAddressScreen
    }
}