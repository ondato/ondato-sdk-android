package com.ondato.sdk.ui.splash

import android.os.Bundle
import android.view.View
import com.ondato.sdk.R
import com.ondato.sdk.ui.base.BaseFragment
import com.ondato.sdk.ui.main.MainViewModel
import com.ondato.sdk.ui.main.Step
import org.koin.androidx.viewmodel.ext.android.sharedViewModel
import org.koin.androidx.viewmodel.ext.android.viewModel

internal class SplashFragment : BaseFragment(R.layout.ondato_fragment_splash) {
    private val viewModel: SplashViewModel by viewModel()
    private val mainViewModel: MainViewModel by sharedViewModel()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (savedInstanceState == null) viewModel.init()
        viewModel.success.observe { mainViewModel.onStepSuccess(Step.INITIALIZE) }
        viewModel.showError.observe(::showError)
        mainViewModel.retry.observe { viewModel.init() }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel.isLoading.observeOnView { isLoading ->
            if (isLoading) R.id.progressBar.show() else R.id.progressBar.hide()
        }
    }

    companion object {
        fun newInstance(): SplashFragment = SplashFragment()
    }
}