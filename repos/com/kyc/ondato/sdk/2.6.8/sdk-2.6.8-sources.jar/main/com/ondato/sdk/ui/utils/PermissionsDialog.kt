package com.ondato.sdk.ui.utils

import android.content.Context
import androidx.appcompat.app.AlertDialog
import com.ondato.sdk.R

object PermissionsDialog {

    fun show(context: Context, openSettingsClicked: () -> Unit) {
        AlertDialog.Builder(context)
            .setTitle(R.string.FaceTec_camera_permission_header)
            .setPositiveButton(R.string.FaceTec_camera_permission_launch_settings) { _, _ ->
                openSettingsClicked()
            }
            .show()
    }
}