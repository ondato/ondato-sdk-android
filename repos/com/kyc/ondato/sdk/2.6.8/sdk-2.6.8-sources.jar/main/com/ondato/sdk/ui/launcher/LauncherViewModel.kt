package com.ondato.sdk.ui.launcher

import com.ondato.sdk.OndatoConfig
import com.ondato.sdk.ui.base.BaseViewModel
import com.ondato.sdk.ui.base.event
import com.ondato.sdk.ui.base.set
import com.ondato.sdk.usecase.session.StartSessionUseCase
import com.ondato.sdk.usecase.session.restart.RestartSessionUseCase

internal class LauncherViewModel(
    private val startSessionUseCase: StartSessionUseCase,
    private val restartSessionUseCase: RestartSessionUseCase,
) : BaseViewModel() {

    val success by event<Unit>()

    fun init(shouldRestart: Boolean, config: OndatoConfig) {
        launch {
            if (shouldRestart) {
                restartSessionUseCase.restart()
            } else {
                startSessionUseCase.start(config)
            }
            success.set(Unit)
        }
    }
}