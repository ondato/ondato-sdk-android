package com.ondato.sdk.usecase.installationid

internal interface InstallationIdStorage {
    suspend fun get(): String

    suspend fun save(id: String)
}