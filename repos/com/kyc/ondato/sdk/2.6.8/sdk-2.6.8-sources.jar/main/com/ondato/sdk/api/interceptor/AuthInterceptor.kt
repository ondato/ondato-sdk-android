package com.ondato.sdk.api.interceptor

import com.ondato.sdk.usecase.session.Session
import okhttp3.Interceptor
import okhttp3.Response

internal class AuthInterceptor(private val session: Session) : Interceptor {

    override fun intercept(chain: Interceptor.Chain): Response {
        return if (session.token.token.isEmpty()) {
            chain.proceed(chain.request())
        } else {
            chain.proceed(
                chain.request()
                    .newBuilder()
                    .header("Authorization", "${session.token.type} ${session.token.token}")
                    .build()
            )
        }
    }
}