package com.ondato.sdk.ui.tooManyAttempts

import android.os.Bundle
import android.view.View
import com.ondato.sdk.R
import com.ondato.sdk.ui.base.BaseFragment
import com.ondato.sdk.ui.main.MainViewModel
import com.ondato.sdk.ui.main.Step
import org.koin.androidx.viewmodel.ext.android.sharedViewModel

internal class TooManyAttemptsFragment: BaseFragment(R.layout.ondato_fragment_success) {
    private val mainViewModel: MainViewModel by sharedViewModel()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        R.id.imageView.src(R.drawable.ondato_close_icon_color)
        R.id.titleTextView.text(R.string.ondato_face_auth_too_many_attempts_title)
        R.id.descriptionTextView.text(R.string.ondato_face_auth_too_many_attempts_description)
        R.id.ondatoCloseButton.text(R.string.ondato_face_auth_too_many_attempts_button)
        R.id.ondatoCloseButton.onClick { mainViewModel.onStepSuccess(Step.TOO_MANY_ATTEMPTS) }
    }

    companion object {
        fun newInstance(): TooManyAttemptsFragment {
            return TooManyAttemptsFragment()
        }
    }
}