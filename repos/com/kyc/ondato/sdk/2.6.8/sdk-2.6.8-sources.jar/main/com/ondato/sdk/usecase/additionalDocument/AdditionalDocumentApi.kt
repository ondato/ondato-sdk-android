package com.ondato.sdk.usecase.additionalDocument

import com.ondato.sdk.usecase.savephoto.Mode

internal interface AdditionalDocumentApi {

    suspend fun send(
        identityVerificationId: String,
        imageBase64: String,
        imageFileType: String,
        mode: Mode,
    )
}