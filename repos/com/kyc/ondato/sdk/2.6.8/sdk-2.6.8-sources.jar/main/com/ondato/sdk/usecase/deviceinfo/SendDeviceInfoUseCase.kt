package com.ondato.sdk.usecase.deviceinfo

import com.ondato.sdk.api.session.DeviceInfoBodyV2
import com.ondato.sdk.api.session.DeviceInformation
import com.ondato.sdk.api.session.OsVersion
import com.ondato.sdk.api.session.SessionSource
import com.ondato.sdk.usecase.installationid.InstallationIdUseCase
import com.ondato.sdk.usecase.session.Session
import kotlinx.coroutines.*

internal class SendDeviceInfoUseCase(
    private val session: Session,
    private val api: DeviceInfoApi,
    private val os: OsInfoProvider,
    private val id: InstallationIdUseCase,
    private val model: DeviceModelProvider,
    private val sdkVersion: SdkVersionProvider,
    private val dispatcher: CoroutineDispatcher = Dispatchers.Default
) {

    suspend fun sendV2(identityVerificationId: String) = withContext(dispatcher) {
        val (model, osName, osVersion, sdkVersion, installationId) = awaitAll(
            async { model.get() },
            async { os.getName() },
            async { os.getSdkVersion() },
            async { sdkVersion.get() },
            async { id.get() },
        )
        val info = DeviceInfoBodyV2(
            sdkVersion,
            SessionSource.Mobile,
            DeviceInformation(
                model,
                osName,
                OsVersion(osVersion.toInt(), 0, 0),
                installationId,
            )
        )
        api.sendDeviceInfoV2(identityVerificationId, info)
    }
}