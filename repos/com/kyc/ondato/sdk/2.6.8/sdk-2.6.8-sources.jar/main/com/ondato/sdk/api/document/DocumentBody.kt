package com.ondato.sdk.api.document

import com.google.gson.annotations.SerializedName

internal class DocumentBody(
    @SerializedName("type") val type: String,
    @SerializedName("part") val part: String,
    @SerializedName("imageBase64") val imageBase64: String,
    @SerializedName("imageFileType") val imageFileType: String,
)