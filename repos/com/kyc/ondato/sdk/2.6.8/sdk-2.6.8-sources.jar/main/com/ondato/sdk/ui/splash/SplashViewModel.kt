package com.ondato.sdk.ui.splash

import com.ondato.sdk.ui.base.BaseViewModel
import com.ondato.sdk.ui.base.call
import com.ondato.sdk.ui.base.event
import com.ondato.sdk.usecase.session.StartSessionUseCase
import com.ondato.sdk.usecase.session.restart.RestartSessionUseCase

internal class SplashViewModel(
    private val startSessionUseCase: StartSessionUseCase,
    private val restartSessionUseCase: RestartSessionUseCase,
) : BaseViewModel() {
    val success by event<Unit>()

    fun init() = launch {
        success.call()
    }
}