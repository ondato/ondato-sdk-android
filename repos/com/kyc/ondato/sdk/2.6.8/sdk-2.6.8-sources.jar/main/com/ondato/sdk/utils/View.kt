package com.ondato.sdk.utils

import android.view.View
import android.view.inputmethod.InputMethodManager
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

fun View.hideKeyboard() {
    if (isKeyboardVisible()) {
        val inputMethodManager =
            context.getSystemService(android.content.Context.INPUT_METHOD_SERVICE) as? InputMethodManager
        inputMethodManager?.hideSoftInputFromWindow(this.windowToken, 0)
        clearFocus()
    }
}

fun View.isKeyboardVisible(): Boolean {
    val insets = ViewCompat.getRootWindowInsets(this)
    return insets?.isVisible(
        WindowInsetsCompat.Type.ime()
    ) ?: false
}