package com.ondato.sdk.ui.base

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.ondato.sdk.log.Logger
import com.ondato.sdk.ui.error.ErrorMessageMapper
import com.ondato.sdk.ui.main.ErrorConfig
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlin.coroutines.CoroutineContext
import kotlin.coroutines.EmptyCoroutineContext

abstract class BaseViewModel : ViewModel() {
    private val handler = CoroutineExceptionHandler { _, throwable -> handleError(throwable) }

    val showError by event<ErrorConfig>()
    val hideError by event<Unit>()
    val isLoading by state(false)

    protected open fun handleError(error: Throwable) {
        Logger.d(error, "Error @ ${this::class.simpleName}")
        isLoading.set(false)
        showError.set(ErrorMessageMapper.map(error))
    }

    protected fun launch(
        context: CoroutineContext = EmptyCoroutineContext,
        withLoader: Boolean = true,
        onError: ((Throwable) -> Unit)? = null,
        operation: suspend CoroutineScope.() -> Unit
    ): Job {
        val errorHandler = if (onError == null) {
            handler
        } else {
            CoroutineExceptionHandler { _, throwable ->
                isLoading.set(false)
                onError(throwable)
            }
        }

        return viewModelScope.launch(context + errorHandler) {
            if (withLoader) isLoading.set(true)
            operation()
            if (withLoader) isLoading.set(false)
        }
    }
}