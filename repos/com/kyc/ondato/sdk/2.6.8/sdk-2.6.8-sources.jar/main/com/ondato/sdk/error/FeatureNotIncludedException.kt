package com.ondato.sdk.error

internal class FeatureNotIncludedException(override val message: String) : RuntimeException(message)