package com.ondato.sdk.ui.liveness.pasive

import com.otaliastudios.cameraview.CameraException
import com.otaliastudios.cameraview.CameraListener
import com.otaliastudios.cameraview.CameraView
import com.otaliastudios.cameraview.PictureResult
import kotlinx.coroutines.*

import kotlinx.coroutines.delay

internal class LivenessCaptor(
    private val dispatcher: CoroutineDispatcher = Dispatchers.Default
) {
    fun capture(
        scope: CoroutineScope,
        cameraView: CameraView,
        captureListener: CaptureListener,
        numberOfFrames: Int = DEFAULT_NUMBER_OF_FRAMES
    ) {
        scope.launch(dispatcher) {
            val result = mutableListOf<ByteArray>()

            val listener = object : CameraListener() {
                override fun onPictureTaken(pictureResult: PictureResult) {
                    result.add(pictureResult.data)
                    if (result.size < numberOfFrames) {
                        scope.launch(dispatcher) {
                            withContext(dispatcher) {
                                delay(250)
                                cameraView.takePictureSnapshot()
                            }
                        }
                    } else {
                        captureListener.onCaptured(result.toList())
                        result.clear()
                        cameraView.removeCameraListener(this)
                        cameraView.close()
                    }
                }

                override fun onCameraError(exception: CameraException) {
                    result.clear()
                    captureListener.onCaptureFailed()
                }
            }

            cameraView.addCameraListener(listener)
            cameraView.takePictureSnapshot()
        }
    }

    companion object {
        private const val DEFAULT_NUMBER_OF_FRAMES = 5
    }
}