package com.ondato.sdk.usecase.session.verification

interface VerificationApi {

    suspend fun verify(identityVerificationId: String)
}