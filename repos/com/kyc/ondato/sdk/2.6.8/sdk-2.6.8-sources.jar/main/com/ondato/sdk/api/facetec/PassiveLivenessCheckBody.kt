package com.ondato.sdk.api.facetec

import com.google.gson.annotations.SerializedName

internal class PassiveLivenessCheckBody(
    @SerializedName("auditImagesBase64") val auditImagesBase64: List<String>,
)