package com.ondato.sdk.usecase.identification

import androidx.annotation.Keep

internal data class Identification(
    val status: Status,
)

internal sealed class Status {
    sealed class Finished : Status() {
        object Success : Finished()

        data class Rejected(val rejectedStatus: RejectedStatus) : Finished()
    }

    object Awaiting : Status()
}

@Keep
internal enum class RejectedStatus(val tryAgain: Boolean) {
    MissingDocumentPhoto(tryAgain = true),
    DocumentNotAccepted(tryAgain = true),
    DataNotMatch(tryAgain = true),
    Sanctioned(tryAgain = false),
    MissingPersonPhoto(tryAgain = true),
    FacesNotMatch(tryAgain = true),
    PoorPhotoQuality(tryAgain = true),
    PoorPhotoLighting(tryAgain = true),
    MISCELLANEOUS(tryAgain = false),
    PossibleFraudAttempt(tryAgain = false),
    UnrelatedPhotoSubmit(tryAgain = true),
    MoreThanOnePerson(tryAgain = true),
    ProhibitedCountryOrState(tryAgain = false),
    DocumentIsExpired(tryAgain = true),
    DocumentWithNonLatinCharacters(tryAgain = true),
    PartOfDocumentIsCovered(tryAgain = true),
    BAD_MEDIA_FORMAT(tryAgain = true),
    PartOfFaceIsCovered(tryAgain = true),
    UnderagePerson(tryAgain = false),
    ProhibitedNationality(tryAgain = false),
    FacePhotoUploadFormat(tryAgain = true),
    TransferToVideoCall(tryAgain = true),
    Unfinished(tryAgain = true),
    DuplicatedInfo(tryAgain = false),
    Processing(tryAgain = true),
    AutomaticallyIdentified(tryAgain = true),
    ManuallyIdentified(tryAgain = true),
    SomethingWentWrong(tryAgain = false),
}