package com.ondato.sdk.usecase.installationid

import java.util.*

internal object InstallationIdGenerator {
    fun generate(): String = UUID.randomUUID().toString()
}