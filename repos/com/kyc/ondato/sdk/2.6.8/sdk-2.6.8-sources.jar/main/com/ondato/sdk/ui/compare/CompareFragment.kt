package com.ondato.sdk.ui.compare

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.ondato.sdk.Ondato
import com.ondato.sdk.OndatoConfig
import com.ondato.sdk.R
import com.ondato.sdk.ui.base.BaseFragment
import com.ondato.sdk.ui.main.MainViewModel
import com.ondato.sdk.ui.main.Step.COMPARE
import org.koin.androidx.viewmodel.ext.android.sharedViewModel
import org.koin.androidx.viewmodel.ext.android.viewModel

internal class CompareFragment : BaseFragment(R.layout.ondato_fragment_compare) {
    private val config: OndatoConfig = Ondato.config
    private val viewModel: CompareViewModel by viewModel()
    private val mainViewModel: MainViewModel by sharedViewModel()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (savedInstanceState == null) {
            viewModel.init(config)
        }
        viewModel.invokeScreenRecordingUpload.observe {
            val intent = Intent("invoke_record_upload")
            LocalBroadcastManager.getInstance(requireContext()).sendBroadcast(intent)
        }
        viewModel.success.observe { mainViewModel.onStepSuccess(COMPARE) }
        viewModel.failed.observeForever(mainViewModel::onStepFailed)
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        config.loadingScreenProvider.get().show(R.id.loadingContainer)
    }

    companion object {
        fun newInstance() = CompareFragment()
    }
}