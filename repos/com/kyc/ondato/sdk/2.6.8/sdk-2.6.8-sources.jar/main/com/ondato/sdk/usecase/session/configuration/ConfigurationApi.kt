package com.ondato.sdk.usecase.session.configuration

import com.ondato.sdk.api.session.ApiFaceAuthStatusResponse
import com.ondato.sdk.usecase.session.ApiConfig
import retrofit2.http.Path

internal interface ConfigurationApi {

    suspend fun getKycIdentificationSetup(identityVerificationId: String): SessionSetup

    suspend fun getKYCId(setupId: String, identityVerificationId: String): String

    suspend fun getConfig(KYCId: String): ApiConfig

    suspend fun getFaceAuthConfig(@Path("id") faceAuthId: String): ApiFaceAuthStatusResponse
}