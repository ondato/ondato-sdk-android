package com.ondato.sdk.ui.main

import android.content.ClipData
import android.content.ClipboardManager
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.content.ContextCompat.getSystemService
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.ondato.sdk.databinding.OndatoLogsBottomSheetBinding
import com.ondato.sdk.ui.utils.StorageHelper

class LogsBottomSheetFragment : BottomSheetDialogFragment() {
    private var _binding: OndatoLogsBottomSheetBinding? = null

    private val binding get() = _binding!!
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = OndatoLogsBottomSheetBinding.inflate(inflater, container, false)

        return binding.root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        //Logs picker is available only for our internal app
        //TODO: Also include the package name of react native internal app?
        val packageName = context?.packageName
        packageName?.let {
            if (packageName == "com.ondato.sdk.test") {
                val storageHelper = StorageHelper(requireContext())

                binding.idvid.text = storageHelper.getIdvId()

                storageHelper.getLogsFile()?.let {
                    binding.logsBlock.setText(storageHelper.getContents(it))
                } ?: run {
                    binding.logsBlock.setText("")
                }

                binding.copyLogs.setOnClickListener {
                    storageHelper.getLogsFile()?.let {
                        try {
                            val clipboardManager =
                                getSystemService(requireContext(), ClipboardManager::class.java)
                            val clipData =
                                ClipData.newPlainText("Label", storageHelper.getContents(it))
                            clipboardManager?.setPrimaryClip(clipData)
                        } catch (e: Exception) {
                            Toast.makeText(
                                context,
                                e.message,
                                Toast.LENGTH_LONG
                            ).show()
                        }
                    }
                }

                binding.clearLogs.setOnClickListener {
                    storageHelper.deleteLogsFile()
                    binding.logsBlock.setText("")
                }

                binding.shareLogsButton.setOnClickListener {
                    storageHelper.shareLogs(requireActivity())
                }

                binding.downloadLogs.setOnClickListener {
                    storageHelper.getLogsFile()?.let { file ->
                        storageHelper.saveToDownloads(file)
                    }
                }
            } else {
                activity?.finish()
            }
        }
    }
}