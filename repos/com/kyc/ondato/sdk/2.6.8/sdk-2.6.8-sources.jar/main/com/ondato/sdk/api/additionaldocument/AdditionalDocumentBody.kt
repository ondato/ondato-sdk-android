package com.ondato.sdk.api.additionaldocument

import androidx.annotation.Keep
import com.google.gson.annotations.SerializedName
import com.ondato.sdk.usecase.savephoto.Mode

internal class AdditionalDocumentBody(
    @SerializedName("imageBase64") val imageBase64: String,
    @SerializedName("imageFileType") val imageFileType: String,
    @SerializedName("type") val type: String,
)

@Keep
internal enum class AdditionalDocumentType(val type: String) {
    SelfieWithDoc("SelfieWithDoc"),
    ProofOfAddress("ProofOfAddress");

    companion object {
        fun of(mode: Mode): String {
            return when (mode) {
                Mode.Selfie -> SelfieWithDoc.type
                Mode.Address -> ProofOfAddress.type
                else -> ""
            }
        }
    }
}