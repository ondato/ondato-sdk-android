package com.ondato.sdk.ui.base


class MutableLiveNonNullData<T>(default: T) : LiveNonNullData<T>(default) {

    public override fun postValue(value: T) = super.postValue(value)

    public override fun setValue(value: T) = super.setValue(value)
}
