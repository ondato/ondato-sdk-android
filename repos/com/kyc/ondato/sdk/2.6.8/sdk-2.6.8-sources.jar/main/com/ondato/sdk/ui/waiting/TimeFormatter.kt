package com.ondato.sdk.ui.waiting

internal class TimeFormatter {
    fun format(seconds: Int): String {
        val min = seconds / 60
        val sec = seconds % 60
        return FORM.format(min, sec)
    }

    companion object {
        private const val FORM = "%d:%02d"
    }
}