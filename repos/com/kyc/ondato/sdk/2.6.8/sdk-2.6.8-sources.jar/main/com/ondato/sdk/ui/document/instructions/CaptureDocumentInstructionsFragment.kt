package com.ondato.sdk.ui.document.instructions

import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.core.view.isVisible
import com.ondato.sdk.R
import com.ondato.sdk.ui.base.BaseFragment
import com.ondato.sdk.ui.main.MainViewModel
import com.ondato.sdk.usecase.savephoto.Mode
import org.koin.androidx.viewmodel.ext.android.sharedViewModel
import org.koin.androidx.viewmodel.ext.android.viewModel

internal class CaptureDocumentInstructionsFragment :
    BaseFragment(R.layout.ondato_fragment_capture_document_instructions) {

    private val viewModel: CaptureDocumentInstructionsViewModel by viewModel()
    private val mainViewModel: MainViewModel by sharedViewModel()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ((arguments?.getSerializable(KEY_MODE) as? Mode) ?: Mode.Front).let(viewModel::init)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel.isLoading.observeOnView(::toggleScreenVisibility)
        viewModel.data.observeOnView(::setupUi)
        viewModel.next.observeOnView(mainViewModel::onStepSuccess)
    }

    private fun setupUi(data: InstructionsViewData) {
        R.id.ondatoDocumentInstructionsStart.onClick { viewModel.onStartClicked() }
        R.id.ondatoDocumentInstructionsTitle.text(data.titleResId)
        R.id.ondatoDocumentInstructionsDescription.text(data.descriptionResId)
        R.id.ondatoDocumentInstructionsImage.find<ImageView>()?.apply {
            (layoutParams as? ViewGroup.MarginLayoutParams)?.setMargins(
                data.imageMarginLeft,
                data.imageMarginTop,
                data.imageMarginRight,
                data.imageMarginBottom
            )
            setImageResource(data.imageResId)
        }
        R.id.ondato_mrz_scan_result_mistake_one_description.text(data.firstMistakeDescResId)
        R.id.ondato_mrz_scan_result_mistake_two_description.text(data.secondMistakeDescResId)
        R.id.ondato_mrz_scan_result_mistake_three_description.text(data.thirdMistakeDescResId)
        R.id.ondato_mrz_scan_result_instruction_one.src(data.firstMistakeImageResId)
        R.id.ondato_mrz_scan_result_instruction_two.src(data.secondMistakeImageResId)
        R.id.ondato_mrz_scan_result_instruction_three.src(data.thirdMistakeImageResId)
    }

    private fun toggleScreenVisibility(loading: Boolean) {
        R.id.ondatoDocumentInstructionsContainer.view()?.isVisible = !loading
    }

    companion object {
        private const val KEY_MODE = "key.mode"

        fun newInstance(mode: Mode): CaptureDocumentInstructionsFragment {
            val bundle = Bundle().apply { putSerializable(KEY_MODE, mode) }
            val fragment = CaptureDocumentInstructionsFragment()
            fragment.apply { arguments = bundle }
            return fragment
        }
    }
}