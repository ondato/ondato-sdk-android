package com.ondato.sdk.api.upload

import com.ondato.sdk.usecase.document.DocumentType
import com.ondato.sdk.usecase.savephoto.Mode

internal fun Mode.toSide(): String {
    return when (this) {
        Mode.Back, Mode.MRZ -> "Back"
        else -> "Front"
    }
}

internal fun Mode.toSide(documentType: DocumentType): String {
    return if (documentType == DocumentType.Passport) {
        when (this) {
            Mode.Back, Mode.MRZ, Mode.Front -> "DataPage"
            else -> "FrontCover"
        }
    } else {
        when (this) {
            Mode.Back, Mode.MRZ -> "Back"
            else -> "Front"
        }
    }
}