package com.ondato.sdk.android

import android.content.Context
import com.ondato.sdk.usecase.deviceinfo.DeviceModelProvider
import com.ondato.sdk.usecase.deviceinfo.OsInfoProvider
import com.ondato.sdk.usecase.deviceinfo.SdkVersionProvider
import org.koin.android.ext.koin.androidContext
import org.koin.dsl.bind
import org.koin.dsl.module

internal val androidModule = module {
    single { androidContext().getSharedPreferences("ondato.sdk", Context.MODE_PRIVATE) }
    factory { AndroidDeviceModelProvider() } bind DeviceModelProvider::class
    factory { AndroidOsInfoProvider() } bind OsInfoProvider::class
    factory { AndroidSdkVersionProvider() } bind SdkVersionProvider::class
}