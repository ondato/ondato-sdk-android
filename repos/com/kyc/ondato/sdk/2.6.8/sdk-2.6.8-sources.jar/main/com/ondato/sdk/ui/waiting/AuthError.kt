package com.ondato.sdk.ui.waiting

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
sealed class AuthError : Parcelable {
    object Timeout: AuthError()
}
