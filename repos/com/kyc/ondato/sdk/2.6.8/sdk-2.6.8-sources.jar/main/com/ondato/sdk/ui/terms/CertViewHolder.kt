package com.ondato.sdk.ui.terms

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.ondato.sdk.R

internal class CertViewHolder(view: View) : RecyclerView.ViewHolder(view) {

    fun bind(imageUrl: String) {
        Glide.with(itemView).load(imageUrl).into(itemView.findViewById(R.id.certImageView))
    }

    companion object {
        fun create(parent: ViewGroup): CertViewHolder {
            val inflater = LayoutInflater.from(parent.context)
            val view = inflater.inflate(R.layout.ondato_item_certificate, parent, false)
            return CertViewHolder(view)
        }
    }
}