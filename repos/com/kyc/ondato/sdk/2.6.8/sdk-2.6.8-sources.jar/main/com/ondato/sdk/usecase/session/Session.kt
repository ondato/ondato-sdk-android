package com.ondato.sdk.usecase.session

import android.os.Parcelable
import androidx.annotation.Keep
import com.ondato.sdk.enums.Language
import com.ondato.sdk.usecase.document.DocumentType
import com.ondato.sdk.usecase.session.configuration.Steps
import com.ondato.sdk.usecase.session.token.Token
import com.ondato.sdk.usecase.upload.Upload
import kotlinx.parcelize.Parcelize

@Keep
@Parcelize
object Session : Parcelable {
    var kycSteps = mutableListOf<Steps>()
    var currentKycStep: Steps.Type = Steps.Type.Unknown
    var currentKycStepPosition = -1
    var faceAuthId: String? = null
    var kycId = ""
    var token: Token = Token.EMPTY
    var language: Language = Language.English
    var areTermsAgreed: Boolean = false
    var shouldShowRegistrationScreen: Boolean = false
    var availableDocumentTypes = listOf<DocumentTypeInfo>()
    var showProofOfAddressStep: Boolean = false
    var selectedType: DocumentType? = null
    var currentPart = -1
    var mrz: String = ""
    val uploads = mutableListOf<Upload>()
    var sessionCompleted = false
    var apiConfig: ApiConfig? = null

    fun isPassport() = selectedType == DocumentType.Passport

    fun clear() {
        kycSteps.clear()
        currentKycStep = Steps.Type.Unknown
        currentKycStepPosition = -1
        kycId = ""
        token = Token.EMPTY
        areTermsAgreed = false
        shouldShowRegistrationScreen = false
        availableDocumentTypes = emptyList()
        showProofOfAddressStep = false
        selectedType = null
        mrz = ""
        currentPart = -1
        language = Language.English
        uploads.clear()
        sessionCompleted = false
        apiConfig = null
    }

    fun restart() {
        uploads.clear()
        sessionCompleted = false
        selectedType = null
        mrz = ""
        currentPart = -1
        currentKycStep = Steps.Type.Unknown
        currentKycStepPosition = -1
    }
}