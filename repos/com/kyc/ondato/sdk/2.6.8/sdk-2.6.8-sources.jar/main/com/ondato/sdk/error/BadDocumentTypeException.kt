package com.ondato.sdk.error

import java.io.IOException

internal class BadDocumentTypeException : IOException()