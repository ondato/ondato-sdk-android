package com.ondato.sdk.api.registration

import androidx.annotation.Keep

@Keep
data class RegistrationRequest(
    val op: String,
    val path: String,
    val value: Value,
)

@Keep
data class Value(
    val personalCode: String,
)