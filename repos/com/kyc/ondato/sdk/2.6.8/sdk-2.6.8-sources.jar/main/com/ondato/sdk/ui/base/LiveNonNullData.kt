package com.ondato.sdk.ui.base

import androidx.lifecycle.LiveData

open class LiveNonNullData<T>(private val default: T) : LiveData<T>() {
    init {
        value = default
    }

    override fun getValue() = super.getValue() ?: default
}