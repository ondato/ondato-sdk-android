package com.ondato.sdk.ui.document.instructions

import android.os.Bundle
import android.view.View
import com.ondato.sdk.R
import com.ondato.sdk.ui.base.BaseFragment
import com.ondato.sdk.ui.main.MainViewModel
import com.ondato.sdk.ui.main.Step
import org.koin.androidx.viewmodel.ext.android.sharedViewModel

internal class CaptureSelfieWithDocumentInstructionsFragment
    : BaseFragment(R.layout.ondato_fragment_selfie_with_document_instructions) {

    private val mainViewModel: MainViewModel by sharedViewModel()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        R.id.ondatoDocumentInstructionsStart.onClick {
            mainViewModel.onStepSuccess(Step.CAPTURE_SELFIE_WITH_DOCUMENT_INSTRUCTIONS)
        }
    }

    companion object {
        fun newInstance() = CaptureSelfieWithDocumentInstructionsFragment()
    }
}
