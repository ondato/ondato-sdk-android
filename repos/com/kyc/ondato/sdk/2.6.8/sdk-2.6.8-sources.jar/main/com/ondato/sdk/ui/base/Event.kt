package com.ondato.sdk.ui.base

import androidx.lifecycle.LiveData
import kotlin.properties.ReadOnlyProperty
import kotlin.reflect.KProperty

class Event<T> : ReadOnlyProperty<Any, LiveData<T>> {
    private val liveData = SingleLiveEvent<T>()

    override fun getValue(thisRef: Any, property: KProperty<*>): LiveData<T> {
        return liveData
    }
}

fun <T> event() = Event<T>()