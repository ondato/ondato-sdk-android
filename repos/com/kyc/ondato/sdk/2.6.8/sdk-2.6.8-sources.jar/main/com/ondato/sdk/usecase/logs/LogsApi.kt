package com.ondato.sdk.usecase.logs

import com.ondato.sdk.log.Log

internal interface LogsApi {
    suspend fun send(identificationId: String, logs: List<Log>)
}