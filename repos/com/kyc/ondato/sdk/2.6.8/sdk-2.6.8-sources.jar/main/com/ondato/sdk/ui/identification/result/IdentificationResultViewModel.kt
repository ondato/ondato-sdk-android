package com.ondato.sdk.ui.identification.result

import android.os.CountDownTimer
import com.ondato.sdk.ui.base.BaseViewModel
import com.ondato.sdk.ui.base.event
import com.ondato.sdk.ui.base.set
import com.ondato.sdk.ui.base.state
import com.ondato.sdk.usecase.identification.RejectedStatus
import com.ondato.sdk.usecase.session.CompleteSessionUseCase

internal class IdentificationResultViewModel(
    private val completeSessionUseCase: CompleteSessionUseCase,
) : BaseViewModel() {



    val state by state<State>()

    val event by event<Event>()

    fun init(rejectedStatus: RejectedStatus?) {
        if (rejectedStatus == null) {
            initSuccess()
        } else {
            initFailure(rejectedStatus)
        }
    }

    private fun initSuccess() {
        object : CountDownTimer(
            TIME_IN_MILLIS,
            INTERVAL_IN_MILLIS
        ) {
            override fun onTick(millisUntilFinished: Long) {
                val secondsLeft = millisUntilFinished / 1000
                state.set(State.Success(secondsLeft.toInt()))
            }

            override fun onFinish() {
                onButtonClick(State.Success((TIME_IN_MILLIS / 1000).toInt()))
            }
        }.apply { start() }
    }

    private fun initFailure(rejectedStatus: RejectedStatus) {
        state.set(State.Failure(rejectedStatus))
    }

    fun onButtonClick(state: State) {
        when (state) {
            is State.Success -> event.set(Event.Success)
            is State.Failure -> event.set(Event.Failure(state.rejectedStatus.tryAgain))
        }
    }

    fun onCloseClick() {
        launch {
            completeSessionUseCase.complete()
            event.set(Event.Close)
        }
    }

    sealed class State {
        data class Success(val seconds: Int) : State()
        data class Failure(val rejectedStatus: RejectedStatus) : State()
    }

    sealed class Event {
        object Success : Event()
        data class Failure(val tryAgain: Boolean) : Event()

        object Close : Event()
    }

    companion object {
        private const val TIME_IN_MILLIS = 5000L
        private const val INTERVAL_IN_MILLIS = 500L
    }
}