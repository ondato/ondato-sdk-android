package com.ondato.sdk.ui.utils

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Environment
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.BufferedReader
import java.io.File
import java.io.FileOutputStream
import java.io.FileReader
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class StorageHelper(private val context: Context) {
    private val sharedPreferences = context.getSharedPreferences("my_preferences", Context.MODE_PRIVATE)

    fun getIdvId(): String? {
        return sharedPreferences.getString(IDV_ID_KEY, "")
    }

    fun storeIdvId(value: String) {
        sharedPreferences.edit().putString(IDV_ID_KEY, value).apply()
    }

    fun deleteLogsFile() {
        if (getLogsFile()?.exists() == true) {
            getLogsFile()?.delete()
        }
    }

    fun getLogsFile(): File? {
        val file = File(context.filesDir, LOGS_FILE)
        return if (file.exists()) {
            file
        } else {
            null
        }
    }

    fun saveLogToFile(logLine: String) {
        val file = File(context.filesDir, LOGS_FILE)
        FileOutputStream(file, true).use { outputStream ->
            outputStream.write(logLine.toByteArray())
            outputStream.write(System.lineSeparator().toByteArray())
        }
    }


    fun getContents(file: File): String {
        val stringBuilder = StringBuilder()
        try {
            BufferedReader(FileReader(file)).use { reader ->
                var line: String?
                while (reader.readLine().also { line = it } != null) {
                    stringBuilder.append(line)
                    stringBuilder.append(System.lineSeparator())
                }
            }
        } catch (e: IOException) {
            e.printStackTrace()
        }
        return stringBuilder.toString()
    }

    fun saveToDownloads(file: File) {
        try {
            val downloadsDir =
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
            val newFileName = "${file.nameWithoutExtension}_$timestamp.${file.extension}"
            val newFile = File(downloadsDir, newFileName)
            val fos = FileOutputStream(newFile)
            fos.write(file.readBytes())
            fos.close()
            Toast.makeText(context, "$newFileName saved to Downloads!", Toast.LENGTH_SHORT).show()
        } catch (e: IOException) {
            e.printStackTrace()
            Toast.makeText(context, "Error saving file to Downloads!", Toast.LENGTH_SHORT).show()
        }
    }

    fun shareLogs(activity: Activity) {
        val file = getLogsFile()
        file?.let {
            val uri = FileProvider.getUriForFile(
                activity,
                "${context.packageName}.provider",
                file
            )
            val fileShareIntent = Intent(Intent.ACTION_SEND)
                .setType("text/plain")
                .putExtra(Intent.EXTRA_STREAM, uri)
            val chooser = Intent.createChooser(fileShareIntent, "Send Logs")
            chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            try {
                activity.startActivity(chooser)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    companion object {
        private const val LOGS_FILE = "logs.txt"
        private const val IDV_ID_KEY = "IDV_ID_KEY"
    }
}