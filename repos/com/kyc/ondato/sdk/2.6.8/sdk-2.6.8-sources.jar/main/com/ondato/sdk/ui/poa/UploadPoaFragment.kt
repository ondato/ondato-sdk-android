package com.ondato.sdk.ui.poa

import android.app.Activity.RESULT_OK
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.isVisible
import com.ondato.sdk.R
import com.ondato.sdk.databinding.OndatoFragmentUploadPoaBinding
import com.ondato.sdk.ui.base.BaseFragment
import com.ondato.sdk.ui.document.instructions.CaptureDocumentInstructionsViewModel
import com.ondato.sdk.ui.main.MainViewModel
import com.ondato.sdk.ui.main.Step
import com.ondato.sdk.utils.Utils.getBytes
import com.ondato.sdk.utils.Utils.getFileNameFromUri
import com.ondato.sdk.utils.Utils.getFileSizeFromUri
import com.ondato.sdk.utils.Utils.getMimeType
import com.ondato.sdk.utils.Utils.roundOffDecimal
import org.koin.androidx.viewmodel.ext.android.sharedViewModel
import org.koin.androidx.viewmodel.ext.android.viewModel
import java.io.InputStream

internal class UploadPoaFragment : BaseFragment(R.layout.ondato_fragment_upload_poa) {

    private var _binding: OndatoFragmentUploadPoaBinding? = null
    private val binding get() = _binding!!

    private val viewModel: CaptureDocumentInstructionsViewModel by viewModel()
    private val mainViewModel: MainViewModel by sharedViewModel()
    private val uploadPoaViewModel: UploadPoaViewModel by viewModel()
    private var selectedFileUri: Uri? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        uploadPoaViewModel.completed.observe(::onCompleted)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = OndatoFragmentUploadPoaBinding.inflate(inflater, container, false)

        return binding.root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel.isLoading.observeOnView(::toggleScreenVisibility)
        viewModel.next.observeOnView(mainViewModel::onStepSuccess)
        R.id.continueButton.onClick {
            onContinueClicked()
            handlePickedFileUpload()
        }
        R.id.uploadContainer.onClick { launchFilePicker() }
        R.id.trashIcon.onClick { onPickedFileRemove() }
    }

    private fun launchFilePicker() {
        val mimeTypes = arrayOf("application/pdf", "image/*")
        val intent = Intent()
            .setType("*/*")
            .putExtra(Intent.EXTRA_MIME_TYPES, mimeTypes)
            .setAction(Intent.ACTION_GET_CONTENT)

        resultLauncher.launch(intent)
    }

    private var resultLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                selectedFileUri = result.data?.data
                selectedFileUri?.let { uri ->
                    val fileName = getFileNameFromUri(requireContext(), uri)
                    val fileSize = getFileSizeFromUri(requireContext(), uri)
                    val roundedFileSize = roundOffDecimal((fileSize?.toDouble() ?: 0.00) / 1024)
                    binding.fileNameTx.text = fileName
                    binding.fileSizeTx.text = getString(R.string.ondato_capture_poa_file_size, roundedFileSize.toString())
                }
                onFilePicked()
            }
        }

    /**
     * When user selects the file, convert it to byteArray and send it to backend
     */
    private fun handlePickedFileUpload() {
        val iStream: InputStream? = selectedFileUri?.let {
            context?.contentResolver?.openInputStream(it)
        }
        val inputData = iStream?.let { getBytes(it) }
        inputData?.let { byteArray ->
            val type = selectedFileUri?.let { getMimeType(requireContext(), it) }
            type?.let { uploadPoaViewModel.onContinueClicked(byteArray, it) }
        }
    }

    private fun onFilePicked() {
        R.id.continueButton.enable()
        R.id.trashIcon.show()
        R.id.uploadIcon.src(R.drawable.ondato_poa_document_icon)
        R.id.uploadContainer.bg(R.drawable.ondato_normal_bg)
        R.id.clickHereTx.hide()
        R.id.fileNameTx.show()
        R.id.fileSizeTx.show()
    }

    private fun onPickedFileRemove() {
        R.id.continueButton.disable()
        R.id.trashIcon.invisible()
        R.id.uploadIcon.src(R.drawable.ondato_upload_icon)
        R.id.uploadContainer.bg(R.drawable.ondato_dotted_bg)
        R.id.fileSizeTx.hide()
        R.id.fileNameTx.hide()
        R.id.clickHereTx.show()
    }

    private fun onContinueClicked() {
        R.id.trashIcon.src(R.drawable.ondato_trash_icon_disabled)
        R.id.trashIcon.disable()
    }

    private fun toggleScreenVisibility(loading: Boolean) {
        R.id.ondatoDocumentInstructionsContainer.view()?.isVisible = !loading
    }

    private fun onCompleted() {
        mainViewModel.onStepSuccess(Step.UPLOAD_POA)
    }

    companion object {
        fun newInstance(): UploadPoaFragment {
            return UploadPoaFragment()
        }
    }
}