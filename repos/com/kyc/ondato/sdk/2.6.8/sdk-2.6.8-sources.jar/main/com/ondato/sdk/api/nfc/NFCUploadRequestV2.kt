package com.ondato.sdk.api.nfc

import androidx.annotation.Keep
import com.google.gson.annotations.SerializedName

@Keep
data class NFCUploadRequestV2(
    @SerializedName("firstName") val firstName: String? = null,
    @SerializedName("middleName") val middleName: String? = null,
    @SerializedName("lastName") val lastName: String? = null,
    @SerializedName("documentNumber") val documentNumber: String? = null,
    @SerializedName("personalCode") val personalCode: String? = null,
    @SerializedName("dateOfExpiration") val dateOfExpiration: String? = null,
    @SerializedName("dateOfBirth") val dateOfBirth: String? = null,
    @SerializedName("dateOfIssue") val dateOfIssue: String? = null,
    @SerializedName("nationality") val nationality: String? = null,
    @SerializedName("gender") val gender: String? = null,
    @SerializedName("type") val type: String? = null,
    @SerializedName("faceBase64") val faceBase64: String? = null,
)