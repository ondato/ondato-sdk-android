package com.ondato.sdk.storage.installationid

import android.content.SharedPreferences
import com.ondato.sdk.usecase.installationid.InstallationIdStorage
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

internal class PrefsInstallationIdStorage(
    private val prefs: SharedPreferences,
    private val dispatcher: CoroutineDispatcher = Dispatchers.IO
) : InstallationIdStorage {

    override suspend fun get(): String = withContext(dispatcher) {
        prefs.getString(ID, "") ?: ""
    }

    override suspend fun save(id: String) = withContext(dispatcher) {
        prefs.edit().putString(ID, id).apply()
    }

    companion object {
        private const val ID = "ondato.id"
    }
}