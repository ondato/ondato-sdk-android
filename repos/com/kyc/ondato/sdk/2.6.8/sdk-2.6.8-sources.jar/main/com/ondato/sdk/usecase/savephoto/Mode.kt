package com.ondato.sdk.usecase.savephoto

import java.io.Serializable

sealed class Mode : Serializable {
    object Front : Mode()
    object Back : Mode()
    object Selfie : Mode()
    object Address : Mode()
    object MRZ : Mode()
}

internal sealed class LivenessMode: Serializable {
    object Liveness: LivenessMode()

    object FaceAuth: LivenessMode()
}