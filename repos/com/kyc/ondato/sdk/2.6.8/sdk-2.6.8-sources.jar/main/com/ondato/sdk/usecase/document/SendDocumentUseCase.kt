package com.ondato.sdk.usecase.document

import android.graphics.Bitmap
import com.ondato.sdk.api.upload.toSide
import com.ondato.sdk.usecase.ImageFileType
import com.ondato.sdk.usecase.savephoto.Mode
import com.ondato.sdk.usecase.savephoto.PhotoStorage
import com.ondato.sdk.usecase.session.Session
import com.ondato.sdk.utils.Base64.decodeToBase64
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class SendDocumentUseCase internal constructor(
    private val session: Session,
    private val storage: PhotoStorage,
    private val documentApi: DocumentApi,
    private val dispatcher: CoroutineDispatcher = Dispatchers.Default
) {
    suspend fun send(
        documentType: String,
        photo: ByteArray,
        mode: Mode
    ) = withContext(dispatcher) {
        val file = storage.save(photo, mode)
        documentApi.send(
            documentType,
            session.kycId,
            file.path.decodeToBase64(Bitmap.CompressFormat.JPEG),
            ImageFileType.Jpeg.type,
            mode.toSide(DocumentType.of(documentType)),
        )
    }
}