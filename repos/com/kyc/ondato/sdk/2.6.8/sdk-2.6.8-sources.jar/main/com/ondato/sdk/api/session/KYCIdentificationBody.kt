package com.ondato.sdk.api.session

import com.google.gson.annotations.SerializedName

internal class KYCIdentificationBody(
    @SerializedName("setupId") val kycId: String,
    @SerializedName("identityVerificationId") val identityVerificationId: String
)
