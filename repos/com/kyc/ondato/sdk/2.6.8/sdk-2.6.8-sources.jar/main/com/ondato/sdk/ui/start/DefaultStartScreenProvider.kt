package com.ondato.sdk.ui.start

import androidx.fragment.app.Fragment
import com.ondato.sdk.screen.StartScreenCallback
import com.ondato.sdk.screen.StartScreenProvider

internal object DefaultStartScreenProvider : StartScreenProvider {
    override fun get(callback: StartScreenCallback): Fragment {
        return StartFragment.newInstance(callback)
    }
}