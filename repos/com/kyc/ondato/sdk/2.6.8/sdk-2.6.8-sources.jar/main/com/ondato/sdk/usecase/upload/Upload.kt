package com.ondato.sdk.usecase.upload

import com.ondato.sdk.usecase.document.DocumentType
import com.ondato.sdk.usecase.savephoto.Mode
import java.io.File

sealed class Upload {
    internal sealed class FileUpload(open val file: File) : Upload() {
        data class DocumentUpload(
            override val file: File,
            val documentType: DocumentType,
            val mode: Mode
        ) : FileUpload(file)

        data class FacePhotoUpload(
            override val file: File,
            val ageEstimate: String?,
            val enrollmentId: String?,
            val isPassive: Boolean = false
        ) : FileUpload(file)

        data class RecordUpload(override val file: File) : FileUpload(file)
    }
}
