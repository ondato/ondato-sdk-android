package com.ondato.sdk.api.session

import com.ondato.sdk.api.BackendApi
import com.ondato.sdk.usecase.session.verification.VerificationApi

internal class VerificationApiService(private val api: BackendApi) : VerificationApi {

    override suspend fun verify(identityVerificationId: String) {
        api.verification(identityVerificationId)
    }
}