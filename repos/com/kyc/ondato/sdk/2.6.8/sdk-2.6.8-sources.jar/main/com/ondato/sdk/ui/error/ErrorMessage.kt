package com.ondato.sdk.ui.error

interface ErrorMessage {
    val title: Int
    val message: Int
}