package com.ondato.sdk.storage.file

import android.graphics.Bitmap
import com.ondato.sdk.usecase.savephoto.Mode
import com.ondato.sdk.usecase.savephoto.PhotoStorage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.util.*
import kotlin.coroutines.CoroutineContext

internal class AndroidPhotoStorage(
    private val dir: File,
    private val gifGenerator: GifGenerator = GifGenerator(),
    private val factory: BitmapFactory = BitmapFactory(),
    private val context: CoroutineContext = Dispatchers.IO
) : PhotoStorage {

    override suspend fun save(byteArray: ByteArray, mode: Mode): File = withContext(context) {
        val bitmap = factory.create(byteArray, mode)
        val name = UUID.randomUUID().toString()
        val file = File(dir, "$name.jpg")
        if (file.exists()) file.delete()
        val out = FileOutputStream(file)
        bitmap.compress(Bitmap.CompressFormat.JPEG, 90, out)
        bitmap.recycle()
        out.flush()
        out.close()
        file
    }

    override suspend fun save(frames: List<ByteArray>): File {
        val name = UUID.randomUUID().toString()
        val file = File(dir, "$name.gif")
        file.createNewFile()
        gifGenerator.saveAsGif(frames, file)
        return file
    }

    override suspend fun delete(file: File) = withContext(context) {
        if (file.exists()) {
            file.delete()
        }
    }

    override suspend fun clear() = withContext(context) {
        dir.listFiles().forEach(File::delete)
    }
}