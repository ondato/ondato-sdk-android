package com.ondato.sdk.ui.compare

import com.ondato.sdk.OndatoConfig
import com.ondato.sdk.usecase.verify.Verification

internal val criticalErrors = listOf(
    VerificationError.PersonPhotoContainsFace,
    VerificationError.PersonFoundInComplyAdvantage,
    VerificationError.ContainsCelebrity
)

internal fun Verification.isVerified(config: OndatoConfig): Boolean {
//Ignore verification errors by default until backend is ready
    return true
//    if (config.ignoreVerificationErrors) return true
//    return this == Verification.verified()
}

internal fun Verification.getErrors(): List<VerificationError> {
    return VerificationErrorMapper.map(this)
}

internal fun List<VerificationError>.getMainError(): VerificationError? {
    return find(VerificationError::isCritical) ?: firstOrNull()
}

internal fun VerificationError.isCritical(): Boolean {
    return this in criticalErrors
}
