package com.ondato.sdk.ui.start

import com.ondato.sdk.R
import com.ondato.sdk.enums.Language

internal object LanguageMapper {
    fun map(languages: Language): Int {
        return when (languages) {
            Language.English -> R.string.ondato_language_en
            Language.Lithuanian -> R.string.ondato_language_lt
            Language.German -> R.string.ondato_language_de
            Language.Latvian -> R.string.ondato_language_lv
            Language.Estonian -> R.string.ondato_language_ee
            Language.Russian -> R.string.ondato_language_ru
            Language.Albanian -> R.string.ondato_language_sq
            Language.Bulgarian -> R.string.ondato_language_bg
            Language.Spanish -> R.string.ondato_language_es
            Language.French -> R.string.ondato_language_fr
            Language.Italian -> R.string.ondato_language_it
            Language.Romanian -> R.string.ondato_language_ro
            Language.Greek -> R.string.ondato_language_gr
            Language.Dutch -> R.string.ondato_language_nl
            Language.System -> R.string.ondato_language_system
        }
    }
}