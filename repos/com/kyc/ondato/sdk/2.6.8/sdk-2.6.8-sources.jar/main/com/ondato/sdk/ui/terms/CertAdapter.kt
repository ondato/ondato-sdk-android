package com.ondato.sdk.ui.terms

import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView

internal class CertAdapter : RecyclerView.Adapter<CertViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CertViewHolder {
        return CertViewHolder.create(parent)
    }

    override fun onBindViewHolder(holder: CertViewHolder, position: Int) {
        holder.bind(Certificates.urls[position])
    }

    override fun getItemCount(): Int {
        return Certificates.urls.size
    }
}