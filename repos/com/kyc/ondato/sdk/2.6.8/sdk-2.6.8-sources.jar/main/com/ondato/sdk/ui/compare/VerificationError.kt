package com.ondato.sdk.ui.compare

import android.os.Parcelable
import com.ondato.sdk.R
import com.ondato.sdk.ui.error.ErrorMessage
import kotlinx.parcelize.Parcelize

@Parcelize
sealed class VerificationError(
    override val title: Int,
    override val message: Int
) : ErrorMessage, Parcelable {
    object PersonPhotoContainsFace : VerificationError(
        R.string.FailedRule_PersonPhotoContainsFace_title,
        R.string.FailedRule_PersonPhotoContainsFace_subtitle
    )

    object DocContainsFace : VerificationError(
        R.string.FailedRule_DocContainsFace_title,
        R.string.FailedRule_DocContainsFace_subtitle
    )

    object DocContainsMrz : VerificationError(
        R.string.FailedRule_DocContainsMrz_title,
        R.string.FailedRule_DocContainsMrz_subtitle
    )

    object PersonAndDocPhotoMatch : VerificationError(
        R.string.FailedRule_PersonAndDocPhotoMatch_title,
        R.string.FailedRule_PersonAndDocPhotoMatch_subtitle
    )

    object PersonAndDocPhotoMatchScoreTooHigh : VerificationError(
        R.string.FailedRule_PersonAndDocPhotoMatchScoreTooHigh_title,
        R.string.FailedRule_PersonAndDocPhotoMatchScoreTooHigh_subtitle
    )

    object DocExpireDateInFuture : VerificationError(
        R.string.FailedRule_DocExpireDateInFuture_title,
        R.string.FailedRule_DocExpireDateInFuture_subtitle
    )

    object PersonAndDocumentPersonCodeMatch : VerificationError(
        R.string.FailedRule_PersonAndDocumentPersonCodeMatch_title,
        R.string.FailedRule_PersonAndDocumentPersonCodeMatch_subtitle
    )

    object PersonFaceOrDocIsMonochrome : VerificationError(
        R.string.FailedRule_PersonFaceOrDocIsMonochrome_title,
        R.string.FailedRule_PersonFaceOrDocIsMonochrome_subtitle
    )

    object DocumentContainsBothSides : VerificationError(
        R.string.FailedRule_DocumentContainsBothSides_title,
        R.string.FailedRule_DocumentContainsBothSides_subtitle
    )

    object ContainsMultipleFaces : VerificationError(
        R.string.FailedRule_ContainsMultipleFaces_title,
        R.string.FailedRule_ContainsMultipleFaces_subtitle
    )

    object PersonFoundInComplyAdvantage : VerificationError(
        R.string.FailedRule_PersonFoundInComplyAdvantage_title,
        R.string.FailedRule_PersonFoundInComplyAdvantage_subtitle
    )

    object ContainsCelebrity : VerificationError(
        R.string.FailedRule_ContainsCelebrity_title,
        R.string.FailedRule_ContainsCelebrity_subtitle
    )

    object LostAndStolen : VerificationError(
        R.string.FailedRule_LostAndStolen_title,
        R.string.FailedRule_LostAndStolen_subtitle
    )
}