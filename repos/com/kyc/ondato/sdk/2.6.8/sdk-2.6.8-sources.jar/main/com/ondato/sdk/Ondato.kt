package com.ondato.sdk

import android.content.Context
import androidx.annotation.Keep
import com.ondato.sdk.OndatoConfig.Mode.TEST
import com.ondato.sdk.di.Injector
import com.ondato.sdk.enums.NFCScan
import com.ondato.sdk.log.Level
import com.ondato.sdk.log.LogListener
import com.ondato.sdk.log.Logger
import com.ondato.sdk.storage.CACHE
import com.ondato.sdk.ui.launcher.LauncherActivity
import org.koin.core.qualifier.named
import java.io.File

@Keep
object Ondato {
    private val sessionState = IdentificationSessionState(OndatoConfig.Builder().build())

    val config: OndatoConfig
        get() = sessionState.config

    private val cache by lazy { Injector.get().get<File>(File::class, named(CACHE)) }

    fun init(config: OndatoConfig) {
        sessionState.setPendingConfig(config)
    }

    fun startIdentification(context: Context, onResultListener: ResultListener) {
        when (val result = sessionState.start(LogListener, onResultListener)) {
            is IdentificationSessionState.StartResult.Rejected -> {
                onResultListener.onFailure(
                    result.requestedConfig.identityVerificationId,
                    OndatoError.SESSION_ALREADY_RUNNING,
                )
            }

            is IdentificationSessionState.StartResult.Started -> {
                try {
                    val sessionConfig = result.config
                    Injector.init(context, sessionConfig.mode)
                    Logger.setLevel(if (sessionConfig.mode == TEST) Level.Debug else Level.Production)
                    Logger.d("Config: $sessionConfig")
                    LauncherActivity.start(context)
                } catch (throwable: Throwable) {
                    sessionState.cancelStart(result.sessionId)
                    throw throwable
                }
            }
        }
    }

    fun disableNfc() {
        sessionState.updateCurrentConfig { it.copy(NFCScan = NFCScan.No) }
    }

    fun getLogs(): String {
        return Logger.get()
    }

    fun onSuccess(identificationId: String) {
        completeSession { listener -> listener.onSuccess(identificationId) }
    }

    fun onError(identificationId: String, error: OndatoError) {
        completeSession { listener -> listener.onFailure(identificationId, error) }
    }

    internal fun updateActiveConfig(update: (OndatoConfig) -> OndatoConfig) {
        sessionState.updateActiveConfig(update)
    }

    private fun completeSession(notify: (ResultListener) -> Unit) {
        val completion = sessionState.beginCompletion() ?: return

        try {
            try {
                cache.deleteRecursively()
            } catch (exception: Exception) {
                Logger.d(exception, "Failed to clear the completed identification session cache")
            }

            notify.let { callback ->
                completion.listeners.forEach { listener ->
                    try {
                        callback(listener)
                    } catch (exception: Exception) {
                        Logger.d(exception, "Identification result listener failed")
                    }
                }
            }
        } finally {
            sessionState.complete(completion.sessionId)
        }
    }

    @Keep
    interface ResultListener {
        fun onSuccess(identificationId: String?)

        fun onFailure(identificationId: String?, error: OndatoError)
    }
}