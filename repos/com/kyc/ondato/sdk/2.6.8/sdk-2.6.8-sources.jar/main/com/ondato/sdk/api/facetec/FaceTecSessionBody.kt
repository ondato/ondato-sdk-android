package com.ondato.sdk.api.facetec

import com.google.gson.annotations.SerializedName

internal class FaceTecSessionBody(
    @SerializedName("sessionUserAgent") val sessionUserAgent: String,
)