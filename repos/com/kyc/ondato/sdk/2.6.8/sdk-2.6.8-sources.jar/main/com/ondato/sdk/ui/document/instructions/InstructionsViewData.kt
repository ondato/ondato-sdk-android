package com.ondato.sdk.ui.document.instructions

import androidx.annotation.DrawableRes
import androidx.annotation.StringRes
import com.ondato.sdk.R
import com.ondato.sdk.ui.utils.dp

internal data class InstructionsViewData(
    @StringRes val titleResId: Int,
    @StringRes val descriptionResId: Int,
    @DrawableRes val imageResId: Int,
    val imageMarginTop: Int = 36.dp,
    val imageMarginBottom: Int = 46.dp,
    val imageMarginLeft: Int = 46.dp,
    val imageMarginRight: Int = 46.dp,
    @StringRes val firstMistakeDescResId: Int = R.string.ondato_capture_instructions_too_blurry,
    @StringRes val secondMistakeDescResId: Int = R.string.ondato_capture_instructions_too_small,
    @StringRes val thirdMistakeDescResId: Int = R.string.ondato_capture_instructions_too_dark,
    @DrawableRes val firstMistakeImageResId: Int,
    @DrawableRes val secondMistakeImageResId: Int,
    @DrawableRes val thirdMistakeImageResId: Int
)
