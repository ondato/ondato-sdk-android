package com.ondato.sdk.usecase.deviceinfo

internal interface DeviceModelProvider {
    suspend fun get(): String
}