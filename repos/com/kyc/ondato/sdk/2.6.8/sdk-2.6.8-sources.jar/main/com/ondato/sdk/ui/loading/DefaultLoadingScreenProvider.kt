package com.ondato.sdk.ui.loading

import androidx.fragment.app.Fragment
import com.ondato.sdk.screen.LoadingScreenProvider

internal object DefaultLoadingScreenProvider : LoadingScreenProvider {
    override fun get(): Fragment {
        return OndatoLoadingFragment.newInstance()
    }
}