package com.ondato.sdk.ui.identification.result

import com.ondato.sdk.usecase.identification.Status

internal class IdentificationResultParameters {

    private var status: Status.Finished? = null

    @Synchronized
    fun set(status: Status.Finished) {
        this.status = status
    }

    @Synchronized
    fun take(): Status.Finished? {
        val status = status
        this.status = null
        return status
    }
}