package com.ondato.sdk.usecase.session.token

data class Token(
    val token: String,
    val type: String = "Bearer",
    val expiresIn: Long = -1
) {
    companion object {
        internal val EMPTY = Token("", "", -1)
    }
}