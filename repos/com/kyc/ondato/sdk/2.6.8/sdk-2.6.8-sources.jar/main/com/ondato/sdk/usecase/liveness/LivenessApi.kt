package com.ondato.sdk.usecase.liveness

import com.ondato.sdk.api.facetec.ActiveLivenessCheckBody
import com.ondato.sdk.api.facetec.PassiveLivenessCheckBody

internal interface LivenessApi {

    suspend fun sendPassiveCheck(kycId: String, body: PassiveLivenessCheckBody)

    suspend fun sendActiveCheck(kycId: String, body: ActiveLivenessCheckBody)

    suspend fun sendFaceAuth(kycId: String, body: ActiveLivenessCheckBody)
}