package com.ondato.sdk.api.restart

import com.ondato.sdk.api.BackendApi
import com.ondato.sdk.usecase.session.identification.RestartIdentificationApi

internal class RestartIdentificationApiService(
    private val api: BackendApi,
) : RestartIdentificationApi {

    override suspend fun restartIdentification(kycId: String) {
        api.retryIdentification(kycId)
    }
}