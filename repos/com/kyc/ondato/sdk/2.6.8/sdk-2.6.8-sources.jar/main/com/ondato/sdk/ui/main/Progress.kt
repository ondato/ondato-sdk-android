package com.ondato.sdk.ui.main

internal object Progress {
    fun resolve(step: Step): Int {
        return if (step == Step.FINISH) {
            100
        } else {
            (step.order / (Step.values().size.toFloat() - 1) * 100).toInt()
        }
    }
}