package com.ondato.sdk.ui.liveness.active

import com.facetec.sdk.FaceTecSessionResult
import com.facetec.sdk.FaceTecSessionStatus.*
import com.ondato.sdk.api.facetec.FaceTecApiService
import com.ondato.sdk.error.BadRequestException
import com.ondato.sdk.log.Event
import com.ondato.sdk.log.Logger
import com.ondato.sdk.ui.base.BaseViewModel
import com.ondato.sdk.ui.base.call
import com.ondato.sdk.ui.base.event
import com.ondato.sdk.ui.base.set
import com.ondato.sdk.ui.liveness.active.LivenessError.InternalSdkError
import com.ondato.sdk.ui.photo.PhotoScreenData
import com.ondato.sdk.usecase.savephoto.LivenessMode
import com.ondato.sdk.usecase.savephoto.Mode

internal class FaceTecViewModel(
    private val faceTecService: FaceTecApiService,
) : BaseViewModel() {

    val completed by event<Unit>()
    val failed by event<LivenessError>()

    private var mode: LivenessMode = LivenessMode.Liveness

    fun init(mode: LivenessMode) {
        this.mode = mode
    }

    fun onFaceTecResult(result: FaceTecSessionResult) {
        Logger.d("FaceTec session result : ${result.status}")
        when (result.status) {
            SESSION_COMPLETED_SUCCESSFULLY -> checkLiveness(result)
            SESSION_UNSUCCESSFUL,
            ENCRYPTION_KEY_INVALID,
            UNKNOWN_INTERNAL_ERROR,
            LANDSCAPE_MODE_NOT_ALLOWED,
            REVERSE_PORTRAIT_NOT_ALLOWED,
            LOCKED_OUT,
            MISSING_GUIDANCE_IMAGES,
            NON_PRODUCTION_MODE_KEY_INVALID,
            NON_PRODUCTION_MODE_NETWORK_REQUIRED -> failed.set(InternalSdkError(result.status))
            else -> failed.set(LivenessError.Canceled)
        }
    }

    private fun checkLiveness(result: FaceTecSessionResult) {
        Logger.log(Event.FaceTaken)
        launch {
            try {
                if (mode == LivenessMode.Liveness) {
                    faceTecService.uploadFacePhoto(result)
                } else {
                    faceTecService.uploadFaceAuthPhoto(result)
                }
                Logger.log(Event.FaceFound)
                completed.call()
            } catch (exception: Exception) {
                Logger.d(exception, "Liveness upload error @ ${this::class.simpleName}")
                if (exception is BadRequestException) {
                    if (exception.error?.json?.contains("MaxAttemptsReached") == true) {
                        failed.set(LivenessError.MaxAttemptsReached)
                    } else {
                        failed.set(LivenessError.FaceNotFount)
                    }
                } else {
                    failed.set(LivenessError.Canceled)
                }
            }
        }
    }
}