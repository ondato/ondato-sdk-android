package com.ondato.sdk

/**
 * Keeps configuration prepared by [Ondato.init] separate from the immutable identity of the
 * currently running session.
 *
 * A host may prepare the next configuration while a session is running. That pending
 * configuration becomes active only after the current session completes and the host calls
 * start again.
 */
internal class IdentificationSessionState<Config>(initialConfig: Config) {
    private val lock = Any()

    private var pendingConfig = initialConfig
    private var activeSession: ActiveSession<Config>? = null
    private var nextSessionId = 0L

    val config: Config
        get() = synchronized(lock) { activeSession?.config ?: pendingConfig }

    fun setPendingConfig(config: Config) {
        synchronized(lock) {
            pendingConfig = config
        }
    }

    fun start(vararg listeners: Ondato.ResultListener): StartResult<Config> {
        synchronized(lock) {
            if (activeSession != null) {
                return StartResult.Rejected(pendingConfig)
            }

            val sessionId = ++nextSessionId
            val sessionConfig = pendingConfig
            activeSession = ActiveSession(
                id = sessionId,
                config = sessionConfig,
                listeners = listeners.distinct(),
            )
            return StartResult.Started(sessionId, sessionConfig)
        }
    }

    fun cancelStart(sessionId: Long) {
        synchronized(lock) {
            if (activeSession?.id == sessionId) {
                activeSession = null
            }
        }
    }

    fun updateActiveConfig(update: (Config) -> Config) {
        synchronized(lock) {
            activeSession?.let { session ->
                session.config = update(session.config)
            }
        }
    }

    fun updateCurrentConfig(update: (Config) -> Config) {
        synchronized(lock) {
            val session = activeSession
            if (session == null) {
                pendingConfig = update(pendingConfig)
            } else {
                session.config = update(session.config)
            }
        }
    }

    fun beginCompletion(): Completion? {
        synchronized(lock) {
            val session = activeSession ?: return null
            if (session.isCompleting) return null

            session.isCompleting = true
            return Completion(session.id, session.listeners)
        }
    }

    fun complete(sessionId: Long) {
        synchronized(lock) {
            if (activeSession?.id == sessionId) {
                activeSession = null
            }
        }
    }

    private data class ActiveSession<Config>(
        val id: Long,
        var config: Config,
        val listeners: List<Ondato.ResultListener>,
        var isCompleting: Boolean = false,
    )

    sealed class StartResult<out Config> {
        data class Started<Config>(
            val sessionId: Long,
            val config: Config,
        ) : StartResult<Config>()

        data class Rejected<Config>(
            val requestedConfig: Config,
        ) : StartResult<Config>()
    }

    data class Completion(
        val sessionId: Long,
        val listeners: List<Ondato.ResultListener>,
    )
}
