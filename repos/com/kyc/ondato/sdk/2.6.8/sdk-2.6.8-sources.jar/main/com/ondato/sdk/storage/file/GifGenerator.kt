package com.ondato.sdk.storage.file

import android.graphics.Bitmap
import com.ondato.sdk.usecase.savephoto.Mode.Selfie
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import kotlin.coroutines.CoroutineContext

internal class GifGenerator(
    private val bitmapFactory: BitmapFactory = BitmapFactory(),
    private val context: CoroutineContext = Dispatchers.IO
) {

    suspend fun saveAsGif(frames: List<ByteArray>, target: File) = withContext(context) {
        val outStream = FileOutputStream(target)
        val bitmaps = frames.map { bitmapFactory.create(it, Selfie, 480) }
        outStream.write(generateGIF(bitmaps))
        outStream.flush()
        outStream.close()
        bitmaps.forEach { bitmap -> bitmap.recycle() }
    }

    private fun generateGIF(bitmaps: List<Bitmap>): ByteArray {
        val bos = ByteArrayOutputStream()
        val encoder = AnimatedGifEncoder()
        encoder.start(bos)
        encoder.setRepeat(0)
        encoder.setDelay(100)
        bitmaps.forEach(encoder::addFrame)
        encoder.finish()
        return bos.toByteArray()
    }
}