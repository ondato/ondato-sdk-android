package com.ondato.sdk.ui.main

import com.ondato.sdk.Ondato
import com.ondato.sdk.OndatoConfig
import com.ondato.sdk.OndatoError
import com.ondato.sdk.OndatoError.BAD_SERVER_RESPONSE
import com.ondato.sdk.OndatoError.CANCELED
import com.ondato.sdk.OndatoError.NO_AVAILABLE_DOCUMENT_TYPES
import com.ondato.sdk.enums.NFCScan
import com.ondato.sdk.log.Event
import com.ondato.sdk.log.Logger
import com.ondato.sdk.ui.base.BaseViewModel
import com.ondato.sdk.ui.base.call
import com.ondato.sdk.ui.base.event
import com.ondato.sdk.ui.base.set
import com.ondato.sdk.ui.base.state
import com.ondato.sdk.ui.compare.getMainError
import com.ondato.sdk.ui.compare.isCritical
import com.ondato.sdk.ui.error.ErrorMessage
import com.ondato.sdk.ui.liveness.active.LivenessError
import com.ondato.sdk.ui.main.Failure.IdentificationFailure
import com.ondato.sdk.ui.main.Failure.LiveCheckFailure
import com.ondato.sdk.ui.main.Failure.MrzScanFailure
import com.ondato.sdk.ui.main.Failure.NfcScanFailure
import com.ondato.sdk.ui.main.Failure.NfcScanTryAlternative
import com.ondato.sdk.ui.main.Failure.NfcSettingCancelled
import com.ondato.sdk.ui.main.Failure.RecordUploadFailure
import com.ondato.sdk.ui.main.Failure.RecordingNotFoundFailure
import com.ondato.sdk.ui.main.Failure.StartFailure
import com.ondato.sdk.ui.main.Failure.TermsFailure
import com.ondato.sdk.ui.main.Failure.VerificationFailure
import com.ondato.sdk.ui.main.Failure.WaitingFailure
import com.ondato.sdk.ui.main.Step.CAPTURE_DOCUMENT_BACK_INSTRUCTIONS
import com.ondato.sdk.ui.main.Step.CAPTURE_DOCUMENT_FRONT_INSTRUCTIONS
import com.ondato.sdk.ui.main.Step.CAPTURE_DOCUMENT_MRZ_INSTRUCTIONS
import com.ondato.sdk.ui.main.Step.CAPTURE_DOCUMENT_NFC_INSTRUCTIONS
import com.ondato.sdk.ui.main.Step.CAPTURE_FACE_INSTRUCTIONS
import com.ondato.sdk.ui.main.Step.CAPTURE_POA
import com.ondato.sdk.ui.main.Step.CAPTURE_POA_INSTRUCTIONS
import com.ondato.sdk.ui.main.Step.CAPTURE_SELFIE_WITH_DOCUMENT_INSTRUCTIONS
import com.ondato.sdk.ui.main.Step.FACE_AUTH
import com.ondato.sdk.ui.main.Step.FACE_AUTH_SUCCESS
import com.ondato.sdk.ui.main.Step.FAILURE_NFC
import com.ondato.sdk.ui.main.Step.FINISH
import com.ondato.sdk.ui.main.Step.FORCE_START
import com.ondato.sdk.ui.main.Step.IDENTIFICATION_WAITING_PAGE
import com.ondato.sdk.ui.main.Step.IDENTIFICATION_WAITING_PAGE_RESULT
import com.ondato.sdk.ui.main.Step.INITIALIZE
import com.ondato.sdk.ui.main.Step.MRZ_FAILURE
import com.ondato.sdk.ui.main.Step.NFC_NOT_ALLOWED
import com.ondato.sdk.ui.main.Step.SCAN_MRZ
import com.ondato.sdk.ui.main.Step.SCAN_NFC
import com.ondato.sdk.ui.main.Step.SELECT_DOCUMENT
import com.ondato.sdk.ui.main.Step.SELECT_POA_METHOD
import com.ondato.sdk.ui.main.Step.START
import com.ondato.sdk.ui.main.Step.SUCCESS
import com.ondato.sdk.ui.main.Step.TAKE_DOCUMENT_BACK
import com.ondato.sdk.ui.main.Step.TAKE_DOCUMENT_FRONT
import com.ondato.sdk.ui.main.Step.TAKE_FACE
import com.ondato.sdk.ui.main.Step.TAKE_SELFIE_WITH_DOCUMENT
import com.ondato.sdk.ui.main.Step.TERMS
import com.ondato.sdk.ui.main.Step.UPLOAD_POA
import com.ondato.sdk.usecase.document.DocumentPart
import com.ondato.sdk.usecase.document.DocumentType
import com.ondato.sdk.usecase.session.CompleteSessionUseCase
import com.ondato.sdk.usecase.session.DocumentTypeInfo
import com.ondato.sdk.usecase.session.Session

internal class MainViewModel(
    private val session: Session,
    private val stepResolver: StepResolver,
    private val completeSessionUseCase: CompleteSessionUseCase
) : BaseViewModel() {
    private lateinit var config: OndatoConfig

    val step by state(INITIALIZE)
    val cancel by event<OndatoError>()
    val success by event<Unit>()
    val retry by event<Unit>()
    val restart by event<Unit>()
    val abort by event<Unit>()
    val interrupted by event<Unit>()

    fun init(config: OndatoConfig) {
        this.config = config

        if (stepResolver.steps.isEmpty()) {
            stepResolver.generateSteps()
        }

        if (stepResolver.steps.isEmpty()) {
            cancel.set(BAD_SERVER_RESPONSE)
        }
    }

    // If process went to settings to enable NFC then do not cancel.
    // Also do not cancel when app goes into background when file picker was opened in upload screen
    fun onStop() {
//        val step = step.value.order
//        if (step != CAPTURE_DOCUMENT_NFC_INSTRUCTIONS.order && step != UPLOAD_POA.order) {
//            cancel.set(CANCELED)
//        }
    }

    fun onStepSuccess(step: Step) {
        when (step) {
            CAPTURE_DOCUMENT_BACK_INSTRUCTIONS -> this.step.set(TAKE_DOCUMENT_BACK)
            CAPTURE_DOCUMENT_FRONT_INSTRUCTIONS -> this.step.set(TAKE_DOCUMENT_FRONT)
            CAPTURE_DOCUMENT_MRZ_INSTRUCTIONS -> this.step.set(SCAN_MRZ)
            CAPTURE_DOCUMENT_NFC_INSTRUCTIONS -> this.step.set(SCAN_NFC)
            CAPTURE_POA_INSTRUCTIONS -> this.step.set(CAPTURE_POA)
            CAPTURE_SELFIE_WITH_DOCUMENT_INSTRUCTIONS -> this.step.set(TAKE_SELFIE_WITH_DOCUMENT)
            IDENTIFICATION_WAITING_PAGE -> this.step.set(IDENTIFICATION_WAITING_PAGE_RESULT)
            IDENTIFICATION_WAITING_PAGE_RESULT -> this.step.set(FINISH)
            FAILURE_NFC -> this.step.set(SCAN_NFC)
            Step.TOO_MANY_ATTEMPTS -> {
                launch {
                    completeSessionUseCase.abort()
                }
                cancel.set(OndatoError.TOO_MANY_ATTEMPTS)
            }
            FACE_AUTH -> {
                launch {
                    completeSessionUseCase.complete()
                }
                this.step.set(FACE_AUTH_SUCCESS)
            }
            else -> {
                if (step == SELECT_DOCUMENT && session.selectedType == DocumentType.IdCard && Ondato.config.NFCScan != NFCScan.No) {
                    this.step.set(CAPTURE_DOCUMENT_FRONT_INSTRUCTIONS)
                    return
                }

                if (step.order == this.step.value.order || step == SCAN_NFC) {
                    var nextStep = stepResolver.nextStep()
                    if (session.selectedType == DocumentType.Passport && nextStep == Step.CAPTURE_DOCUMENT_BACK_INSTRUCTIONS) {
                        nextStep = stepResolver.nextStep()
                    }

                    Logger.d("Step from: ${step.order} to ${nextStep.order}")
                    this.step.set(nextStep)
                } else {
                    Logger.d("Step mismatch: ${step.order} | ${this.step.value.order} ")
                }
            }
        }
    }

    fun onShowInfo() {
        when (this.step.value) {
            TAKE_DOCUMENT_FRONT -> this.step.set(CAPTURE_DOCUMENT_FRONT_INSTRUCTIONS)
            TAKE_DOCUMENT_BACK -> this.step.set(CAPTURE_DOCUMENT_BACK_INSTRUCTIONS)
            TAKE_SELFIE_WITH_DOCUMENT -> this.step.set(CAPTURE_SELFIE_WITH_DOCUMENT_INSTRUCTIONS)
            CAPTURE_POA -> this.step.set(CAPTURE_POA_INSTRUCTIONS)
            else -> return
        }
    }

    fun onNextStep(nextStep: Step) {
        Logger.d("Step next from: ${this.step.value.order} to ${nextStep.order}")
        this.step.set(nextStep)
    }

    fun onStepFailed(failure: Failure?) {
        when (failure) {
            is VerificationFailure -> handleVerificationError(failure)
            is LiveCheckFailure -> handleLivenessCheckFailure(failure)
            is TermsFailure -> handleTermsFailure(failure)
            is WaitingFailure -> handleWaitingFailure(failure)
            is RecordUploadFailure -> handleRecordUploadFailure(failure)
            is RecordingNotFoundFailure -> handleRecordingNotFoundFailure(failure)
            is IdentificationFailure -> handleIdentificationFailure(failure)
            is MrzScanFailure -> handleMrzScanFailure()
            is NfcScanFailure -> handleNfcScanFailure()
            is NfcScanTryAlternative -> handleNfcAlternativeNextPage()
            is NfcSettingCancelled -> handleNfcSettingsCancelled()
            StartFailure -> handleStartFailure()
            else -> {
                // do nothing
            }
        }.javaClass
    }

    private fun handleStartFailure() {
        step.set(NFC_NOT_ALLOWED)
    }

    fun onBackClicked() {
        val destination = stepResolver.getPreviousStep()
        val currentStepResolverStep = stepResolver.getCurrentStep()
        val currentStep = this.step.value
        val allSteps = stepResolver.steps
        when (currentStep) {
            SCAN_MRZ -> this.step.set(CAPTURE_DOCUMENT_MRZ_INSTRUCTIONS)
            SCAN_NFC -> this.step.set(CAPTURE_DOCUMENT_NFC_INSTRUCTIONS)
            TAKE_DOCUMENT_FRONT -> this.step.set(CAPTURE_DOCUMENT_FRONT_INSTRUCTIONS)
            TAKE_DOCUMENT_BACK -> this.step.set(CAPTURE_DOCUMENT_BACK_INSTRUCTIONS)
            TAKE_FACE -> this.step.set(CAPTURE_FACE_INSTRUCTIONS)
            TAKE_SELFIE_WITH_DOCUMENT -> this.step.set(CAPTURE_SELFIE_WITH_DOCUMENT_INSTRUCTIONS)
            CAPTURE_POA -> this.step.set(CAPTURE_POA_INSTRUCTIONS)
            CAPTURE_POA_INSTRUCTIONS -> this.step.set(SELECT_POA_METHOD)
            UPLOAD_POA -> this.step.set(SELECT_POA_METHOD)
            else -> {

                when (destination) {
                    TERMS -> {
                        if (this.step.value.order < 2) {
                            this.step.set(stepResolver.previousStep())
                        } else {
                            cancel.set(CANCELED)
                        }
                    }

                    START -> {
                        if (this.step.value.order < 2) {
                            this.step.set(stepResolver.previousStep())
                        } else {
                            cancel.set(CANCELED)
                        }
                    }

                    SELECT_DOCUMENT -> {
                        this.step.set(stepResolver.previousStep())
                    }

                    else -> {
                        when (this.step.value) {
                            FACE_AUTH,
                            IDENTIFICATION_WAITING_PAGE,
                            IDENTIFICATION_WAITING_PAGE_RESULT -> cancel.set(CANCELED)

                            SUCCESS -> {}
                            else -> {
                                if (stepResolver.currentStep == 0) {
                                    cancel.set(CANCELED)
                                } else {
                                    this.step.set(stepResolver.previousStep())
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    fun onRetryClicked() {
        retry.call()
        hideError.call()
    }

    fun onContinueAnywayClicked() {
        hideError.call()
        val nextStep = stepResolver.nextStep()
        Logger.d("Step from: ${TAKE_FACE.order} to ${nextStep?.order}")
        nextStep?.let(step::set) ?: cancel.set(NO_AVAILABLE_DOCUMENT_TYPES)
    }

    fun handleTryAgain() {
        stepResolver.restart()
        step.set(SELECT_DOCUMENT)
    }

    suspend fun completeSession() = completeSessionUseCase.complete()

    private fun handleVerificationError(failure: VerificationFailure) {
        val error = failure.errors.getMainError()
        if (error == null || error.isCritical()) {
            Logger.d("Verification failed, restarting")
            step.set(FORCE_START)
        } else {
            Logger.d("Verification failed, selecting document")
            step.set(SELECT_DOCUMENT)
        }
        showErrorMessage(error)
    }

    private fun handleLivenessCheckFailure(failure: LiveCheckFailure) {
        if (failure.error is LivenessError.Canceled) {
            cancel.set(CANCELED)
        } else if (failure.error is LivenessError.MaxAttemptsReached) {
            this.step.set(Step.TOO_MANY_ATTEMPTS)
        } else {
//          Current flow: Retry face scan if FaceTec fails either on frontend or backend
//          Don't allow for user to proceed until he succeeds in scanning his face

//          Note: During app runtime when app in debug mode with debugger attached,
//          FaceTec validation succeeds on frontend but when captured face data is passed to backend,
//          then face validation fails and we receive an API ERROR response. For that reason,
//          this feature should be tested without debugger attached

//          Since retry is being handled in FaceTecUi.kt, for now all we do here is logging
            Logger.log(Event.FaceNotFound)
            Logger.d("Liveness check failed, restarting")

//            Old flows:

//            Continue with the step flow even if there are face scan errors
//            onContinueAnywayClicked()

//            Ignore liveness check error based on config and restart the whole step flow
//            showErrorMessage(failure.error as? ErrorMessage, config.ignoreLivenessErrors)
//            step.set(FORCE_START)
        }
    }

    private fun handleWaitingFailure(failure: WaitingFailure) {
        //todo implement error handling
        Logger.d("Waiting failed")
        step.set(FORCE_START)
    }

    private fun handleNfcAlternativeNextPage() {
        Logger.d("Nfc failure continue")
        Ondato.disableNfc()
        session.availableDocumentTypes = session.availableDocumentTypes.map { typeInfo ->
            val nfcDisabledParts = typeInfo.parts.map { part ->
                if (part == DocumentPart.DataPage) DocumentPart.Front else part
            }
            DocumentTypeInfo(typeInfo.type, nfcDisabledParts)
        }

        stepResolver.disableNfc()
        step.set(SELECT_DOCUMENT)
        session.currentPart = -1

//        val nextStep = session.selectedType?.let { selectedType ->
//            session.availableDocumentTypes.find { it.type == selectedType }
//                ?.parts?.firstOrNull()?.toStep()
//        }
//        if (nextStep == null) {
//            step.set(SELECT_DOCUMENT)
//            session.currentPart = -1
//        } else {
//            session.currentPart = 0
//            step.set(nextStep)
//        }
    }

    private fun handleNfcSettingsCancelled() {
        Logger.d("Nfc setting cancelled")
        step.set(NFC_NOT_ALLOWED)
    }

    private fun handleTermsFailure(failure: TermsFailure) {
        launch {
            completeSessionUseCase.abort()
            abort.call()
            onBackClicked()
        }
    }

    private fun handleRecordUploadFailure(failure: RecordUploadFailure) {
        //todo show error message
        Logger.d(failure.cause, "Record upload failed")

        restart.call()
    }

    private fun handleRecordingNotFoundFailure(failure: RecordingNotFoundFailure) {
        Logger.d("Recording not found")
        interrupted.call()
    }

    private fun handleIdentificationFailure(failure: IdentificationFailure) {
        Logger.d("Identification failed confirmed")
        if (failure.tryAgain) {
            restart.call()
        } else {
            cancel.set(CANCELED)
        }
    }

    private fun handleNfcScanFailure() {
        Logger.d("Nfc scan failed confirmed")
        step.set(FAILURE_NFC)
    }

    private fun handleMrzScanFailure() {
        Logger.d("Mrz scan failed confirmed")
        step.set(MRZ_FAILURE)
    }

    private fun showErrorMessage(error: ErrorMessage?, canContinue: Boolean = false) {
        error?.let { message -> showError.set(ErrorConfig(message, canContinue)) }
    }
}