package com.ondato.sdk.screen

import androidx.annotation.Keep
import androidx.fragment.app.Fragment

@Keep
fun interface SuccessScreenProvider {
    fun get(callback: SuccessScreenCallback): Fragment
}