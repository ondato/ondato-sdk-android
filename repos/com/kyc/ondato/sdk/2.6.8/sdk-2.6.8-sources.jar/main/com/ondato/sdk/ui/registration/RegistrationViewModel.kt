package com.ondato.sdk.ui.registration

import com.ondato.sdk.api.registration.RegistrationRequest
import com.ondato.sdk.ui.base.BaseViewModel
import com.ondato.sdk.ui.base.event
import com.ondato.sdk.ui.base.set
import com.ondato.sdk.usecase.registration.RegistrationUseCase

internal class RegistrationViewModel(
    private val registrationUseCase: RegistrationUseCase,
) : BaseViewModel() {

    val registrationSuccess by event<Unit>()

    fun sendRegistration(registrationRequest: List<RegistrationRequest>) {
        launch {
            registrationUseCase.sendRegistration(registrationRequest)
            registrationSuccess.set(Unit)
        }
    }
}