package com.ondato.sdk.screen

import androidx.annotation.Keep
import androidx.fragment.app.Fragment

@Keep
fun interface LoadingScreenProvider {
    fun get(): Fragment
}