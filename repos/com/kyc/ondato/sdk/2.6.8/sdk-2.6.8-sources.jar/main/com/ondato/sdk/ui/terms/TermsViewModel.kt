package com.ondato.sdk.ui.terms

import com.ondato.sdk.log.Event
import com.ondato.sdk.log.Logger
import com.ondato.sdk.ui.base.BaseViewModel
import com.ondato.sdk.ui.base.call
import com.ondato.sdk.ui.base.event
import com.ondato.sdk.usecase.session.Session

internal class TermsViewModel(
    private val session: Session
) : BaseViewModel() {
    val success by event<Unit>()
    val failed by event<Unit>()

    fun onTermsAccepted() {
        session.areTermsAgreed = true
        success.call()
        Logger.log(Event.TermsAgreed)
    }

    fun onTermsDenied() {
        session.areTermsAgreed = false
        failed.call()
        Logger.log(Event.TermsDisagreed)
    }
}