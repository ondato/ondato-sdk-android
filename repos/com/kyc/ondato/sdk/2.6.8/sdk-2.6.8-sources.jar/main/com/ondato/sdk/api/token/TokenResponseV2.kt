package com.ondato.sdk.api.token

import androidx.annotation.Keep

@Keep
internal class TokenResponseV2 {
    var accessToken: String? = null
    var tokenType: String? = null
}