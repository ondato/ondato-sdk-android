package com.ondato.sdk.api.facetec

import com.facetec.sdk.FaceTecSDK.createFaceTecAPIUserAgentString
import com.facetec.sdk.FaceTecSessionResult
import com.ondato.sdk.api.BackendApi
import com.ondato.sdk.usecase.liveness.FaceTecApi
import com.ondato.sdk.usecase.liveness.LivenessLicenseInfo
import com.ondato.sdk.usecase.liveness.active.ActiveLivenessCheckUseCase

internal class FaceTecApiService(
    private val backendApi: BackendApi,
    private val activeLivenessCheckUseCase: ActiveLivenessCheckUseCase,
) : FaceTecApi {

    override suspend fun getLicenseInfo(): LivenessLicenseInfo {
        return backendApi.getLivenessLicenseInfo().toLivenessLicenseInfo()
    }

    override suspend fun getSessionToken(): String {
        return backendApi.getLivenessToken().sessionToken ?: ""
    }

    override suspend fun uploadFacePhoto(sessionResult: FaceTecSessionResult) {
        activeLivenessCheckUseCase.check(
            sessionResult.sessionId ?: "",
            sessionResult.faceScanBase64,
            createFaceTecAPIUserAgentString(sessionResult.sessionId ?: ""),
            sessionResult.auditTrailCompressedBase64.toList(),
            sessionResult.lowQualityAuditTrailCompressedBase64.toList(),
        )
    }

    override suspend fun uploadFaceAuthPhoto(sessionResult: FaceTecSessionResult) {
        val firstPhoto = sessionResult.auditTrailCompressedBase64.toList().first()
        val faceList = listOf(firstPhoto)
        val sessionId = sessionResult.sessionId
        activeLivenessCheckUseCase.checkFaceAuth(
            sessionId ?: "",
            sessionResult.faceScanBase64,
            createFaceTecAPIUserAgentString(sessionResult.sessionId ?: ""),
            faceList,
            sessionResult.lowQualityAuditTrailCompressedBase64.toList(),
        )
    }
}