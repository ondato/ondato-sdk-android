package com.ondato.sdk.ui.compare

import com.ondato.sdk.OndatoConfig
import com.ondato.sdk.log.Event
import com.ondato.sdk.log.Logger
import com.ondato.sdk.ui.base.BaseViewModel
import com.ondato.sdk.ui.base.call
import com.ondato.sdk.ui.base.event
import com.ondato.sdk.ui.base.set
import com.ondato.sdk.ui.main.Failure
import com.ondato.sdk.usecase.session.CompleteSessionUseCase
import com.ondato.sdk.usecase.upload.RecordUploadException
import com.ondato.sdk.usecase.upload.RecordingNotFoundException

internal class CompareViewModel(
    private val completeSessionUseCase: CompleteSessionUseCase,
) : BaseViewModel() {

    val success by event<Unit>()
    val failed by event<Failure>()
    val invokeScreenRecordingUpload by event<Unit>()

    fun init(config: OndatoConfig) {
        launch {
            // If there is a screen recording that needs to be uploaded, the UI is handled via broadcasts on the MainActivity
            if (config.recordProcess) {
                invokeScreenRecordingUpload.call()
            } else {
                completeSessionUseCase.completeKYC()
                Logger.log(Event.IdentificationSuccess)
                success.call()
            }
        }
    }

    override fun handleError(error: Throwable) {
        if (error is RecordUploadException) {
            failed.set(Failure.RecordUploadFailure(error))
        } else if (error is RecordingNotFoundException) {
            failed.set(Failure.RecordingNotFoundFailure)
        } else {
            super.handleError(error)
        }
    }
}