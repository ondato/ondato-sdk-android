package com.ondato.sdk.api.token

import androidx.annotation.Keep

@Keep
internal class FullAccessTokenBody
