package com.ondato.sdk.ui.error

import com.ondato.sdk.error.*
import com.ondato.sdk.ui.main.ErrorConfig

internal object ErrorMessageMapper {

    fun map(throwable: Throwable): ErrorConfig {
        val error = when (throwable) {
            is NoNetworkException -> NetworkError
            is NotAuthorizedException -> UnauthorizedError
            is BadRequestException -> BadRequest
            is InternalServerErrorException -> ServerError
            is TimeoutException -> TimeoutError
            else -> GenericError
        }
        return ErrorConfig(error)
    }
}