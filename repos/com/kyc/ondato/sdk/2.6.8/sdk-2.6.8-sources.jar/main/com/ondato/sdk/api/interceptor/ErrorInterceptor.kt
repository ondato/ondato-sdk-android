package com.ondato.sdk.api.interceptor

import com.ondato.sdk.error.*
import com.ondato.sdk.log.Logger
import okhttp3.Interceptor
import okhttp3.Response
import java.io.IOException
import java.net.ConnectException
import java.net.SocketTimeoutException
import java.net.UnknownHostException

internal class ErrorInterceptor(
    private val errorMapper: ApiErrorMapper = ApiErrorMapper
) : Interceptor {

    override fun intercept(chain: Interceptor.Chain): Response {
        val request = chain.request()
        val url = request.url.toString()
        try {
            val response = chain.proceed(request)
            if (response.isSuccessful) {
                return response
            } else {
                val responseBody = response.body?.string()
                Logger.d("------ API ERROR ------")
                Logger.d("REQUEST: $request")
                Logger.d("RESPONSE: $response")
                Logger.d("RESPONSE Body: $responseBody")
                Logger.d("-----------------------")
                val error = errorMapper.map(responseBody)
                throw mapException(error, response, url)
            }
        } catch (cause: IOException) {
            throw getNetworkError(cause, url)
        }
    }

    private fun getNetworkError(cause: IOException, url: String): Throwable {
        return when (cause) {
            is ConnectException,
            is SocketTimeoutException,
            is UnknownHostException -> {
                NoNetworkException(cause = cause, message = url.asUrlMessage())
            }
            else -> cause
        }
    }

    private fun mapException(error: ApiError?, response: Response, url: String): Throwable {
        return when (response.code) {
            401 -> NotAuthorizedException(error, message = url.asUrlMessage())
            400 -> BadRequestException(error, message = url.asUrlMessage())
            522 -> TimeoutException(error, message = url.asUrlMessage())
            else -> InternalServerErrorException(error, message = url.asUrlMessage())
        }
    }

    private fun String.asUrlMessage(): String {
        return "url: $this"
    }
}