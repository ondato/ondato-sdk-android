package com.ondato.sdk.ui.start

import com.ondato.sdk.Ondato
import com.ondato.sdk.enums.Language
import com.ondato.sdk.enums.NFCScan
import com.ondato.sdk.ui.base.*
import com.ondato.sdk.usecase.session.Session

internal class StartViewModel(
    private val session: Session,
) : BaseViewModel() {
    val language by state<Language>()
    val changeLanguage by event<Language>()
    val isLanguagePickerVisible by state(false)
    val proceedNext by event<Unit>()
    val showNfcNotAvailable by event<Unit>()

    init {
        language.set(session.language)
    }

    fun onStartClicked(isNfcAvailable: Boolean) {
        val isNfcMode = Ondato.config.NFCScan != NFCScan.No
        when {
            isNfcMode && !isNfcAvailable -> showNfcNotAvailable.call()
            else -> proceedNext.call()
        }
    }

    fun onShowLanguagePickerClicked() {
        isLanguagePickerVisible.set(true)
    }

    fun onCloseLanguagePicketClicked() {
        isLanguagePickerVisible.set(false)
    }

    fun onLanguageClicked(languages: Language) {
        if (languages != session.language) {
            session.language = languages
            changeLanguage.set(languages)
        } else {
            isLanguagePickerVisible.set(false)
        }
    }
}