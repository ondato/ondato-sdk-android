package com.ondato.sdk.api.identification

import com.ondato.sdk.log.Logger
import com.ondato.sdk.usecase.identification.Identification
import com.ondato.sdk.usecase.identification.RejectedStatus
import com.ondato.sdk.usecase.identification.Status

internal object IdentificationMapper {

    fun map(identificationResponse: IdentificationResponse): Identification {
        return Identification(mapStatus(identificationResponse))
    }

    private fun mapStatus(statusDataResponse: IdentificationResponse): Status {
        return when (statusDataResponse.status) {
            StatusResponse.Awaiting -> Status.Awaiting
            StatusResponse.Approved -> Status.Finished.Success
            StatusResponse.Rejected -> {
                Status.Finished.Rejected(mapRejectedStatus(statusDataResponse.statusReason!!))
            }
            else -> Status.Awaiting
        }
    }

    private fun mapRejectedStatus(rejectedStatusResponse: RejectedStatusResponse): RejectedStatus {
        Logger.d("Identification rejection status: ${rejectedStatusResponse.name}")
        return when (rejectedStatusResponse) {
            RejectedStatusResponse.MissingDocumentPhoto -> RejectedStatus.MissingDocumentPhoto
            RejectedStatusResponse.DocumentNotAccepted -> RejectedStatus.DocumentNotAccepted
            RejectedStatusResponse.DataNotMatch -> RejectedStatus.DataNotMatch
            RejectedStatusResponse.Sanctioned -> RejectedStatus.Sanctioned
            RejectedStatusResponse.MissingPersonPhoto -> RejectedStatus.MissingPersonPhoto
            RejectedStatusResponse.FacesNotMatch -> RejectedStatus.FacesNotMatch
            RejectedStatusResponse.PoorPhotoQuality -> RejectedStatus.PoorPhotoQuality
            RejectedStatusResponse.PoorPhotoLighting -> RejectedStatus.PoorPhotoLighting
            RejectedStatusResponse.Miscellaneous -> RejectedStatus.MISCELLANEOUS
            RejectedStatusResponse.PossibleFraudAttempt -> RejectedStatus.PossibleFraudAttempt
            RejectedStatusResponse.UnrelatedPhotoSubmit -> RejectedStatus.UnrelatedPhotoSubmit
            RejectedStatusResponse.MoreThanOnePerson -> RejectedStatus.MoreThanOnePerson
            RejectedStatusResponse.ProhibitedCountryOrState -> RejectedStatus.ProhibitedCountryOrState
            RejectedStatusResponse.DocumentIsExpired -> RejectedStatus.DocumentIsExpired
            RejectedStatusResponse.DocumentWithNonLatinCharacters -> RejectedStatus.DocumentWithNonLatinCharacters
            RejectedStatusResponse.PartOfDocumentIsCovered -> RejectedStatus.PartOfDocumentIsCovered
            RejectedStatusResponse.PartOfFaceIsCovered -> RejectedStatus.PartOfFaceIsCovered
            RejectedStatusResponse.UnderagePerson -> RejectedStatus.UnderagePerson
            RejectedStatusResponse.ProhibitedNationality -> RejectedStatus.ProhibitedNationality
            RejectedStatusResponse.DuplicatedInfo -> RejectedStatus.DuplicatedInfo
            RejectedStatusResponse.FacePhotoUploadFormat -> RejectedStatus.FacePhotoUploadFormat
            RejectedStatusResponse.TransferToVideoCall -> RejectedStatus.TransferToVideoCall
            RejectedStatusResponse.Unfinished -> RejectedStatus.Unfinished
            RejectedStatusResponse.Processing -> RejectedStatus.Processing
            RejectedStatusResponse.AutomaticallyIdentified -> RejectedStatus.AutomaticallyIdentified
            RejectedStatusResponse.ManuallyIdentified -> RejectedStatus.ManuallyIdentified
        }
    }
}