package com.ondato.sdk.api.identification

import androidx.annotation.Keep
import com.google.gson.annotations.SerializedName

@Keep
internal data class IdentificationResponse(
    @SerializedName("status") val status: StatusResponse? = null,
    @SerializedName("statusReason") val statusReason: RejectedStatusResponse? = null,
)

@Keep
internal enum class StatusResponse {
    @SerializedName("Awaiting") Awaiting,
    @SerializedName("Approved") Approved,
    @SerializedName("Rejected") Rejected,
}

@Keep
internal enum class RejectedStatusResponse {
    @SerializedName("MissingDocumentPhoto") MissingDocumentPhoto,
    @SerializedName("DocumentNotAccepted") DocumentNotAccepted,
    @SerializedName("DataNotMatch") DataNotMatch,
    @SerializedName("Sanctioned") Sanctioned,
    @SerializedName("MissingPersonPhoto") MissingPersonPhoto,
    @SerializedName("FacesNotMatch") FacesNotMatch,
    @SerializedName("PoorPhotoQuality") PoorPhotoQuality,
    @SerializedName("PoorPhotoLighting") PoorPhotoLighting,
    @SerializedName("Miscellaneous") Miscellaneous,
    @SerializedName("PossibleFraudAttempt") PossibleFraudAttempt,
    @SerializedName("UnrelatedPhotoSubmit") UnrelatedPhotoSubmit,
    @SerializedName("MoreThanOnePerson") MoreThanOnePerson,
    @SerializedName("ProhibitedCountryOrState") ProhibitedCountryOrState,
    @SerializedName("DocumentIsExpired") DocumentIsExpired,
    @SerializedName("DocumentWithNonLatinCharacters") DocumentWithNonLatinCharacters,
    @SerializedName("PartOfDocumentIsCovered") PartOfDocumentIsCovered,
    @SerializedName("PartOfFaceIsCovered") PartOfFaceIsCovered,
    @SerializedName("UnderagePerson") UnderagePerson,
    @SerializedName("ProhibitedNationality") ProhibitedNationality,
    @SerializedName("DuplicatedInfo") DuplicatedInfo,
    @SerializedName("FacePhotoUploadFormat") FacePhotoUploadFormat,
    @SerializedName("TransferToVideoCall") TransferToVideoCall,
    @SerializedName("Unfinished") Unfinished,
    @SerializedName("Processing") Processing,
    @SerializedName("AutomaticallyIdentified") AutomaticallyIdentified,
    @SerializedName("ManuallyIdentified") ManuallyIdentified,
}