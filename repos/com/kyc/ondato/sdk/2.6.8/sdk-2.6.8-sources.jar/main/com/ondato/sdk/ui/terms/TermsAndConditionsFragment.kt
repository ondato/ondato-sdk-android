package com.ondato.sdk.ui.terms

import android.os.Bundle
import android.view.View
import androidx.recyclerview.widget.RecyclerView
import com.ondato.sdk.R
import com.ondato.sdk.log.Event
import com.ondato.sdk.log.Logger
import com.ondato.sdk.ui.base.BaseFragment
import com.ondato.sdk.ui.main.Failure
import com.ondato.sdk.ui.main.MainViewModel
import com.ondato.sdk.ui.main.Step
import org.koin.androidx.viewmodel.ext.android.sharedViewModel
import org.koin.androidx.viewmodel.ext.android.viewModel

internal class TermsAndConditionsFragment : BaseFragment(R.layout.ondato_fragment_terms) {
    private val mainViewModel: MainViewModel by sharedViewModel()
    private val viewModel: TermsViewModel by viewModel()
    private val adapter = CertAdapter()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        viewModel.success.observe { mainViewModel.onStepSuccess(Step.TERMS) }
        viewModel.failed.observe { mainViewModel.onStepFailed(Failure.TermsFailure) }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        R.id.certificatesRecycler.find<RecyclerView>()?.adapter = adapter
        R.id.acceptButton.onClick(viewModel::onTermsAccepted)
        R.id.declineButton.onClick(viewModel::onTermsDenied)
//        R.id.ondatoTermsScrollView.find<ScrollView>()?.onScrollToBottom(::enableButtons)
        if (savedInstanceState == null) Logger.log(Event.TermsShown)
    }

    private fun enableButtons() {
        R.id.acceptButton.view()?.isEnabled = true
        R.id.declineButton.view()?.isEnabled = true
    }

    companion object {
        fun newInstance(): TermsAndConditionsFragment {
            return TermsAndConditionsFragment()
        }
    }
}