package com.ondato.sdk.enums


import androidx.annotation.Keep
import com.ondato.sdk.ui.utils.LanguageUtils.getSystemLocale
import java.util.*

@Keep
enum class Language(
    val languageString: String,
    val country: String
) {
    English(Locale.ENGLISH.language, "EN"),
    Lithuanian("lt", "LT"),
    German(Locale.GERMAN.language, "DE"),
    Latvian("lv", "LV"),
    Estonian("et", "EE"),
    Russian("ru", "RU"),
    Albanian("sq", "AL"),
    Bulgarian("bg", "BG"),
    Spanish("es", "ES"),
    French("fr", "FR"),
    Italian("it", "IT"),
    Romanian("ro", "RO"),
    Greek("el", "GR"),
    Dutch("nl", "NL"),
    System(getSystemLocale().language, if (getSystemLocale().language.startsWith("en")) "EN" else getSystemLocale().country);

    companion object {
        fun of(languageString: String): Language {
            return values().firstOrNull { lang -> lang.languageString == languageString } ?: System
        }
    }
}