package com.ondato.sdk.api.logs

import com.ondato.sdk.api.BackendApi
import com.ondato.sdk.log.Log
import com.ondato.sdk.usecase.logs.LogsApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.coroutines.CoroutineContext

internal class LogsService(
    private val backEndApi: BackendApi,
    private val context: CoroutineContext = Dispatchers.IO
) : LogsApi {

    override suspend fun send(identificationId: String, logs: List<Log>) = withContext(context) {
        if (identificationId.isBlank()) throw IllegalStateException("Identification id is empty")
        if (logs.isNotEmpty()) {
            logs.map { backEndApi.sendLogs(identificationId, LogRequest(it.message)) }
        }
    }
}