package com.ondato.sdk.ui.waiting

import kotlin.concurrent.fixedRateTimer

internal class CountDown(private val formatter: TimeFormatter = TimeFormatter()) {
    private var isRunning = true

    fun start(from: Int, onTick: (String) -> Unit, onCompleted: () -> Unit) {
        var left = from
        fixedRateTimer(period = 1000L) {
            if (left >= 0) {
                onTick(formatter.format(left))
            } else {
                onCompleted()
            }

            if (left < 0 || !isRunning) cancel()
            left--
        }
    }

    fun stop() {
        isRunning = false
    }
}