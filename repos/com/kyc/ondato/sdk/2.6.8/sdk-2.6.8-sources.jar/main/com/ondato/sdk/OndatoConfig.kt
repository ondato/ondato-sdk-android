package com.ondato.sdk

import androidx.annotation.Keep
import com.ondato.sdk.enums.Language
import com.ondato.sdk.enums.LivenessCheck
import com.ondato.sdk.enums.NFCScan
import com.ondato.sdk.enums.NFCScan.No
import com.ondato.sdk.screen.LoadingScreenProvider
import com.ondato.sdk.screen.StartScreenProvider
import com.ondato.sdk.screen.SuccessScreenProvider
import com.ondato.sdk.ui.loading.DefaultLoadingScreenProvider
import com.ondato.sdk.ui.start.DefaultStartScreenProvider
import com.ondato.sdk.ui.success.DefaultSuccessScreenProvider

@Keep
data class OndatoConfig(
    val mode: Mode,
    val showSplashScreen: Boolean,
    val identityVerificationId: String = "",
    val showSuccess: Boolean, // turim confige?
    val language: Language, // turim confige?
    val showSelfieWithDocumentScreen: Boolean, // additionalDocument type SelfieWithDoc
    val showWaitingScreen: Boolean, // turim confige?
    val showTermsScreen: Boolean, // kyc setup steps Consent order != 0?
    val showStartScreen: Boolean, // turim confige?
    val recordProcess: Boolean, // recordProcess kyc setup sessionScreenRecording
    val removeSelfieFrame: Boolean, // turim confige?
    val showIdentificationWaitingPage: Boolean, // turim confige?
    val NFCScan: NFCScan, // config nfc type name:
    val isDriverLicenseBacksideRequired: Boolean,
    val loadingScreenProvider: LoadingScreenProvider,
    val startScreenProvider: StartScreenProvider,
    val successScreenProvider: SuccessScreenProvider,
    val livenessCheck: LivenessCheck,
    val skipRegistrationIfDriverLicense: Boolean, // turim confige
    ) {
    @Keep
    class Builder {
        private var identificationId: String = ""
        private var mode: Mode = Mode.TEST
        private var showSplash: Boolean = false
        private var language: Language = Language.English
        private var showSuccess: Boolean = false
        private var ignoreVerofocatopmErrors: Boolean = true
        private var showStartScreen: Boolean = true
        private var ignoreLivenessErrors: Boolean = false
        private var showSelfieWithDocumentScreen: Boolean = true
        private var showWaitingScreen: Boolean = false
        private var showTermsScreen: Boolean = true
        private var recordProcess: Boolean = false
        private var isDriverLicenseBacksideRequired: Boolean = false
        private var removeSelfieFrame: Boolean = false
        private var loadingScreenProvider: LoadingScreenProvider = DefaultLoadingScreenProvider
        private var startScreenProvider: StartScreenProvider = DefaultStartScreenProvider
        private var successScreenProvider: SuccessScreenProvider = DefaultSuccessScreenProvider
        private var livenessCheck: LivenessCheck = LivenessCheck.Active
        private var showIdentificationWaitingPage: Boolean = true
        private var NFCScan: NFCScan = No
        private var skipRegistrationIfDriverLicense: Boolean = false

        fun setLoadingScreenProvider(provider: LoadingScreenProvider): Builder {
            this.loadingScreenProvider = provider
            return this
        }

        fun setStartScreenProvider(provider: StartScreenProvider): Builder {
            this.startScreenProvider = provider
            return this
        }

        fun setSuccessScreenProvider(provider: SuccessScreenProvider): Builder {
            this.successScreenProvider = provider
            return this
        }

        fun setIdentityVerificationId(identificationId: String): Builder {
            this.identificationId = identificationId
            return this
        }

        fun setMode(mode: Mode): Builder {
            this.mode = mode
            return this
        }

        fun showSuccessScreen(showSuccessScreen: Boolean): Builder {
            this.showSuccess = showSuccessScreen
            return this
        }

        fun showSplashScreen(showSplashScreen: Boolean): Builder {
            this.showSplash = showSplashScreen
            return this
        }

        fun setLanguage(language: Language): Builder {
            this.language = language
            return this
        }

        fun setLanguage(languageString: String): Builder {
            val language = Language.of(languageString)
            this.language = language
            return this
        }

        @Deprecated(
            replaceWith = ReplaceWith("showStartScreen(showStartScreen)"),
            message = "Use 'showStartScreen() instead'"
        )
        fun showStartStartScreen(showStartScreen: Boolean): Builder {
            return showStartScreen(showStartScreen)
        }

        fun showStartScreen(showStartScreen: Boolean): Builder {
            this.showStartScreen = showStartScreen
            return this
        }

        @Deprecated("No longer used")
        fun ignoreVerificationErrors(ignoreVerificationErrors: Boolean): Builder {
            this.ignoreVerofocatopmErrors = ignoreVerificationErrors
            return this
        }

        @Deprecated("No longer used")
        fun ignoreLivenessError(ignoreLivenessErrors: Boolean): Builder {
            this.ignoreLivenessErrors = ignoreLivenessErrors
            return this
        }

        @Deprecated("No longer used")
        fun showSelfieWithDocumentScreen(showSelfieWithDocumentScreen: Boolean): Builder {
            this.showSelfieWithDocumentScreen = showSelfieWithDocumentScreen
            return this
        }

//        fun showProofOfAddressScreen(showProofOfAddressScreen: Boolean): Builder {
//            this.showProofOfAddress = showProofOfAddressScreen
//            return this
//        }
//
//        fun showWaitingScreen(showWaitingScreen: Boolean): Builder {
//            this.showWaitingScreen = showWaitingScreen
//            return this
//        }

        fun showIdentificationWaitingScreen(showIdentificationWaitingScreen: Boolean): Builder {
            this.showIdentificationWaitingPage = showIdentificationWaitingScreen
            return this
        }

        @Deprecated("No longer used")
        fun showConsentScreen(showConsentScreen: Boolean): Builder {
            this.showTermsScreen = showConsentScreen
            return this
        }

        @Deprecated("No longer used")
        fun recordProcess(recordProcess: Boolean): Builder {
            this.recordProcess = recordProcess
            return this
        }

        @Deprecated("No longer used")
        fun setLivenessCheckMode(mode: LivenessCheck): Builder {
            this.livenessCheck = mode
            return this
        }

        @Deprecated("No longer used")
        fun setDriverLicenseBacksideRequired(isRequired: Boolean): Builder {
            this.isDriverLicenseBacksideRequired = isRequired
            return this
        }

        fun setRemoveSelfieFrame(remove: Boolean): Builder {
            this.removeSelfieFrame = remove
            return this
        }

        @Deprecated("No longer used")
        fun setNFCScanMode(NFCScan: NFCScan): Builder {
            this.NFCScan = NFCScan
            return this
        }

        fun setSkipRegistrationIfDriverLicense(skipRegistrationIfDriverLicense: Boolean): Builder {
            this.skipRegistrationIfDriverLicense = skipRegistrationIfDriverLicense
            return this
        }

        fun build(): OndatoConfig {
            return OndatoConfig(
                mode = mode,
                identityVerificationId = identificationId,
                showSuccess = showSuccess,
                language = language,
                showSelfieWithDocumentScreen = showSelfieWithDocumentScreen,
                showWaitingScreen = showWaitingScreen,
                showTermsScreen = showTermsScreen,
                showStartScreen = showStartScreen,
                showSplashScreen = showSplash,
                recordProcess = recordProcess,
                loadingScreenProvider = loadingScreenProvider,
                startScreenProvider = startScreenProvider,
                successScreenProvider = successScreenProvider,
                livenessCheck = livenessCheck,
                isDriverLicenseBacksideRequired = isDriverLicenseBacksideRequired,
                removeSelfieFrame = removeSelfieFrame,
                showIdentificationWaitingPage = showIdentificationWaitingPage,
                NFCScan = NFCScan,
                skipRegistrationIfDriverLicense = skipRegistrationIfDriverLicense
            )
        }
    }

    @Keep
    enum class Mode { TEST, LIVE }
}