package com.ondato.sdk.ui.photo

import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import androidx.core.content.ContextCompat.getColor
import com.ondato.sdk.R
import com.ondato.sdk.ui.base.BaseFragment
import com.ondato.sdk.ui.main.MainViewModel
import com.ondato.sdk.ui.main.Step
import com.ondato.sdk.usecase.savephoto.Mode
import com.otaliastudios.cameraview.CameraView
import com.otaliastudios.cameraview.controls.Facing
import org.koin.androidx.viewmodel.ext.android.sharedViewModel
import org.koin.androidx.viewmodel.ext.android.viewModel
import com.intuit.sdp.R as SdpR

internal class PhotoFragment : BaseFragment(R.layout.ondato_fragment_photo) {
    private val viewModel: PhotoViewModel by viewModel()
    private val mainViewModel: MainViewModel by sharedViewModel()
    private val mode: Mode by lazy { (arguments?.getSerializable(KEY_MODE) as? Mode) ?: Mode.Front }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ((arguments?.getSerializable(KEY_MODE) as? Mode) ?: Mode.Front).let(viewModel::init)
        viewModel.completed.observe(::returnSuccess)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel.stopCamera.observeOnView(::stopCamera)
        viewModel.startCamera.observeOnView(::startCamera)
        val cameraView = R.id.cameraView.find<CameraView>()?.setup()
        R.id.ondatoHelpIcon.onClick { mainViewModel.onShowInfo() }
        R.id.captureButton.onClick { cameraView?.takePictureSnapshot() }
        R.id.tryAgainButton.onClick(viewModel::onTryAgainClicked)
        R.id.continueButton.onClick(viewModel::onContinueClicked)
    }

    private fun CameraView.setup(): CameraView {
        setLifecycleOwner(viewLifecycleOwner)
        addCameraListener(PhotoListener(viewModel::onPictureTaken))
        val fragmentScope = this@PhotoFragment
        facing = if (fragmentScope.mode == Mode.Selfie) {
            Facing.FRONT
        } else {
            Facing.BACK
        }
        return this
    }

    private fun startCamera(data: PhotoScreenData) {
        R.id.cameraView.find<CameraView>()?.open()
        R.id.titleTextView.text(data.titleId)
        setCameraFrame(data.isCameraFrameSquare)

        if (data.documentIconId > 0) {
            R.id.ondatoPhotoIv.src(data.documentIconId)
        }

        // Show the capturing frame in case the image capture is restarted
        R.id.ondatoPhotoIv.show()
        R.id.cameraFrameImageView.show()

        R.id.topOverlay.find<View>()?.setBackgroundColor(getColor(requireContext(), R.color.ondatoColorCameraFilter))
        R.id.leftOverlay.find<View>()?.setBackgroundColor(getColor(requireContext(), R.color.ondatoColorCameraFilter))
        R.id.rightOverlay.find<View>()?.setBackgroundColor(getColor(requireContext(), R.color.ondatoColorCameraFilter))
        R.id.bottomOverlay.find<View>()?.setBackgroundColor(getColor(requireContext(), R.color.ondatoColorCameraFilter))

        R.id.captureButton.show()
        R.id.ondatoHelpIcon.show()
        R.id.descriptionTextView.hide()
        R.id.tryAgainButton.hide()
        R.id.continueButton.hide()
    }

    private fun stopCamera(data: PhotoScreenData) {
        R.id.cameraView.find<CameraView>()?.close()
        R.id.titleTextView.text(data.checkPhotoTitleId)
        R.id.descriptionTextView.text(data.checkPhotoDescriptionId)
        setCameraFrame(data.isCameraFrameSquare)

        if(data.documentIconId > 0){
            R.id.ondatoPhotoIv.src(data.documentIconId)
        }

        // Hide the capturing frame when the photo is captured
        R.id.ondatoPhotoIv.hide()
        R.id.cameraFrameImageView.hide()
        R.id.topOverlay.find<View>()?.setBackgroundColor(Color.TRANSPARENT)
        R.id.leftOverlay.find<View>()?.setBackgroundColor(Color.TRANSPARENT)
        R.id.rightOverlay.find<View>()?.setBackgroundColor(Color.TRANSPARENT)
        R.id.bottomOverlay.find<View>()?.setBackgroundColor(Color.TRANSPARENT)

        R.id.captureButton.hide()
        R.id.ondatoHelpIcon.hide()
        R.id.descriptionTextView.show()
        R.id.tryAgainButton.show()
        R.id.continueButton.show()
    }

    private fun setCameraFrame(isSquare: Boolean) {
        val frame = R.id.cameraFrameImageView.find<ImageView>() ?: return
        if (isSquare) {
            val sdp = resources.getDimension(SdpR.dimen._270sdp).toInt()
            frame.layoutParams.width = sdp
            frame.layoutParams.height = sdp
        } else {
            frame.layoutParams.width = resources.getDimension(SdpR.dimen._270sdp).toInt()

            if (mode == Mode.Address) {
                R.id.descriptionTextView.hide()
                R.id.ondatoPhotoIv.hide()
                frame.layoutParams.height = resources.getDimension(SdpR.dimen._420sdp).toInt()
            } else {
                frame.layoutParams.height = resources.getDimension(SdpR.dimen._180sdp).toInt()
            }
        }
        frame.requestLayout()
    }

    private fun returnSuccess() {
        when (mode) {
            Mode.Selfie -> mainViewModel.onStepSuccess(Step.TAKE_SELFIE_WITH_DOCUMENT)
            Mode.Front -> mainViewModel.onStepSuccess(Step.TAKE_DOCUMENT_FRONT)
            Mode.Back -> mainViewModel.onStepSuccess(Step.TAKE_DOCUMENT_BACK)
            Mode.Address -> mainViewModel.onStepSuccess(Step.CAPTURE_POA)
            else -> return
        }
    }

    companion object {
        private const val KEY_MODE = "ondato.key.mode"

        fun newInstance(mode: Mode): PhotoFragment {
            val bundle = Bundle()
            bundle.putSerializable(KEY_MODE, mode)
            val fragment = PhotoFragment()
            fragment.arguments = bundle
            return fragment
        }
    }
}