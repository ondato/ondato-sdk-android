package com.ondato.sdk.ui.waiting

import com.ondato.sdk.OndatoConfig
import com.ondato.sdk.OndatoConfig.Mode.TEST
import com.ondato.sdk.ui.base.BaseViewModel
import com.ondato.sdk.ui.base.event
import com.ondato.sdk.ui.base.set
import com.ondato.sdk.ui.base.state

internal class WaitingViewModel(
    private val countDown: CountDown = CountDown()
) : BaseViewModel() {
    val time by state<String>()
    val completed by event<Unit>()
    val failed by event<AuthError>()

    fun init(config: OndatoConfig) {
        countDown.start(
            from = if (config.mode == TEST) 10 else 120,
            onTick = { time.set(it) },
            onCompleted = { failed.set(AuthError.Timeout) }
        )
    }

    override fun onCleared() {
        countDown.stop()
        super.onCleared()
    }
}