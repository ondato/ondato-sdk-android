package com.ondato.sdk.ui.main

import android.os.Parcelable
import com.ondato.sdk.ui.compare.VerificationError
import com.ondato.sdk.ui.liveness.active.LivenessError
import com.ondato.sdk.ui.waiting.AuthError
import kotlinx.parcelize.Parcelize

@Parcelize
sealed class Failure : Parcelable {
    data class LiveCheckFailure(val error: LivenessError) : Failure()
    data class VerificationFailure(val errors: List<VerificationError>) : Failure()
    data class RecordUploadFailure(val cause: Throwable): Failure()
    data class WaitingFailure(val error: AuthError) : Failure()
    object TermsFailure : Failure()
    data class IdentificationFailure(val tryAgain: Boolean) : Failure()
    object StartFailure : Failure()
    object MrzScanFailure : Failure()
    object NfcScanFailure : Failure()
    object NfcScanTryAlternative : Failure()
    object NfcSettingCancelled : Failure()
    object RecordingNotFoundFailure : Failure()
}
