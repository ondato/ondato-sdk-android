package com.ondato.sdk.usecase.installationid

import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

internal class InstallationIdUseCase(
    private val storage: InstallationIdStorage,
    private val generator: InstallationIdGenerator = InstallationIdGenerator,
    private val dispatcher: CoroutineDispatcher = Dispatchers.Default
) {
    suspend fun get(): String = withContext(dispatcher) {
        val stored = storage.get()
        if (stored.isBlank()) {
            val new = generator.generate()
            storage.save(new)
            new
        } else {
            stored
        }
    }
}