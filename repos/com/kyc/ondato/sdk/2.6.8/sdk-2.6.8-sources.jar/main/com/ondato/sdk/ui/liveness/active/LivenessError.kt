package com.ondato.sdk.ui.liveness.active

import android.os.Parcelable
import com.facetec.sdk.FaceTecSessionStatus
import com.ondato.sdk.R
import com.ondato.sdk.ui.error.ErrorMessage
import kotlinx.parcelize.Parcelize

@Parcelize
sealed class LivenessError : ErrorMessage, Parcelable {
    override val title: Int = R.string.FaceTecRetryReasonGeneric_title
    override val message: Int = R.string.FaceTecRetryReasonGeneric_subtitle

    object Canceled : LivenessError()
    object NetworkError : LivenessError()
    data class InternalSdkError(val status: FaceTecSessionStatus) : LivenessError()
    object FaceNotFount : LivenessError()

    object MaxAttemptsReached: LivenessError()
}