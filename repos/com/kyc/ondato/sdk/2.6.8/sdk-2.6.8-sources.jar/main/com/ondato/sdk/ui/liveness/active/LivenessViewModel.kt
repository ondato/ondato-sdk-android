package com.ondato.sdk.ui.liveness.active

import com.ondato.sdk.ui.base.BaseViewModel
import com.ondato.sdk.ui.base.set
import com.ondato.sdk.ui.base.state
import com.ondato.sdk.usecase.liveness.LivenessLicenseInfo
import com.ondato.sdk.usecase.liveness.LivenessTokenUseCase

internal class LivenessViewModel(
    private val tokenUseCase: LivenessTokenUseCase
) : BaseViewModel() {

    val licenseInfo by state<LivenessLicenseInfo>()

    init {
        launch { licenseInfo.set(tokenUseCase.getToken()) }
    }
}