package com.ondato.sdk.android

import com.ondato.sdk.BuildConfig
import com.ondato.sdk.usecase.deviceinfo.SdkVersionProvider

internal class AndroidSdkVersionProvider: SdkVersionProvider {
    override suspend fun get(): String {
        return BuildConfig.SDK_VERSION
    }
}