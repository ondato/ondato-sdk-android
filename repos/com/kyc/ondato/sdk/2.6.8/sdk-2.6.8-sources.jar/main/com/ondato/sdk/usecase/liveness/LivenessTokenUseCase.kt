package com.ondato.sdk.usecase.liveness

internal class LivenessTokenUseCase(private val api: FaceTecApi) {

    suspend fun getToken(): LivenessLicenseInfo {
        val livenessLicenseInfo = api.getLicenseInfo()
        val token = api.getSessionToken()

        return livenessLicenseInfo.copy(token = token)
    }
}