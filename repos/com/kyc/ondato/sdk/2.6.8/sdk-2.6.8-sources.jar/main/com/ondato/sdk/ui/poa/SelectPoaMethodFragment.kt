package com.ondato.sdk.ui.poa

import android.os.Bundle
import android.view.View
import androidx.core.view.isVisible
import com.ondato.sdk.R
import com.ondato.sdk.ui.base.BaseFragment
import com.ondato.sdk.ui.document.instructions.CaptureDocumentInstructionsViewModel
import com.ondato.sdk.ui.main.MainViewModel
import com.ondato.sdk.ui.main.Step
import org.koin.androidx.viewmodel.ext.android.sharedViewModel
import org.koin.androidx.viewmodel.ext.android.viewModel

internal class SelectPoaMethodFragment :
    BaseFragment(R.layout.ondato_fragment_select_poa_method) {

    private val viewModel: CaptureDocumentInstructionsViewModel by viewModel()
    private val mainViewModel: MainViewModel by sharedViewModel()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel.isLoading.observeOnView(::toggleScreenVisibility)
        viewModel.next.observeOnView(mainViewModel::onStepSuccess)
        R.id.captureDocumentButton.onClick { mainViewModel.onNextStep(Step.CAPTURE_POA_INSTRUCTIONS) }
        R.id.uploadDocumentButton.onClick { mainViewModel.onNextStep(Step.UPLOAD_POA) }
    }


    private fun toggleScreenVisibility(loading: Boolean) {
        R.id.ondatoDocumentInstructionsContainer.view()?.isVisible = !loading
    }

    companion object {
        fun newInstance(): SelectPoaMethodFragment {
            return SelectPoaMethodFragment()
        }
    }
}