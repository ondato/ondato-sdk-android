package com.ondato.sdk.ui.main

internal interface ErrorUi {
    fun showError(error: ErrorConfig)
}