package com.ondato.sdk.usecase.deviceinfo

internal interface SdkVersionProvider {
    suspend fun get(): String
}