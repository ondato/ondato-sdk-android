package com.ondato.sdk.api.facetec

import com.ondato.sdk.api.BackendApi
import com.ondato.sdk.usecase.liveness.LivenessApi

internal class LivenessApiService(private val api: BackendApi) : LivenessApi {

    override suspend fun sendPassiveCheck(kycId: String, body: PassiveLivenessCheckBody) {
        api.sendPassiveLivenessCheck(kycId, body)
    }

    override suspend fun sendActiveCheck(kycId: String, body: ActiveLivenessCheckBody) {
        api.sendActiveLivenessPhoto(kycId, body)
    }

    override suspend fun sendFaceAuth(kycId: String, body: ActiveLivenessCheckBody) {
        api.sendFaceAuthPhoto(kycId, body)
    }
}