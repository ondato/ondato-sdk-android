package com.ondato.sdk.api.facetec

import com.ondato.sdk.api.facetec.ProgressRequestBody.Listener
import okhttp3.MediaType
import okhttp3.RequestBody
import okio.BufferedSink
import okio.buffer
import okio.sink
import java.io.IOException
import java.io.OutputStream

internal class ProgressRequestBody(
    private val requestBody: RequestBody,
    private val listener: Listener = Listener { _, _ -> }
) : RequestBody() {

    override fun contentType(): MediaType? {
        return requestBody.contentType()
    }

    @Throws(IOException::class)
    override fun contentLength(): Long {
        return requestBody.contentLength()
    }

    @Throws(IOException::class)
    override fun writeTo(sink: BufferedSink) {
        val progressStream = ProgressStream(sink.outputStream(), contentLength())
        val progressSink = progressStream.sink().buffer()
        requestBody.writeTo(progressSink)
        progressSink.flush()
    }

    private inner class ProgressStream(
        private val stream: OutputStream,
        private val totalBytes: Long
    ) : OutputStream() {
        private var bytesSent: Long = 0

        @Throws(IOException::class)
        override fun write(b: ByteArray, off: Int, len: Int) {
            stream.write(b, off, len)
            bytesSent += if (len < b.size) {
                len.toLong()
            } else {
                b.size.toLong()
            }
            listener.onUploadProgressChanged(bytesSent, totalBytes)
        }

        @Throws(IOException::class)
        override fun write(b: Int) {
            stream.write(b)
            bytesSent += 1
            listener.onUploadProgressChanged(bytesSent, totalBytes)
        }
    }

    internal fun interface Listener {
        fun onUploadProgressChanged(bytesWritten: Long, totalBytes: Long)
    }
}