package com.ondato.sdk.ui.liveness.active

import com.ondato.sdk.Ondato
import com.ondato.sdk.OndatoConfig.Mode.TEST

//TODO: Delete this because this seems to be deprecated since facetec api key is received from backend now?
internal object FaceTecConfig {
    val deviceLicenseKeyIdentifier: String
        get() = if (Ondato.config.mode == TEST) Config.Test.id else Config.Live.id

    val faceTecServerBaseURL: String
        get() = if (Ondato.config.mode == TEST) Config.Test.url else Config.Live.url

    val publicFaceMapEncryptionKey: String
        get() = if (Ondato.config.mode == TEST) Config.Test.publicKey else Config.Live.publicKey
}