package com.ondato.sdk.ui.document

import android.os.Bundle
import android.view.View
import com.ondato.sdk.R
import com.ondato.sdk.log.Event
import com.ondato.sdk.log.Logger
import com.ondato.sdk.ui.base.BaseFragment
import com.ondato.sdk.ui.main.MainViewModel
import com.ondato.sdk.ui.main.Step.SELECT_DOCUMENT
import com.ondato.sdk.usecase.document.DocumentType
import org.koin.androidx.viewmodel.ext.android.sharedViewModel
import org.koin.androidx.viewmodel.ext.android.viewModel

internal class SelectDocumentFragment : BaseFragment(R.layout.ondato_fragment_select_document) {
    private val viewModel: SelectDocumentViewModel by viewModel()
    private val mainViewModel: MainViewModel by sharedViewModel()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (savedInstanceState == null) Logger.log(Event.DocumentTypeSelectionStarted)
        viewModel.completed.observe { mainViewModel.onStepSuccess(SELECT_DOCUMENT) }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel.documents.observeOnView(::showDocuments)
        R.id.passportButton.onClick { viewModel.onDocumentSelected(DocumentType.Passport) }
        R.id.idCardButton.onClick { viewModel.onDocumentSelected(DocumentType.IdCard) }
        R.id.drivingLicenseButton.onClick {
            viewModel.onDocumentSelected(DocumentType.DriverLicense)
        }
    }

    private fun showDocuments(documents: List<DocumentType>) {
        documents.forEach { type ->
            when (type) {
                DocumentType.Passport -> showPassport()
                DocumentType.IdCard -> showIdCard()
                DocumentType.DriverLicense -> showDrivingLicense()
                else -> return
            }
        }
    }

    private fun showPassport() {
        R.id.passportButton.view()?.visibility = View.VISIBLE
        R.id.passportDivider.view()?.visibility = View.VISIBLE
    }

    private fun showIdCard() {
        R.id.idCardButton.view()?.visibility = View.VISIBLE
        R.id.cardDivider.view()?.visibility = View.VISIBLE
    }

    private fun showDrivingLicense() {
        R.id.drivingLicenseButton.view()?.visibility = View.VISIBLE
        R.id.licenseDivider.view()?.visibility = View.VISIBLE
    }

    companion object {
        fun newInstance() = SelectDocumentFragment()
    }
}