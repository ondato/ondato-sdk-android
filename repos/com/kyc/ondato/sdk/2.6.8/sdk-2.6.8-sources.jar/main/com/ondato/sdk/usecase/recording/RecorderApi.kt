package com.ondato.sdk.usecase.recording

import androidx.annotation.Keep

@Keep
interface RecorderApi {

    @Keep
    suspend fun send(kycId: String, videoBase64: String, videoFileType: String)
}