package com.ondato.sdk.ui.liveness.pasive

import android.content.Context
import android.os.Bundle
import android.view.View
import androidx.core.view.isVisible
import androidx.lifecycle.lifecycleScope
import com.ondato.sdk.Ondato
import com.ondato.sdk.R
import com.ondato.sdk.ui.base.BaseFragment
import com.ondato.sdk.ui.main.MainViewModel
import com.ondato.sdk.ui.main.Step
import com.otaliastudios.cameraview.CameraView
import kotlinx.coroutines.delay
import org.koin.androidx.viewmodel.ext.android.sharedViewModel
import org.koin.androidx.viewmodel.ext.android.viewModel

internal class PassiveLivenessCheckFragment :
    BaseFragment(R.layout.ondato_fragment_liveness_passive) {
    private val captor = LivenessCaptor()
    private val viewModel: PassiveCheckViewModel by viewModel()
    private val mainViewModel: MainViewModel by sharedViewModel()
    private val config = Ondato.config

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        viewModel.completed.observe { mainViewModel.onStepSuccess(Step.TAKE_FACE) }
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        config.loadingScreenProvider.get().show(R.id.loadingContainer)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        R.id.captureButton.disable() // start with capture button disabled until camera loads

        viewModel.loading.observeOnView(::showLoading)
        setupPunchHoleView()
        R.id.cameraView.find<CameraView>()?.apply {
            setLifecycleOwner(viewLifecycleOwner)
            R.id.captureButton.onClick {
                showLoading(true)
                captor.capture(viewLifecycleOwner.lifecycleScope, this, viewModel)
            }
        }

        // todo: update camera lib so we could receive a callback of when camera gets actually loaded
        // for now, after a 3sec delay we just assume that camera is loaded and then enable the capture button
        viewLifecycleOwner.lifecycleScope.launchWhenResumed {
            delay(3000)
            R.id.captureButton.enable()
        }

        viewModel.failed.observeOnView { livenessCheckFailed() }
    }

    private fun livenessCheckFailed() {
        R.id.cameraView.find<CameraView>()?.apply {
            this.open()
        }
    }

    private fun setupPunchHoleView() {
        R.id.cameraOverlay.find<PunchHoleView>()?.isVisible = !config.removeSelfieFrame
    }

    private fun showLoading(show: Boolean) {
        R.id.loadingContainer.find<View>()?.isVisible = show
    }

    companion object {
        fun newInstance(): PassiveLivenessCheckFragment {
            return PassiveLivenessCheckFragment()
        }
    }
}