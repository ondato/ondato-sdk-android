package com.ondato.sdk.usecase.liveness

import com.facetec.sdk.FaceTecSessionResult

internal interface FaceTecApi {
    suspend fun getSessionToken(): String

    suspend fun getLicenseInfo(): LivenessLicenseInfo

    suspend fun uploadFacePhoto(sessionResult: FaceTecSessionResult)

    suspend fun uploadFaceAuthPhoto(sessionResult: FaceTecSessionResult)
}