package com.ondato.sdk.ui.start

import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.core.view.isVisible
import androidx.recyclerview.widget.RecyclerView
import com.ondato.sdk.Ondato
import com.ondato.sdk.OndatoConfig
import com.ondato.sdk.R
import com.ondato.sdk.enums.Language
import com.ondato.sdk.enums.NFCScan
import com.ondato.sdk.screen.StartScreenCallback
import com.ondato.sdk.ui.base.BaseFragment
import com.ondato.sdk.ui.main.Failure
import com.ondato.sdk.ui.main.MainViewModel
import com.ondato.sdk.utils.isNfcAvailable
import org.koin.androidx.viewmodel.ext.android.sharedViewModel
import org.koin.androidx.viewmodel.ext.android.viewModel

internal class StartFragment : BaseFragment(R.layout.ondato_fragment_start) {
    private val mainViewModel: MainViewModel by sharedViewModel()
    private val viewModel: StartViewModel by viewModel()
    private val adapter by lazy { LanguagesAdapter(viewModel::onLanguageClicked) }
    private var callback: StartScreenCallback? = null
    private val isNfcAvailable by lazy { requireActivity().isNfcAvailable() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        viewModel.showNfcNotAvailable.observe { mainViewModel.onStepFailed(Failure.StartFailure) }
        viewModel.proceedNext.observe { callback?.start() }
        viewModel.showError.observe(::showError)
        viewModel.changeLanguage.observe(::setUiLanguage)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setViews(Ondato.config)
        viewModel.isLanguagePickerVisible.observeOnView(::showPicker)
        viewModel.language.observeOnView(::updateSelectedLanguageText)
        R.id.ondatoStartButton.onClick { viewModel.onStartClicked(isNfcAvailable) }
        R.id.ondatoShowLanguageButton.onClick(viewModel::onShowLanguagePickerClicked)
        R.id.ondatoCloseLanguagePickerButton.onClick(viewModel::onCloseLanguagePicketClicked)
        R.id.ondatoLanguagesRecycler.find<RecyclerView>()?.adapter = adapter
    }

    private fun setViews(config: OndatoConfig) {
        val (stepTwoDrawable, stepTwoText) = if (config.NFCScan == NFCScan.No) {
            R.drawable.ondato_onboarding_photo_document to R.string.ondato_start_identification_step_2
        } else {
            R.drawable.ondato_ic_nfc_step to R.string.ondato_start_identification_nfc_step_2
        }
        R.id.ondatoTakePhotoIv.src(stepTwoDrawable)
        R.id.ondatoTakePhotoTv.text(stepTwoText)
    }

    private fun setUiLanguage(it: Language) {
        (activity as? UiLanguage)?.setLanguage(it)
    }

    private fun showPicker(show: Boolean) {
        R.id.ondatoStartButton.view()?.isVisible = !show
        R.id.ondatoStartLayout.view()?.isVisible = !show
        R.id.ondatoShowLanguageButton.view()?.isVisible = !show
        R.id.ondatolanguagePickerLayout.view()?.isVisible = show
    }

    private fun updateSelectedLanguageText(languages: Language) {
        R.id.ondatoShowLanguageButton.find<TextView>()?.text = languages.country
    }

    companion object {
        fun newInstance(callback: StartScreenCallback) = StartFragment().apply {
            this.callback = callback
        }
    }
}