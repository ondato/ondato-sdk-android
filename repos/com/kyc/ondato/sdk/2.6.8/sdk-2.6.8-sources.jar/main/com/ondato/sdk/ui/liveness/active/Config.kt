package com.ondato.sdk.ui.liveness.active

import androidx.annotation.Keep

@Keep
internal enum class Config(
    val id: String,
    val url: String,
    val publicKey: String
) {
    Test(
        id = "dMV5Lvfy6LFjIQKBREZ5X3Od2RjjxMzd",
        url = "https://test-facetecapi.ondato.com",
        publicKey = """
        -----BEGIN PUBLIC KEY-----
        MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAz/j9KaaGdu6mTWRT9Z2n
        Ob7/+b048nX5yRCVR6W1QyEHgLRlNN6PUqWHCL+XBBmzfc559dGt4wRQKogVB6PV
        na4WV9imc82yvjHNYholZnDu60Ta890s03dO8I6F1wT6Kj52bDKFz5krP6SvvIen
        HIdZu7UQwDYayN0wXitwuBcCJA6gUBxFVUkciXijV3L8jc3uspaCPTxKd0z5jGaT
        mLdn7ue0PvYwwHqCWvQC6p4ij9xxlERnyPAi8YteeyUJHceLwFchiiFud0s7lPhC
        BYs3JMEbdJBgcCEPUG/wA5hBnXzYNI3zMALmjsb9oG2R10g+zjWSzw2bdyJ7HB32
        rQIDAQAB
        -----END PUBLIC KEY-----
    """.trimIndent()
    ),

    Live(
        id = "dMV5Lvfy6LFjIQKBREZ5X3Od2RjjxMzd",
        url = "https://facetecapi.ondato.com",
        publicKey = """
        -----BEGIN PUBLIC KEY-----
        MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAp/KzkGdKaVRidxrSPMAl
        y7fJSZnA/rM0zvQZK7n4W2Fm5/YaIpQCdw4lakrZu2ip4pSHioZCdoHI4bRmgJj7
        Vn5TJ3jaP5jmixmGu1Sm6x0HwaRNbIUVtFlpHDQrmA9lPkofzU+H6uDBXjzT9i9A
        hzCjW7odMuhGv8gsKzVICxQqEhn7rhkr119jvsBLQfxfQzDt6RduPtmL+HEmo8wq
        8U2g1R4Q/2BefqEVfM6su76CjQCtAKaH1lZKLlibePi4bJQ9uwZH5kPnb4Ec9jTG
        ufrWyKI+MHDnuvE9IoYShWSBhQNXTnNBbpkfUD3RhbAmOANzeeXfeuo2vV2eT0QP
        aQIDAQAB
        -----END PUBLIC KEY-----
    """.trimIndent()
    );
}