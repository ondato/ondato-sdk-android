package com.ondato.sdk.usecase.session

interface CompleteApi {

    suspend fun completeKYCIdentification(identityVerificationId: String)

    suspend fun completeIdentification(identificationId: String)

    suspend fun abortIdentification(identificationId: String)
}