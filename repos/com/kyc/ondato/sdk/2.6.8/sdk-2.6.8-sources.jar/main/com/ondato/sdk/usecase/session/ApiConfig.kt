package com.ondato.sdk.usecase.session

import androidx.annotation.Keep
import com.ondato.sdk.usecase.document.DocumentPart
import com.ondato.sdk.usecase.document.DocumentType

data class ApiConfig(
    val id: String,
    val documentsInfo: DocumentsInfo,
    val face: Face,
    val resultsWaiting: ResultsWaiting,
    val additionalDocument: AdditionalDocument,
    val nfc: Nfc,
) {

    companion object {
        internal val EMPTY = ApiConfig(
            "",
            DocumentsInfo.EMPTY,
            Face.EMPTY,
            ResultsWaiting.EMPTY,
            AdditionalDocument.EMPTY,
            Nfc.EMPTY,
        )
    }
}

data class DocumentsInfo(
    val enabled: Boolean,
    val types: List<DocumentTypeInfo> = listOf()
) {

    companion object {

        internal val EMPTY = DocumentsInfo(false, arrayListOf())
    }
}

data class DocumentTypeInfo(
    val type: DocumentType,
    val parts: List<DocumentPart>
)

data class Face(
    val enabled: Boolean,
    val activeLivenessEnabled: Boolean,
    val passiveLivenessEnabled: Boolean
) {

    companion object {

        internal val EMPTY = Face(
            enabled = false,
            activeLivenessEnabled = false,
            passiveLivenessEnabled = false
        )
    }
}

data class Nfc(val enabled: Boolean, val type: Type) {

    companion object {

        internal val EMPTY = Nfc(false, Type.EMPTY)
    }
}

data class ResultsWaiting(
    val enabled: Boolean,
    val autoCompleteSkip: Boolean
) {

    companion object {

        internal val EMPTY = ResultsWaiting(enabled = false, autoCompleteSkip = false)
    }
}

data class AdditionalDocument(
    val enabled: Boolean,
    val types: List<Type> = listOf()
) {

    enum class Type {
        SelfieWithDoc,
        ProofOfAddress,
        Unknown;

        companion object {
            fun of(name: String) = values().firstOrNull { it.name == name } ?: Unknown
        }
    }

    companion object {

        internal val EMPTY = AdditionalDocument(enabled = false, types = arrayListOf())
    }
}

data class Type(val name: String) {

    companion object {

        internal val EMPTY = Type("")
    }
}

@Keep
internal enum class Types(val type: String) {
    Consent("Consent"),
    KycIdentification("KycIdentification"),
    Unknown("");

    companion object {
        fun of(name: String) = values().firstOrNull { it.name == name } ?: Unknown
    }
}