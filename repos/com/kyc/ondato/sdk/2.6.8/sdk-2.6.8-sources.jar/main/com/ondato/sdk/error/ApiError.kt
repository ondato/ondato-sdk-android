package com.ondato.sdk.error

internal data class ApiError(
    val json: String
)