package com.ondato.sdk.usecase.registration

import com.ondato.sdk.api.registration.RegistrationRequest

internal interface RegistrationApi {
    suspend fun sendRegistration(
        identityVerificationId: String,
        registrationRequest: List<RegistrationRequest>
    )
}