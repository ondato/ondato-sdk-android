package com.ondato.sdk.ui.base

import android.content.Context
import com.ondato.sdk.enums.Language
import java.util.*

internal class LanguageController {
    fun update(context: Context, language: Language) {
        val locale = Locale(language.languageString, language.country)
        Locale.setDefault(locale)
        update(context, locale)
        update(context.applicationContext, locale)
    }

    @Suppress("DEPRECATION")
    private fun update(context: Context, locale: Locale) {
        val res = context.resources
        val config = res.configuration
        config.setLocale(locale)
        res.updateConfiguration(config, res.displayMetrics)
    }
}