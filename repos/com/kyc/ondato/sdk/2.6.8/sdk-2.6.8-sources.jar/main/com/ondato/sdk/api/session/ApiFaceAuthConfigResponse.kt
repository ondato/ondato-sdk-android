package com.ondato.sdk.api.session

import androidx.annotation.Keep
import com.google.gson.annotations.SerializedName

@Keep
internal data class ApiFaceAuthStatusResponse(
    @SerializedName("status") var status: Status? = null,
    @SerializedName("step") var step: FaceAuthSetupStep? = null
) {
    enum class Status(val type: String) {
        InProgress("InProgress"),
        Unknown("");

        companion object {
            fun of(name: String) = values().firstOrNull { it.name == name } ?: Unknown
        }
    }
}
@Keep
internal data class FaceAuthSetupStep(
    @SerializedName("faceAuthentication") var faceAuthentication: FaceAuthSetup? = null
)

@Keep
internal  data class FaceAuthSetup(
    @SerializedName("id") var id: String? = null
)



