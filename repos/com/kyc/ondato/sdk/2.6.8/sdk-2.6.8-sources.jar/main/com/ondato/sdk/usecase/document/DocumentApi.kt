package com.ondato.sdk.usecase.document

internal interface DocumentApi {

    suspend fun send(
        documentType: String,
        identityVerificationId: String,
        imageBase64: String,
        imageFileType: String,
        side: String,
    )
}