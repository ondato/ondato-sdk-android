package com.ondato.sdk.api.session

import com.google.gson.annotations.SerializedName
import com.ondato.sdk.usecase.document.DocumentPart
import com.ondato.sdk.usecase.document.DocumentType
import com.ondato.sdk.usecase.session.*

internal data class ApiConfigResponse(
    @SerializedName("id") var id: String? = null,
    @SerializedName("document") var document: DocumentResponse? = null,
    @SerializedName("face") var face: FaceResponse? = null,
    @SerializedName("resultsWaiting")
    var resultsWaiting: ResultsWaitingResponse? = null,
    @SerializedName("additionalDocument")
    var additionalDocument: AdditionalDocumentResponse? = null,
    @SerializedName("nfc") var nfc: NfcResponse? = null,
) {

    fun toApiConfig(): ApiConfig {
        return ApiConfig(
            id ?: "",
            document?.toDocument() ?: DocumentsInfo.EMPTY,
            face?.toFace() ?: Face.EMPTY,
            resultsWaiting?.toResultsWaiting() ?: ResultsWaiting.EMPTY,
            additionalDocument?.toAdditionalDocument() ?: AdditionalDocument.EMPTY,
            nfc?.toNfc() ?: Nfc.EMPTY,
        )
    }
}

internal data class DocumentResponse(
    @SerializedName("enabled") var enabled: Boolean? = null,
    @SerializedName("types") var types: ArrayList<TypesResponse> = arrayListOf()
) {

    internal fun toDocument(): DocumentsInfo {
        val types = types.map {
            DocumentTypeInfo(
                DocumentType.of(it.name ?: ""),
                it.parts.map { part -> DocumentPart.of(part.name ?: "") }
            )
        }.filter { type -> type.type != DocumentType.Unknown }

        return DocumentsInfo(enabled ?: false, types)
    }
}

internal data class FaceResponse(
    @SerializedName("enabled") var enabled: Boolean? = null,
    @SerializedName("activeLivenessEnabled") var activeLivenessEnabled: Boolean? = null,
    @SerializedName("passiveLivenessEnabled") var passiveLivenessEnabled: Boolean? = null
) {

    internal fun toFace(): Face {
        return Face(
            enabled ?: false,
            activeLivenessEnabled ?: false,
            passiveLivenessEnabled ?: false
        )
    }
}

internal data class NfcResponse(
    @SerializedName("enabled") var enabled: Boolean? = null,
    @SerializedName("type") var type: TypeResponse? = null
) {

    internal fun toNfc(): Nfc = Nfc(enabled ?: false, type?.toType() ?: Type.EMPTY)
}

internal data class ResultsWaitingResponse(
    @SerializedName("enabled") var enabled: Boolean? = null,
    @SerializedName("autoCompleteSkip") var autoCompleteSkip: Boolean? = null
) {

    internal fun toResultsWaiting(): ResultsWaiting {
        return ResultsWaiting(enabled ?: false, autoCompleteSkip ?: false)
    }
}

internal data class AdditionalDocumentResponse(
    @SerializedName("enabled") var enabled: Boolean? = null,
    @SerializedName("types") var types: ArrayList<TypesResponse> = arrayListOf()
) {

    internal fun toAdditionalDocument(): AdditionalDocument {
        return AdditionalDocument(
            enabled ?: false,
            types.map { AdditionalDocument.Type.of(it.name ?: "") }
        )
    }
}

internal data class TypeResponse(@SerializedName("name") var name: String? = null) {

    internal fun toType(): Type = Type(name ?: "")
}

internal data class TypesResponse(
    @SerializedName("name") var name: String? = null,
    @SerializedName("parts") var parts: List<PartResponse> = emptyList()
) {

    data class PartResponse(@SerializedName("name") var name: String? = null)
}