package com.ondato.sdk.ui.document.instructions

import com.ondato.sdk.R
import com.ondato.sdk.error.BadDocumentTypeException
import com.ondato.sdk.ui.utils.dp
import com.ondato.sdk.usecase.document.DocumentType
import com.ondato.sdk.usecase.savephoto.Mode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

internal object InstructionsScreenMapper {

    suspend fun map(type: DocumentType, mode: Mode): InstructionsViewData =
        withContext(Dispatchers.Default) {
            when (mode) {
                Mode.Back -> handleBack(type)
                Mode.Front -> handleFront(type)
                Mode.MRZ -> handleMRZ(type)
                Mode.Address -> handleAddress()
                else -> handleSelfie()
            }
        }

    private fun handleSelfie(): InstructionsViewData {
        return InstructionsViewData(
            titleResId = R.string.ondato_capture_face_instructions_title,
            descriptionResId = R.string.ondato_capture_face_instructions_description,
            imageResId = R.drawable.ondato_selfie_v2,
            imageMarginLeft = 86.dp,
            imageMarginRight = 86.dp,
            firstMistakeImageResId = R.drawable.ondato_face_too_blurry,
            secondMistakeDescResId = R.string.ondato_capture_instructions_bad_lighting,
            secondMistakeImageResId = R.drawable.ondato_face_bad_lighting,
            thirdMistakeDescResId = R.string.ondato_capture_instructions_not_neutral,
            thirdMistakeImageResId = R.drawable.ondato_face_not_neutral
        )
    }

    private fun handleBack(type: DocumentType) = when (type) {
        DocumentType.Passport -> InstructionsViewData(
            titleResId = R.string.ondato_capture_passport_front_instructions_title,
            descriptionResId = R.string.ondato_capture_passport_front_instructions_description,
            imageResId = R.drawable.ondato_passport_front,
            imageMarginTop = 46.dp,
            imageMarginLeft = 100.dp,
            imageMarginRight = 100.dp,
            imageMarginBottom = 46.dp,
            firstMistakeImageResId = R.drawable.ondato_passport_too_blurry,
            secondMistakeImageResId = R.drawable.ondato_passport_too_small,
            thirdMistakeImageResId = R.drawable.ondato_passport_too_dark
        )
        DocumentType.IdCard -> InstructionsViewData(
            titleResId = R.string.ondato_capture_id_card_back_instructions_title,
            descriptionResId = R.string.ondato_capture_id_card_back_instructions_description,
            imageResId = R.drawable.ondato_id_back,
            firstMistakeImageResId = R.drawable.ondato_card_back_too_blurry,
            secondMistakeImageResId = R.drawable.ondato_card_back_too_small,
            thirdMistakeImageResId = R.drawable.ondato_card_back_too_dark
        )
        DocumentType.DriverLicense -> InstructionsViewData(
            titleResId = R.string.ondato_capture_driver_license_back_instructions_title,
            imageResId = R.drawable.ondato_driving_license_back,
            descriptionResId = R.string.ondato_capture_driver_license_back_instructions_description,
            firstMistakeImageResId = R.drawable.ondato_card_back_too_blurry,
            secondMistakeImageResId = R.drawable.ondato_card_back_too_small,
            thirdMistakeImageResId = R.drawable.ondato_card_back_too_dark
        )
        else -> throw BadDocumentTypeException()
    }

    private fun handleFront(type: DocumentType) = when (type) {
        DocumentType.Passport -> InstructionsViewData(
            titleResId = R.string.ondato_capture_passport_front_instructions_title,
            descriptionResId = R.string.ondato_capture_passport_front_instructions_description,
            imageResId = R.drawable.ondato_passport_front,
            imageMarginTop = 46.dp,
            imageMarginLeft = 100.dp,
            imageMarginRight = 100.dp,
            imageMarginBottom = 46.dp,
            firstMistakeImageResId = R.drawable.ondato_passport_too_blurry,
            secondMistakeImageResId = R.drawable.ondato_passport_too_small,
            thirdMistakeImageResId = R.drawable.ondato_passport_too_dark
        )
        DocumentType.IdCard -> InstructionsViewData(
            titleResId = R.string.ondato_capture_id_card_front_instructions_title,
            descriptionResId = R.string.ondato_capture_id_card_front_instructions_description,
            imageResId = R.drawable.ondato_id_front,
            firstMistakeImageResId = R.drawable.ondato_card_too_blurry,
            secondMistakeImageResId = R.drawable.ondato_card_too_small,
            thirdMistakeImageResId = R.drawable.ondato_card_too_dark
        )
        DocumentType.DriverLicense -> InstructionsViewData(
            titleResId = R.string.ondato_capture_driver_license_front_instructions_title,
            descriptionResId = R.string.ondato_capture_driver_license_front_instructions_description,
            imageResId = R.drawable.ondato_driving_license_front,
            firstMistakeImageResId = R.drawable.ondato_card_too_blurry,
            secondMistakeImageResId = R.drawable.ondato_card_too_small,
            thirdMistakeImageResId = R.drawable.ondato_card_too_dark
        )
        else -> throw BadDocumentTypeException()
    }

    private fun handleMRZ(type: DocumentType) = when (type) {
        DocumentType.Passport -> InstructionsViewData(
            titleResId = R.string.ondato_capture_mrz_instructions_title,
            imageResId = R.drawable.ondato_passport_mrz,
            descriptionResId = R.string.ondato_capture_passport_front_instructions_description,
            imageMarginTop = 46.dp,
            imageMarginLeft = 100.dp,
            imageMarginRight = 100.dp,
            imageMarginBottom = 46.dp,
            firstMistakeImageResId = R.drawable.ondato_passport_too_blurry,
            secondMistakeImageResId = R.drawable.ondato_passport_too_small,
            thirdMistakeImageResId = R.drawable.ondato_passport_too_dark
        )
        DocumentType.IdCard -> InstructionsViewData(
            titleResId = R.string.ondato_capture_mrz_instructions_title,
            imageResId = R.drawable.ondato_identity_card_mrz,
            descriptionResId = R.string.ondato_capture_mrz_id_instructions_description,
            firstMistakeImageResId = R.drawable.ondato_card_back_too_blurry,
            secondMistakeImageResId = R.drawable.ondato_card_back_too_small,
            thirdMistakeImageResId = R.drawable.ondato_card_back_too_dark
        )
        DocumentType.DriverLicense -> InstructionsViewData(
            titleResId = R.string.ondato_capture_mrz_instructions_title,
            imageResId = R.drawable.ondato_identity_card_mrz,
            descriptionResId = R.string.ondato_capture_mrz_id_instructions_description,
            firstMistakeImageResId = R.drawable.ondato_card_back_too_blurry,
            secondMistakeImageResId = R.drawable.ondato_card_back_too_small,
            thirdMistakeImageResId = R.drawable.ondato_card_back_too_dark
        )
        else -> throw BadDocumentTypeException()
    }

    private fun handleAddress(): InstructionsViewData {
        return InstructionsViewData(
            titleResId = R.string.ondato_capture_poa_instructions_title,
            descriptionResId = R.string.ondato_capture_poa_instructions_description,
            imageResId = R.drawable.ondato_poa,
            imageMarginLeft = 86.dp,
            imageMarginRight = 86.dp,
            firstMistakeImageResId = R.drawable.ondato_poa_blurry,
            secondMistakeDescResId = R.string.ondato_capture_instructions_too_small,
            secondMistakeImageResId = R.drawable.ondato_poa_small,
            thirdMistakeDescResId = R.string.ondato_capture_instructions_too_dark,
            thirdMistakeImageResId = R.drawable.ondato_poa_dark
        )
    }
}