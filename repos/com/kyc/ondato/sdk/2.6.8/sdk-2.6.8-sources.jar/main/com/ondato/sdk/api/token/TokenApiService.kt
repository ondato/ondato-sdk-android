package com.ondato.sdk.api.token

import com.ondato.sdk.api.BackendApi
import com.ondato.sdk.api.session.SessionSetupBody
import com.ondato.sdk.usecase.session.token.Token
import com.ondato.sdk.usecase.session.token.TokenApi

internal class TokenApiService(
    private val api: BackendApi,
    private val responseMapper: TokenResponseMapper = TokenResponseMapper
) : TokenApi {

    override suspend fun getTokenV2(identityVerificationId: String): Token {
        val body = SessionSetupBody(identityVerificationId)
        val response = api.getAccessToken(body)
        return responseMapper.map(response)
    }

    override suspend fun getFullAccessTokenV2(identityVerificationId: String): Token {
        val response = api.getFullAccessToken(identityVerificationId, FullAccessTokenBody())
        return responseMapper.map(response)
    }
}