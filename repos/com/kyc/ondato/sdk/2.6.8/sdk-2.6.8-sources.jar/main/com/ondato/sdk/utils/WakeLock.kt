package com.ondato.sdk.utils

import android.content.Context
import android.os.PowerManager
import android.os.PowerManager.PARTIAL_WAKE_LOCK
import android.os.PowerManager.SCREEN_DIM_WAKE_LOCK
import androidx.annotation.Keep

@Keep
class WakeLock(context: Context) {
    private val manager = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
    private var lock: PowerManager.WakeLock? = null

    fun lock() {
        unlock()
        lock = manager?.newWakeLock(PARTIAL_WAKE_LOCK, WakeLock::class.java.simpleName)
        lock?.acquire(10 * 60 * 1000L /*10 minutes*/)
    }

    fun lockScreen() {
        unlock()
        lock = manager?.newWakeLock(SCREEN_DIM_WAKE_LOCK, WakeLock::class.java.simpleName)
        lock?.acquire(100 * 60 * 1000L /*10 minutes*/)
    }

    fun unlock() {
        lock?.let { if (it.isHeld) it.release() }
        lock = null
    }
}