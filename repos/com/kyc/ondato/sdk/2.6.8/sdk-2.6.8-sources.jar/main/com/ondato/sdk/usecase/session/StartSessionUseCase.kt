package com.ondato.sdk.usecase.session

import com.ondato.sdk.Ondato
import com.ondato.sdk.OndatoConfig
import com.ondato.sdk.api.session.ConfigurationApiService
import com.ondato.sdk.enums.LivenessCheck
import com.ondato.sdk.enums.NFCScan
import com.ondato.sdk.usecase.deviceinfo.SendDeviceInfoUseCase
import com.ondato.sdk.usecase.document.DocumentPart
import com.ondato.sdk.usecase.document.DocumentType
import com.ondato.sdk.usecase.session.configuration.SessionSetup
import com.ondato.sdk.usecase.session.configuration.Steps

internal class StartSessionUseCase(
    private val session: Session,
    private val getV2TokenUseCase: GetV2TokenUseCase,
    private val sendDeviceInfoUseCase: SendDeviceInfoUseCase,
    private val configurationApiService: ConfigurationApiService,
) {
    suspend fun start(config: OndatoConfig) {
        session.clear()
        session.language = config.language
        val identityVerificationId = config.identityVerificationId
        setToken(identityVerificationId)
        getKycIdentificationSetup(identityVerificationId)
    }

    private suspend fun setToken(identityVerificationId: String) {
        val apiToken = getV2TokenUseCase.getPartialAccessToken(identityVerificationId)
        session.token = apiToken

        val fullAccessApiToken = getV2TokenUseCase.getFullAccessToken(identityVerificationId)
        session.token = fullAccessApiToken
    }

    private suspend fun getKycIdentificationSetup(identityVerificationId: String) {
        val kycSetup = configurationApiService.getKycIdentificationSetup(identityVerificationId)
        val showTermsScreen = shouldShowTermsScreen(kycSetup)
        val showRegistrationScreen = shouldShowRegistrationScreen(kycSetup)
        session.areTermsAgreed = !showTermsScreen
        session.shouldShowRegistrationScreen = showRegistrationScreen
        startIdentification(identityVerificationId)
    }

    private suspend fun startIdentification(identityVerificationId: String) {
        val kycSetup = configurationApiService.getKycIdentificationSetup(identityVerificationId)
        val kycSetupId = kycSetup.steps
            .firstOrNull { it.type == Steps.Type.KycIdentification }
            ?.setupId

        val faceAuthSetupId = kycSetup.steps
            .firstOrNull { it.type == Steps.Type.FaceAuthentication }
            ?.setupId

        if (faceAuthSetupId != null) {
        val faceAuthSetup = configurationApiService.getFaceAuthConfig(identityVerificationId)
        session.faceAuthId = faceAuthSetup.step?.faceAuthentication?.id
        }

        sendDeviceInfoUseCase.sendV2(identityVerificationId)

        if (kycSetupId != null) {
            val kycId = configurationApiService.getKYCId(kycSetupId, identityVerificationId)
            val config = configurationApiService.getConfig(kycId)
            session.apiConfig = config

            Ondato.updateActiveConfig { currentConfig ->
                currentConfig.copy(
                    showTermsScreen = !session.areTermsAgreed,
                    showSelfieWithDocumentScreen = shouldShowSelfieWithDocumentScreen(config),
                    recordProcess = kycSetup.sessionScreenRecording.enabled,
                    isDriverLicenseBacksideRequired = isDriverLicenseBacksideRequired(config),
                    livenessCheck = getLivenessCheck(config),
                    showIdentificationWaitingPage = config.resultsWaiting.enabled,
                    NFCScan = if (!config.nfc.enabled) NFCScan.No else NFCScan.of(config.nfc.type.name),
                )
            }

            session.showProofOfAddressStep = shouldShowProofOfAddressScreen(config)
            session.availableDocumentTypes = config.documentsInfo.types
            session.kycId = kycId
            session.kycSteps = kycSetup.steps.toMutableList()
        } else {
            Ondato.updateActiveConfig { currentConfig ->
                currentConfig.copy(
                    recordProcess = kycSetup.sessionScreenRecording.enabled
                )
            }
        }
    }

    private fun getLivenessCheck(config: ApiConfig): LivenessCheck {
        return when {
            config.face.activeLivenessEnabled -> LivenessCheck.Active
            else -> LivenessCheck.Passive
        }
    }

    private fun isDriverLicenseBacksideRequired(config: ApiConfig): Boolean {
        return config.documentsInfo.types
            .firstOrNull {
                it.type == DocumentType.DriverLicense &&
                        it.parts.firstOrNull { it == DocumentPart.Back } != null
            } != null
    }

    private fun shouldShowSelfieWithDocumentScreen(config: ApiConfig): Boolean {
        val isEnabled = config.additionalDocument.enabled
        val selfieWithDoc = config.additionalDocument.types
            .firstOrNull { it == AdditionalDocument.Type.SelfieWithDoc }
        return isEnabled && selfieWithDoc != null
    }

    private fun shouldShowProofOfAddressScreen(config: ApiConfig): Boolean {
        val proofOfAddressDoc = config.additionalDocument.types
            .firstOrNull { it == AdditionalDocument.Type.ProofOfAddress }
        return proofOfAddressDoc != null
    }

    private fun shouldShowTermsScreen(kycIdentificationSetup: SessionSetup): Boolean {
        val consentOrder = kycIdentificationSetup.steps
            .firstOrNull { it.type == Steps.Type.Consent }?.order ?: -1
        return consentOrder != -1
    }

    private fun shouldShowRegistrationScreen(kycIdentificationSetup: SessionSetup): Boolean {
        val consentOrder = kycIdentificationSetup.steps
            .firstOrNull { it.type == Steps.Type.Registration }?.order ?: -1
        return consentOrder != -1
    }
}