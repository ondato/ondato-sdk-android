package com.ondato.sdk.ui.photo

import com.ondato.sdk.error.BadDocumentTypeException
import com.ondato.sdk.log.Event.*
import com.ondato.sdk.log.Logger
import com.ondato.sdk.ui.base.BaseViewModel
import com.ondato.sdk.ui.base.call
import com.ondato.sdk.ui.base.event
import com.ondato.sdk.ui.base.set
import com.ondato.sdk.ui.photo.PhotoScreenData.*
import com.ondato.sdk.usecase.additionalDocument.SendAdditionalDocumentUseCase
import com.ondato.sdk.usecase.document.DocumentType
import com.ondato.sdk.usecase.document.SendDocumentUseCase
import com.ondato.sdk.usecase.savephoto.Mode
import com.ondato.sdk.usecase.session.Session

internal class PhotoViewModel(
    private val session: Session,
    private val sendDocumentUseCase: SendDocumentUseCase,
    private val sendAdditionalDocumentUseCase: SendAdditionalDocumentUseCase,
) : BaseViewModel() {
    val completed by event<Unit>()
    val startCamera by event<PhotoScreenData>()
    val stopCamera by event<PhotoScreenData>()

    private var photoBuffer: ByteArray = byteArrayOf()
    private var mode: Mode = Mode.Back
    private var data: PhotoScreenData? = null

    fun init(mode: Mode) {
        this.mode = mode
        this.data = PhotoScreenData.from(mode, session.selectedType)
        data?.let { data ->
            startCamera.set(data)
        }

        log()
    }

    fun onPictureTaken(jpeg: ByteArray?) {
        val data = data ?: return
        stopCamera.set(data)
        photoBuffer = jpeg ?: byteArrayOf()
        when (mode) {
            Mode.Front -> Logger.log(FrontPhotoTaken)
            Mode.Back -> Logger.log(BackPhotoTaken)
            else -> return
        }
    }

    fun onTryAgainClicked() {
        val data = data ?: return
        startCamera.set(data)
    }

    fun onContinueClicked() {
        launch {
            data?.let { data ->
                when (data) {
                    is IdCardFront, is IdCardBack -> {
                        sendDocumentUseCase.send(DocumentType.IdCard.type, photoBuffer, mode)
                    }
                    is PassportFront -> {
                        sendDocumentUseCase.send(DocumentType.Passport.type, photoBuffer, mode)
                    }
                    is DriverLicenseBack, is DriverLicenseFront -> {
                        sendDocumentUseCase.send(DocumentType.DriverLicense.type, photoBuffer, mode)
                    }
                    is Selfie, is ProofOfAddress -> {
                        sendAdditionalDocumentUseCase.storeAndSendImage(photoBuffer, mode)
                    }
                }

                photoBuffer = byteArrayOf()
                onSuccessLog()
                completed.call()
            } ?: throw BadDocumentTypeException()
        }
    }

    private fun onSuccessLog() {
        when (data) {
            Selfie -> Logger.log(SelfieWithDocumentPage)
            else -> return
        }
    }

    private fun log() {
        when (data) {
            PassportFront -> Logger.log(DocumentPassportFrontStart)
            IdCardFront -> Logger.log(DocumentIdCardFrontStart)
            IdCardBack -> Logger.log(DocumentIdCardBackStart)
            DriverLicenseFront -> Logger.log(DocumentDriverLicenseFrontStart)
            DriverLicenseBack -> Logger.log(DocumentDriverLicenseBackStart)
            Selfie -> Logger.log(SelfieWithDocumentStart)
            ProofOfAddress -> Logger.log(ProofOfAddressStart)
            else -> return
        }
    }
}