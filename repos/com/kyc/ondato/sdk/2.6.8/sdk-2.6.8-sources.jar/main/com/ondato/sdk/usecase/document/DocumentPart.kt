package com.ondato.sdk.usecase.document

import androidx.annotation.Keep
import com.ondato.sdk.Ondato
import com.ondato.sdk.enums.NFCScan
import com.ondato.sdk.ui.main.Step

@Keep
enum class DocumentPart(val part: String) {
    FrontCover("FrontCover"),
    BlankPages("BlankPages"),
    DataPage("DataPage"),
    Front("Front"),
    Back("Back"),
    Unknown("");

    companion object {
        fun of(part: String) = values().firstOrNull { it.part == part } ?: Unknown

        fun DocumentPart.toStep(): Step? {
            return when (part) {
                Back.part -> Step.CAPTURE_DOCUMENT_BACK_INSTRUCTIONS
                Front.part -> Step.CAPTURE_DOCUMENT_FRONT_INSTRUCTIONS
                DataPage.part -> {
                    if (Ondato.config.NFCScan == NFCScan.Mandatory || Ondato.config.NFCScan == NFCScan.Optional) {
                        Step.CAPTURE_DOCUMENT_MRZ_INSTRUCTIONS
                    } else {
                        Step.CAPTURE_DOCUMENT_FRONT_INSTRUCTIONS
                    }
                }
                else -> null
            }
        }
    }
}