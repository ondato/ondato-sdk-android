package com.ondato.sdk.error

import java.io.IOException

internal class NotAuthorizedException(
    override val error: ApiError? = null,
    override val cause: Throwable? = null,
    override val message: String? = null
) : IOException(), HasOndatoError
