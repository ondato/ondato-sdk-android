package com.ondato.sdk.ui.registration

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.ondato.sdk.R
import com.ondato.sdk.api.registration.RegistrationRequest
import com.ondato.sdk.api.registration.Value
import com.ondato.sdk.databinding.OndatoFragmentRegistrationBinding
import com.ondato.sdk.log.Event
import com.ondato.sdk.log.Logger
import com.ondato.sdk.ui.base.BaseFragment
import com.ondato.sdk.ui.main.MainViewModel
import com.ondato.sdk.ui.main.Step
import com.ondato.sdk.utils.hideKeyboard
import org.koin.androidx.viewmodel.ext.android.sharedViewModel
import org.koin.androidx.viewmodel.ext.android.viewModel

internal class RegistrationFragment : BaseFragment(R.layout.ondato_fragment_registration) {
    private val mainViewModel: MainViewModel by sharedViewModel()
    private val registrationViewModel: RegistrationViewModel by viewModel()

    private var _binding: OndatoFragmentRegistrationBinding? = null
    private val binding get() = _binding!!

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        registrationViewModel.registrationSuccess.observe {
            mainViewModel.onStepSuccess(Step.REGISTRATION)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = OndatoFragmentRegistrationBinding.inflate(inflater, container, false)

        return binding.root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        if (savedInstanceState == null) Logger.log(Event.RegistrationShown)

        // Submit button can be enabled only when personal code has 9 digits entered
        binding.personalCodeEditText.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(
                charSequence: CharSequence?,
                start: Int,
                before: Int,
                count: Int,
            ) {
                charSequence?.let {
                    if (binding.personalCodeEditText.text?.length == 9) {
                        binding.submitButton.isEnabled = true
                        view.hideKeyboard()
                    } else {
                        binding.submitButton.isEnabled = false
                    }
                }
            }
        })

        binding.submitButton.onClick {
            val personalCode = binding.personalCodeEditText.text.toString()
            registrationViewModel.sendRegistration(listOf(RegistrationRequest(
                "replace", "/registration", Value(personalCode))))
        }
    }

    companion object {
        fun newInstance(): RegistrationFragment {
            return RegistrationFragment()
        }
    }
}