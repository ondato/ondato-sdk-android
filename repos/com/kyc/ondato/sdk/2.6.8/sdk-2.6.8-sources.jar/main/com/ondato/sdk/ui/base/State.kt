package com.ondato.sdk.ui.base

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import kotlin.properties.ReadOnlyProperty
import kotlin.reflect.KProperty

class State<T> : ReadOnlyProperty<Any, LiveData<T>> {
    private val liveData = MutableLiveData<T>()

    override fun getValue(thisRef: Any, property: KProperty<*>): LiveData<T> {
        return liveData
    }
}

class NonNullState<T>(default: T) : ReadOnlyProperty<Any, LiveNonNullData<T>> {
    private val liveData = MutableLiveNonNullData(default)

    override fun getValue(thisRef: Any, property: KProperty<*>): LiveNonNullData<T> {
        return liveData
    }
}


fun <T> state() = State<T>()

fun <T> state(default: T) = NonNullState(default)
