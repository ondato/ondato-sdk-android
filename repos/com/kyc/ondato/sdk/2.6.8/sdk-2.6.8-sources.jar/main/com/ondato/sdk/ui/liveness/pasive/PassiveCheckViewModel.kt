package com.ondato.sdk.ui.liveness.pasive

import com.ondato.sdk.ui.base.*
import com.ondato.sdk.usecase.liveness.passive.PassiveLivenessCheckUseCase

internal class PassiveCheckViewModel(
    private val passiveLivenessCheckUseCase: PassiveLivenessCheckUseCase,
) : BaseViewModel(), CaptureListener {

    val completed by event<Unit>()
    val failed by event<Unit>()
    val loading by state(false)

    override fun onCaptured(frames: List<ByteArray>) {
        launch {
            loading.set(true)
            try {
                passiveLivenessCheckUseCase.check(frames)
                completed.call()
            } catch(e: Exception) {
                loading.set(false)
                failed.call()
            }
//            loading.set(false)
        }
    }

    override fun onCaptureFailed() {
        loading.set(false)
        failed.call()
    }
}