package com.ondato.sdk.usecase.liveness.passive

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import com.ondato.sdk.api.facetec.PassiveLivenessCheckBody
import com.ondato.sdk.log.Logger
import com.ondato.sdk.usecase.liveness.LivenessApi
import com.ondato.sdk.usecase.savephoto.Mode
import com.ondato.sdk.usecase.savephoto.PhotoStorage
import com.ondato.sdk.usecase.session.Session
import com.ondato.sdk.utils.Base64.resizeAndDecodeToBase64
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

internal class PassiveLivenessCheckUseCase(
    private val session: Session,
    private val photoStorage: PhotoStorage,
    private val livenessapi: LivenessApi,
    private val dispatcher: CoroutineDispatcher = Dispatchers.IO,
) {

    suspend fun check(frames: List<ByteArray>) {
        val auditImagesBase64 = frames.map {
            photoStorage.save(it, Mode.Selfie).path.resizeAndDecodeToBase64(Bitmap.CompressFormat.JPEG)
        }

        val bitmaps: List<Bitmap> = frames.map {
            BitmapFactory.decodeByteArray(it, 0, it.size)
        }

        Logger.d("Generated ${bitmaps.size} passive liveness images")

        withContext(dispatcher) {
            livenessapi.sendPassiveCheck(session.kycId, PassiveLivenessCheckBody(auditImagesBase64))
        }
    }
}