package com.ondato.sdk.api.interceptor

import com.ondato.sdk.error.ApiError

internal object ApiErrorMapper {
    fun map(body: String?): ApiError {
        return ApiError(body.toString())
    }
}