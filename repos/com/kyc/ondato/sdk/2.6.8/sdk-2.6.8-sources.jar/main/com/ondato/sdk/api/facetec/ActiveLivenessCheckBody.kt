package com.ondato.sdk.api.facetec

import com.google.gson.annotations.SerializedName

internal class ActiveLivenessCheckBody(
    @SerializedName("sessionId") val sessionId: String,
    @SerializedName("faceScanBase64") val faceScanBase64: String,
    @SerializedName("sessionUserAgent") val sessionUserAgent: String,
    @SerializedName("auditImagesBase64") val auditImagesBase64: List<String>,
    @SerializedName("lowQualityAuditImagesBase64") val lowQualityAuditImagesBase64: List<String>,
)