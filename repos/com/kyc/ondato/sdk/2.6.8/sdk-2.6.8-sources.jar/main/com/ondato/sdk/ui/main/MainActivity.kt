package com.ondato.sdk.ui.main

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.fragment.app.commit
import androidx.lifecycle.lifecycleScope
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.ondato.sdk.Ondato
import com.ondato.sdk.OndatoError
import com.ondato.sdk.R
import com.ondato.sdk.di.Injector.koinInject
import com.ondato.sdk.enums.Language
import com.ondato.sdk.enums.LivenessCheck.Active
import com.ondato.sdk.enums.LivenessCheck.Passive
import com.ondato.sdk.error.FeatureNotIncludedException
import com.ondato.sdk.log.Logger
import com.ondato.sdk.ui.base.BaseActivity
import com.ondato.sdk.ui.base.BaseFragment
import com.ondato.sdk.ui.base.LanguageController
import com.ondato.sdk.ui.compare.CompareFragment
import com.ondato.sdk.ui.document.SelectDocumentFragment
import com.ondato.sdk.ui.document.instructions.CaptureDocumentInstructionsFragment
import com.ondato.sdk.ui.document.instructions.CaptureSelfieWithDocumentInstructionsFragment
import com.ondato.sdk.ui.identification.result.IdentificationResultFragment
import com.ondato.sdk.ui.identification.result.IdentificationResultParameters
import com.ondato.sdk.ui.identification.waiting.IdentificationWaitingFragment
import com.ondato.sdk.ui.interrupted.InterruptedFragment
import com.ondato.sdk.ui.launcher.LauncherActivity
import com.ondato.sdk.ui.launcher.LauncherActivity.Companion.KEY_IS_RESTART
import com.ondato.sdk.ui.launcher.LauncherActivity.Companion.SHOULD_RESTART
import com.ondato.sdk.ui.liveness.active.ActiveLivenessCheckFragment
import com.ondato.sdk.ui.liveness.pasive.PassiveLivenessCheckFragment
import com.ondato.sdk.ui.main.Step.CAPTURE_DOCUMENT_BACK_INSTRUCTIONS
import com.ondato.sdk.ui.main.Step.CAPTURE_DOCUMENT_FRONT_INSTRUCTIONS
import com.ondato.sdk.ui.main.Step.CAPTURE_DOCUMENT_MRZ_INSTRUCTIONS
import com.ondato.sdk.ui.main.Step.CAPTURE_DOCUMENT_NFC_INSTRUCTIONS
import com.ondato.sdk.ui.main.Step.CAPTURE_FACE_INSTRUCTIONS
import com.ondato.sdk.ui.main.Step.CAPTURE_POA
import com.ondato.sdk.ui.main.Step.CAPTURE_POA_INSTRUCTIONS
import com.ondato.sdk.ui.main.Step.CAPTURE_SELFIE_WITH_DOCUMENT_INSTRUCTIONS
import com.ondato.sdk.ui.main.Step.COMPARE
import com.ondato.sdk.ui.main.Step.FAILURE_NFC
import com.ondato.sdk.ui.main.Step.FINISH
import com.ondato.sdk.ui.main.Step.FORCE_START
import com.ondato.sdk.ui.main.Step.IDENTIFICATION_WAITING_PAGE
import com.ondato.sdk.ui.main.Step.IDENTIFICATION_WAITING_PAGE_RESULT
import com.ondato.sdk.ui.main.Step.INITIALIZE
import com.ondato.sdk.ui.main.Step.MRZ_FAILURE
import com.ondato.sdk.ui.main.Step.MRZ_SUCCESS
import com.ondato.sdk.ui.main.Step.NFC_NOT_ALLOWED
import com.ondato.sdk.ui.main.Step.REGISTRATION
import com.ondato.sdk.ui.main.Step.SCAN_MRZ
import com.ondato.sdk.ui.main.Step.SCAN_NFC
import com.ondato.sdk.ui.main.Step.SELECT_DOCUMENT
import com.ondato.sdk.ui.main.Step.SELECT_POA_METHOD
import com.ondato.sdk.ui.main.Step.START
import com.ondato.sdk.ui.main.Step.SUCCESS
import com.ondato.sdk.ui.main.Step.TAKE_DOCUMENT_BACK
import com.ondato.sdk.ui.main.Step.TAKE_DOCUMENT_FRONT
import com.ondato.sdk.ui.main.Step.TAKE_FACE
import com.ondato.sdk.ui.main.Step.TAKE_SELFIE_WITH_DOCUMENT
import com.ondato.sdk.ui.main.Step.TERMS
import com.ondato.sdk.ui.main.Step.UPLOAD_POA
import com.ondato.sdk.ui.main.Step.WAITING
import com.ondato.sdk.ui.photo.PhotoFragment
import com.ondato.sdk.ui.poa.SelectPoaMethodFragment
import com.ondato.sdk.ui.poa.UploadPoaFragment
import com.ondato.sdk.ui.registration.RegistrationFragment
import com.ondato.sdk.ui.splash.SplashFragment
import com.ondato.sdk.ui.start.UiLanguage
import com.ondato.sdk.ui.terms.TermsAndConditionsFragment
import com.ondato.sdk.ui.tooManyAttempts.TooManyAttemptsFragment
import com.ondato.sdk.ui.waiting.WaitingFragment
import com.ondato.sdk.usecase.document.DocumentType
import com.ondato.sdk.usecase.identification.RejectedStatus
import com.ondato.sdk.usecase.identification.Status
import com.ondato.sdk.usecase.savephoto.LivenessMode
import com.ondato.sdk.usecase.savephoto.Mode
import com.ondato.sdk.usecase.session.Session
import kotlinx.coroutines.launch
import org.koin.androidx.viewmodel.ext.android.viewModel

class MainActivity : BaseActivity(), ErrorUi, UiLanguage {
    private val viewModel: MainViewModel by viewModel()
    private val language: LanguageController by koinInject()
    private val session: Session by koinInject()
    private val identificationResultParameters: IdentificationResultParameters by koinInject()
    private val broadcastReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            lifecycleScope.launch {
                when (intent?.action) {
                    "invoke_nfc_success" -> {
                        val data = intent.getSerializableExtra("data") as Step
                        viewModel.onStepSuccess(data)
                    }
                    "invoke_nfc_failure" -> {
                        val data = intent.getParcelableExtra<Failure>("data")
                        viewModel.onStepFailed(data ?: Failure.StartFailure)
                    }
                    "invoke_record_upload_success" -> {
                        viewModel.onStepSuccess(COMPARE)
                    }
                    "invoke_record_upload_failure" -> {
                        val data = intent.getParcelableExtra<Failure>("failureType")
                        viewModel.onStepFailed(data)
                    }
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        language.update(baseContext, session.language)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.ondato_activity_main)
        if (savedInstanceState == null) viewModel.init(Ondato.config)
        viewModel.step.observe(::showStep)
        viewModel.cancel.observe(::finishWithError)
        viewModel.success.observe(::returnSuccess)
        viewModel.showError.observe(::showError)
        viewModel.hideError.observe(::hideError)
        viewModel.restart.observe(::restart)
        viewModel.abort.observe(::abort)
        viewModel.interrupted.observe(::interrupted)
        R.id.errorTryAgainButton.onClick(viewModel::onRetryClicked)
        R.id.errorContinueAnywayButton.onClick { viewModel.onContinueAnywayClicked() }
        val isRestart = intent.extras?.getBoolean(KEY_IS_RESTART) ?: false
        if (isRestart) viewModel.handleTryAgain()

        //Logs picker is available only for our internal app
        //TODO: Also include the package name of react native internal app?
        val packageName = applicationContext.packageName
        if (packageName.equals("com.ondato.sdk.test")) {
            R.id.logsPicker.onClick {
                LogsBottomSheetFragment().show(supportFragmentManager, "bottom_sheet_tag")
            }
        } else {
            R.id.logsPicker.show(false)
        }

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        registerBroadcast()
    }

    override fun onStop() {
        super.onStop()
        viewModel.onStop()
    }

    override fun onDestroy() {
        unregisterBroadcast()
        super.onDestroy()
    }

    override fun onBackPressed() {
        viewModel.onBackClicked()
    }

    override fun showError(error: ErrorConfig) {
        R.id.errorTitleTextView.find<TextView>()?.setText(error.message.title)
        R.id.errorDescriptionTextView.find<TextView>()?.setText(error.message.message)
        R.id.errorTryAgainButton.find<Button>()?.setText(R.string.ondato_try_again)
        R.id.errorContinueAnywayButton.find<Button>()?.setText(R.string.ondato_continue_anyway)
        R.id.errorContinueAnywayButton.show(error.canContinue)
        ErrorMessageAnimator.show(
            R.id.errorTopLayout.view(),
            R.id.errorBottomLayout.view(),
            R.id.errorOverlay.view()
        )
    }

    private fun showStep(step: Step) {
        if (step == SELECT_DOCUMENT) session.currentPart = -1
        when (step) {
            INITIALIZE -> SplashFragment.newInstance().show()
            START -> Ondato.config.startScreenProvider.get(::onStartScreenCompleted).show()
            FORCE_START -> Ondato.config.startScreenProvider.get(::onStartScreenCompleted).show()
            TERMS -> TermsAndConditionsFragment.newInstance().show()
            REGISTRATION  -> RegistrationFragment.newInstance().show()
            CAPTURE_DOCUMENT_MRZ_INSTRUCTIONS -> {
                if (session.selectedType == DocumentType.DriverLicense) {
                    CaptureDocumentInstructionsFragment.newInstance(Mode.Front).show()
                } else {
                    CaptureDocumentInstructionsFragment.newInstance(
                        Mode.MRZ
                    ).show()
                }
            }
            CAPTURE_DOCUMENT_NFC_INSTRUCTIONS -> {
                if (session.selectedType == DocumentType.DriverLicense) {
                    CaptureDocumentInstructionsFragment.newInstance(Mode.Back).show()
                } else {
                    launchNfcActivity(step)
                }
            }
            NFC_NOT_ALLOWED, SCAN_NFC, FAILURE_NFC, SCAN_MRZ, MRZ_SUCCESS, MRZ_FAILURE -> launchNfcActivity(step)
            TAKE_FACE -> {
                when (Ondato.config.livenessCheck) {
                    Active -> ActiveLivenessCheckFragment.newInstance(LivenessMode.Liveness).show()
                    Passive -> PassiveLivenessCheckFragment.newInstance().show()
                }
            }
            SELECT_DOCUMENT -> SelectDocumentFragment.newInstance().show()
            CAPTURE_DOCUMENT_FRONT_INSTRUCTIONS ->
                CaptureDocumentInstructionsFragment.newInstance(Mode.Front).show()
            TAKE_DOCUMENT_FRONT -> PhotoFragment.newInstance(Mode.Front).show()
            CAPTURE_DOCUMENT_BACK_INSTRUCTIONS ->
                CaptureDocumentInstructionsFragment.newInstance(Mode.Back).show()
            TAKE_DOCUMENT_BACK -> PhotoFragment.newInstance(Mode.Back).show()
            CAPTURE_FACE_INSTRUCTIONS ->
                CaptureDocumentInstructionsFragment.newInstance(Mode.Selfie).show()
            CAPTURE_SELFIE_WITH_DOCUMENT_INSTRUCTIONS ->
                CaptureSelfieWithDocumentInstructionsFragment.newInstance().show()
            TAKE_SELFIE_WITH_DOCUMENT -> PhotoFragment.newInstance(Mode.Selfie).show()
            SELECT_POA_METHOD -> SelectPoaMethodFragment.newInstance().show()
            UPLOAD_POA -> UploadPoaFragment.newInstance().show()
            CAPTURE_POA_INSTRUCTIONS ->
                CaptureDocumentInstructionsFragment.newInstance(Mode.Address).show()
            CAPTURE_POA -> PhotoFragment.newInstance(Mode.Address).show()
            COMPARE -> CompareFragment.newInstance().show()
            WAITING -> WaitingFragment.newInstance().show()
            SUCCESS -> Ondato.config.successScreenProvider.get(::onSuccessScreenCompleted).show()
            IDENTIFICATION_WAITING_PAGE -> IdentificationWaitingFragment.newInstance().show()
            IDENTIFICATION_WAITING_PAGE_RESULT -> {
                val rejectedStatus = when (val params = identificationResultParameters.take()) {
                    is Status.Finished.Success -> null
                    is Status.Finished.Rejected -> params.rejectedStatus
                    null -> RejectedStatus.SomethingWentWrong
                }
                IdentificationResultFragment.newInstance(rejectedStatus).show()
            }
            Step.FACE_AUTH_SUCCESS -> {

                IdentificationResultFragment.newInstance(null).show()
            }
            Step.FACE_AUTH -> ActiveLivenessCheckFragment.newInstance(LivenessMode.FaceAuth).show()
            Step.TOO_MANY_ATTEMPTS -> TooManyAttemptsFragment.newInstance().show()
            FINISH -> returnSuccess()
        }
        updateProgress(step)
    }

    private fun hideError() {
        ErrorMessageAnimator.hide(
            R.id.errorTopLayout.view(),
            R.id.errorBottomLayout.view(),
            R.id.errorOverlay.view()
        )
    }

    override fun setLanguage(language: Language) {
        this.language.update(baseContext, language)
        showStep(START)
    }

    private fun returnSuccess() {
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setResult(Activity.RESULT_OK)
        lifecycleScope.launch {
            viewModel.completeSession()
        }
        finish()
    }

    private fun Fragment.show() {
        supportFragmentManager.commit { replace(R.id.container, this@show) }
    }

    private fun updateProgress(step: Step) {
        R.id.ondatoProgress.find<ProgressBar>()?.apply {
            progress = Progress.resolve(step)
            visibility = if (step.order >= TERMS.order) View.VISIBLE else View.GONE
        }
    }

    private fun restart() {
        setResult(
            RESULT_CANCELED,
            Intent().apply {
                putExtra(SHOULD_RESTART, true)
                putExtra("requestCode", intent.extras?.getInt("requestCode"))
            }
        )
        finish()
    }

    private fun abort() {
        setResult(RESULT_CANCELED)
        val intent = Intent("invoke_record_cancel")
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent)
        finish()
    }

    private fun interrupted() {
        InterruptedFragment().show()
    }

    private fun onStartScreenCompleted() {
        viewModel.onStepSuccess(START)
    }

    private fun onSuccessScreenCompleted() {
        viewModel.onStepSuccess(SUCCESS)
    }

    private fun finishWithError(error: OndatoError) {
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setResult(RESULT_CANCELED, Intent().apply { putExtra(LauncherActivity.KEY_ERROR, error) })
        finish()
    }

    private fun launchNfcActivity(step: Step) {
        try {
            val intent = Intent()
            intent.setClassName(this.packageName, "com.ondato.sdk.nfcreader.ui.NfcActivity")
            intent.putExtra("session", session)
            intent.putExtra("step", step)
            startActivity(intent)
        } catch (exception: RuntimeException) {
            throw FeatureNotIncludedException("NFC feature is not included inside build.gradle file")
        }
    }

    private fun registerBroadcast() {
        val instance = LocalBroadcastManager.getInstance(this)
        with(instance) {
            registerReceiver(broadcastReceiver, IntentFilter("invoke_nfc_success"))
            registerReceiver(broadcastReceiver, IntentFilter("invoke_nfc_failure"))
            registerReceiver(broadcastReceiver, IntentFilter("invoke_record_upload_success"))
            registerReceiver(broadcastReceiver, IntentFilter("invoke_record_upload_failure"))
        }
    }

    private fun unregisterBroadcast() =
        LocalBroadcastManager.getInstance(this).unregisterReceiver(broadcastReceiver)

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        Logger.d("New Intent")
        (supportFragmentManager.fragments.lastOrNull() as? BaseFragment)?.onNewIntent(intent)
    }

    companion object {
        fun newIntent(context: Context?) = Intent(context, MainActivity::class.java)
    }
}