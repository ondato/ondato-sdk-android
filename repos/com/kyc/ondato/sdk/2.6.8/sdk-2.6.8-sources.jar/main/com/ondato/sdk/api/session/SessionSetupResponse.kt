package com.ondato.sdk.api.session

import androidx.annotation.Keep
import com.google.gson.annotations.SerializedName
import com.ondato.sdk.usecase.session.configuration.*

@Keep
internal data class SessionSetupResponse(
    @SerializedName("id") var id: String? = null,
    @SerializedName("applicationId") var applicationId: String? = null,
    @SerializedName("resourceDirectoryName") var resourceDirectoryName: String? = null,
    @SerializedName("generalAppSetting") var generalAppSetting: GeneralAppSettingResponse? = null,
    @SerializedName("webAppSetting") var webAppSetting: WebAppSettingResponse? = null,
    @SerializedName("omnichannel") var omnichannel: OmnichannelResponse? = null,
    @SerializedName("sessionScreenRecording")
    var sessionScreenRecording: SessionScreenRecordingResponse? = null,
    @SerializedName("steps") var steps: ArrayList<StepsResponse> = arrayListOf(),
) {

    fun toSessionSetup(): SessionSetup {
        return SessionSetup(
            id ?: "",
            applicationId ?: "",
            resourceDirectoryName ?: "",
            generalAppSetting?.toGeneralAppSetting() ?: GeneralAppSetting.EMPTY,
            webAppSetting?.toWebAppSetting() ?: WebAppSetting.EMPTY,
            omnichannel?.toOmnichannel() ?: Omnichannel.EMPTY,
            sessionScreenRecording?.toSessionScreenRecording() ?: SessionScreenRecording.EMPTY,
            steps.map { it.toSteps() }.sortedBy { it.order }    // kycSetup driven step order
        )
    }
}

@Keep
internal data class GeneralAppSettingResponse(
    @SerializedName("supportEmail") var supportEmail: String? = null
) {

    internal fun toGeneralAppSetting(): GeneralAppSetting {
        return GeneralAppSetting(supportEmail ?: "")
    }
}

@Keep
internal data class LocalisationSettingsResponse(
    @SerializedName("language") var language: String? = null,
    @SerializedName("successRedirectUrl") var successRedirectUrl: String? = null,
    @SerializedName("consentDeclinedRedirectUrl") var consentDeclinedRedirectUrl: String? = null,
    @SerializedName("failureRedirectUrl") var failureRedirectUrl: String? = null,
    @SerializedName("pageTitle") var pageTitle: String? = null
) {

    internal fun toLocalisationSettings(): LocalisationSettings {
        return LocalisationSettings(
            language ?: "",
            successRedirectUrl ?: "",
            consentDeclinedRedirectUrl ?: "",
            failureRedirectUrl ?: "",
            pageTitle ?: "",
        )
    }
}

@Keep
internal data class StepsResponse(
    @SerializedName("type") var type: Type? = null,
    @SerializedName("order") var order: Int? = null,
    @SerializedName("setupId") var setupId: String? = null
) {

    internal fun toSteps(): Steps = Steps(
        Steps.Type.of(type?.name ?: ""),
        order ?: -1,
        setupId ?: ""
    )

    @Keep
    internal enum class Type(val type: String) {
        Consent("Consent"),
        Registration("Registration"),
        KycIdentification("KycIdentification"),
        FaceAuthentication("FaceAuthentication"),
        Unknown("");
    }
}

@Keep
internal data class WebAppSettingResponse(
    @SerializedName("baseUrl") var baseUrl: String? = null,
    @SerializedName("localisationSettings")
    var localisationSettings: ArrayList<LocalisationSettingsResponse> = arrayListOf(),
    @SerializedName("declinedBrowserPermissionsBaseUrl")
    var declinedBrowserPermissionsBaseUrl: String? = null
) {

    internal fun toWebAppSetting(): WebAppSetting {
        return WebAppSetting(
            baseUrl ?: "",
            declinedBrowserPermissionsBaseUrl ?: "",
            localisationSettings.map { it.toLocalisationSettings() },
        )
    }
}

@Keep
internal data class SessionScreenRecordingResponse(
    @SerializedName("enabled") var enabled: Boolean? = null
) {

    internal fun toSessionScreenRecording(): SessionScreenRecording {
        return SessionScreenRecording(enabled ?: false)
    }
}

@Keep
internal data class OmnichannelResponse(
    @SerializedName("enabled") var enabled: Boolean? = null,
    @SerializedName("appStoreEnabled") var appStoreEnabled: Boolean? = null
) {

    internal fun toOmnichannel(): Omnichannel {
        return Omnichannel(enabled ?: false, appStoreEnabled ?: false)
    }
}