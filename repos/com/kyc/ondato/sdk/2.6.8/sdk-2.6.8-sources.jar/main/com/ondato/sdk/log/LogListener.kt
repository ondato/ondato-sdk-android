package com.ondato.sdk.log

import com.ondato.sdk.Ondato
import com.ondato.sdk.OndatoError

internal object LogListener : Ondato.ResultListener {
    override fun onSuccess(identificationId: String?) {
        Logger.d("Authorization Completed Successfully")
    }

    override fun onFailure(identificationId: String?, error: OndatoError) {
        Logger.d("Authorization Failed : ${error.message}")
//        Logger.log(Event.SessionCompleted)
    }
}