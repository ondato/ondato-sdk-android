package com.ondato.sdk.api.logs

import com.google.gson.annotations.SerializedName

internal data class LogRequest(@SerializedName("action") val action: String)