package com.ondato.sdk.usecase

import androidx.annotation.Keep

@Keep
internal enum class ImageFileType(val type: String) {
    Jpeg("Jpeg"),
    Png("Png");
}