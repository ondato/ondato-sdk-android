package com.ondato.sdk.ui.identification.waiting

import android.os.Bundle
import android.view.View
import com.ondato.sdk.Ondato
import com.ondato.sdk.OndatoConfig
import com.ondato.sdk.R
import com.ondato.sdk.log.Logger
import com.ondato.sdk.ui.base.BaseFragment
import com.ondato.sdk.ui.main.MainViewModel
import com.ondato.sdk.ui.main.Step
import com.ondato.sdk.usecase.identification.Status
import org.koin.androidx.viewmodel.ext.android.sharedViewModel
import org.koin.androidx.viewmodel.ext.android.viewModel

internal class IdentificationWaitingFragment : BaseFragment(
    layoutId = R.layout.ondato_fragment_identification_waiting
) {

    private val viewModel by viewModel<IdentificationWaitingViewModel>()
    private val mainViewModel by sharedViewModel<MainViewModel>()
    private val config: OndatoConfig = Ondato.config
    private var tryAgain: Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (savedInstanceState == null) viewModel.init(config)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel.state.observeOnView {
            R.id.ondatoWaitingPagePercentage.text(it.percentage.toString())
            val message = TimeToTextHelper.convertTimeToResource(it.time)
            R.id.ondatoWaitingPageMessage.text(message)
        }

        viewModel.completed.observe {
            mainViewModel.onStepSuccess(Step.IDENTIFICATION_WAITING_PAGE)
        }

        viewModel.rejectionReason.observe { status ->
            if (status is Status.Finished.Success) {
                tryAgain = false
            } else if (status is Status.Finished.Rejected) {
                tryAgain = status.rejectedStatus.tryAgain
            }
        }
    }

    companion object {
        fun newInstance() = IdentificationWaitingFragment()
    }
}