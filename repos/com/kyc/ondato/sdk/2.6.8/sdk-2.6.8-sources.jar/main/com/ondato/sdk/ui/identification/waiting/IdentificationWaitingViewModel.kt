package com.ondato.sdk.ui.identification.waiting

import android.os.CountDownTimer
import com.ondato.sdk.OndatoConfig
import com.ondato.sdk.log.Event
import com.ondato.sdk.log.Logger
import com.ondato.sdk.ui.base.BaseViewModel
import com.ondato.sdk.ui.base.State
import com.ondato.sdk.ui.base.event
import com.ondato.sdk.ui.base.set
import com.ondato.sdk.ui.identification.result.IdentificationResultParameters
import com.ondato.sdk.usecase.identification.IdentificationUseCase
import com.ondato.sdk.usecase.identification.RejectedStatus
import com.ondato.sdk.usecase.identification.Status
import com.ondato.sdk.usecase.session.CompleteSessionUseCase
import com.ondato.sdk.usecase.session.Session
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive

internal class IdentificationWaitingViewModel(
    private val session: Session,
    private val identificationUseCase: IdentificationUseCase,
    private val identificationResultParameters: IdentificationResultParameters,
    private val completeSessionUseCase: CompleteSessionUseCase,
) : BaseViewModel() {

    private var fastTimer: CountDownTimer? = null

    val state by State<IdentificationWaitingState>()

    val completed by event<Status.Finished>()

    val rejectionReason by event<Status.Finished>()

    fun init(config: OndatoConfig) {
        val fullTimeInMillis = BASE_TIME_IN_MILLIS + SLOWER_TIME_IN_MILLIS
        fastTimer = object : CountDownTimer(fullTimeInMillis, INTERVAL_IN_MILLIS) {
            override fun onTick(millisUntilFinished: Long) {
                val millisElapsed = (fullTimeInMillis - millisUntilFinished).toFloat()
                val timeInSeconds = (millisElapsed / 1000).toInt()
                val percentage = if (millisElapsed >= BASE_TIME_IN_MILLIS) {
                    val partElapsed = (millisElapsed - BASE_TIME_IN_MILLIS) / SLOWER_TIME_IN_MILLIS
                    SLOWER_PERCENTAGE_WALL + (partElapsed * 10).toInt()
                } else {
                    ((millisElapsed / BASE_TIME_IN_MILLIS) * SLOWER_PERCENTAGE_WALL).toInt()
                }
                state.set(IdentificationWaitingState(percentage, timeInSeconds))
            }

            override fun onFinish() {}
        }.apply { start() }

        launch {
            while (isActive) {
                delay(TIME_PER_REQUEST)
                try {
                    val kycId = session.kycId
                    val result = identificationUseCase.getIdentification(kycId)
                    when (val status = result.status) {
                        is Status.Awaiting -> continue
                        is Status.Finished -> {
                            onIdentificationFinished(status)
                            break
                        }
                    }
                } catch (exception: Exception) {
                    Logger.log(Event.IdentificationFailed)
                    Logger.d("Identification failed: ${exception.localizedMessage}")
                    onIdentificationFailed()
                }
            }
        }
    }

    private fun onIdentificationFinished(status: Status.Finished) {
        Logger.d("Identification status: $status")
        launch {
            if (status == Status.Finished.Success || (status is Status.Finished.Rejected && !status.rejectedStatus.tryAgain)) {
                completeSessionUseCase.complete()
            }
            identificationResultParameters.set(status)
            fastTimer?.cancel()
            rejectionReason.set(status)
            completed.set(Status.Finished.Rejected(RejectedStatus.DataNotMatch))
        }
    }

    private fun onIdentificationFailed() {
        completed.set(Status.Finished.Rejected(RejectedStatus.MISCELLANEOUS))
    }

    fun isSessionCompleted(): Boolean {
        return session.sessionCompleted
    }

    override fun onCleared() {
        super.onCleared()
        fastTimer?.cancel()
    }

    companion object {
        private const val BASE_TIME_IN_MILLIS = 120000L
        private const val INTERVAL_IN_MILLIS = 100L
        private const val SLOWER_PERCENTAGE_WALL = 90
        private const val SLOWER_TIME_IN_MILLIS = 50000L
        private const val TIME_PER_REQUEST = 3000L
    }
}

internal data class IdentificationWaitingState(val percentage: Int, val time: Int)