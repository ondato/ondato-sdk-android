package com.ondato.sdk.ui.base

import android.view.View
import android.widget.ImageView
import android.widget.TextView
import androidx.annotation.DrawableRes
import androidx.annotation.LayoutRes
import androidx.annotation.StringRes
import androidx.fragment.app.DialogFragment
import androidx.fragment.app.Fragment
import androidx.fragment.app.commit
import androidx.lifecycle.LiveData
import com.ondato.sdk.di.DependencyInjectionEntry
import com.ondato.sdk.ui.main.ErrorConfig
import com.ondato.sdk.ui.main.ErrorUi

abstract class BaseDialogFragment(
    @LayoutRes layoutId: Int
) : DialogFragment(layoutId), DependencyInjectionEntry {
    private val binding = ViewBinding { view }

    override fun onDestroyView() {
        binding.clear()
        super.onDestroyView()
    }

    protected fun <T> LiveData<T>.observe(action: (T) -> Unit) {
        this.observe(this@BaseDialogFragment) { value -> value?.let(action) }
    }

    protected fun LiveData<Unit>.observe(action: () -> Unit) {
        this.observe(this@BaseDialogFragment) { action() }
    }

    protected fun <T> LiveData<T>.observeOnView(action: (T) -> Unit) {
        this.observe(viewLifecycleOwner) { value -> value?.let(action) }
    }

    protected fun LiveData<Unit>.observeOnView(action: () -> Unit) {
        this.observe(viewLifecycleOwner) { action() }
    }

    protected open fun showError(errorMessage: ErrorConfig) {
        (activity as? ErrorUi)?.showError(errorMessage)
    }

    protected fun <T : View> Int.find(): T? {
        return binding.find(this)
    }

    protected fun Int.view(): View? {
        return binding.find(this)
    }

    protected fun View?.onClick(action: () -> Unit) {
        this?.setOnClickListener { action() }
    }

    protected fun Int.onClick(action: () -> Unit) {
        view()?.onClick(action)
    }

    protected fun Int.show() {
        view()?.visibility = View.VISIBLE
    }

    protected fun Int.show(isVisible: Boolean) {
        view()?.visibility = if (isVisible) View.VISIBLE else View.GONE
    }

    protected fun Int.hide() {
        view()?.visibility = View.GONE
    }

    protected fun Int.invisible() {
        view()?.visibility = View.INVISIBLE
    }

    protected fun Int.src(@DrawableRes drawableId: Int) {
        find<ImageView>()?.setImageResource(drawableId)
    }

    protected fun Int.text(@StringRes stringId: Int) {
        find<TextView>()?.setText(stringId)
    }

    protected fun Int.text(string: String) {
        find<TextView>()?.text = string
    }

    protected fun Fragment.show(container: Int) {
        this@BaseDialogFragment.childFragmentManager.commit { replace(container, this@show) }
    }
}