package com.ondato.sdk.ui.identification.waiting

import androidx.annotation.StringRes
import com.ondato.sdk.R

object TimeToTextHelper {

    @StringRes
    fun convertTimeToResource(percentage:Int): Int {
        return when(percentage) {
            in 0 .. 7 -> R.string.ondato_waiting_page_encrypt_data
            in 8 .. 15 -> R.string.ondato_waiting_page_verify_your_identity
            in 16 .. 23 -> R.string.ondato_waiting_page_check_if_all_photos_uploaded
            in 24 .. 31 -> R.string.ondato_waiting_page_documents_clearly_legible
            in 32 .. 39 -> R.string.ondato_waiting_page_external_damage
            in 40 .. 47 -> R.string.ondato_waiting_page_document_obscured
            in 48 .. 55 -> R.string.ondato_waiting_page_document_facial_image
            in 56 .. 63 -> R.string.ondato_waiting_page_facial_photo_obscured
            in 64 .. 71 -> R.string.ondato_waiting_page_no_other_person
            in 72 .. 79 -> R.string.ondato_waiting_page_scan_document
            in 80 .. 87 -> R.string.ondato_waiting_page_biometric_data
            in 88 .. 95 -> R.string.ondato_waiting_page_ai_check
            in 96 .. 103 -> R.string.ondato_waiting_page_authenticity
            in 104 .. 111 -> R.string.ondato_waiting_page_data_in_registers
            in 112 .. 120 -> R.string.ondato_waiting_page_encrypt_data_for_final_approval
            else -> R.string.ondato_waiting_page_taking_longer_than_expected
        }
    }
}