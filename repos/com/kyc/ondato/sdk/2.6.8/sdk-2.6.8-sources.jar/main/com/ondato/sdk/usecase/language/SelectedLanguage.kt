package com.ondato.sdk.usecase.language

import com.ondato.sdk.enums.Language
import kotlinx.coroutines.runBlocking

internal class SelectedLanguage(
    private val useCase: SelectedLanguageUseCase
) {
    fun get(): Language {
        return runBlocking { useCase.get() }
    }

    fun set(languages: Language) {
        runBlocking { useCase.set(languages) }
    }

    fun clear() {
        runBlocking { useCase.clear() }
    }
}