package com.ondato.sdk.usecase.savephoto

import java.io.File

internal interface PhotoStorage {
    suspend fun save(byteArray: ByteArray, mode: Mode): File

    suspend fun save(frames: List<ByteArray>): File

    suspend fun delete(file: File)

    suspend fun clear()
}