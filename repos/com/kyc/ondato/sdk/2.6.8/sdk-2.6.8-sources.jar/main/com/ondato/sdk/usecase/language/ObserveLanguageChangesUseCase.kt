package com.ondato.sdk.usecase.language

import com.ondato.sdk.enums.Language
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow

internal class ObserveLanguageChangesUseCase(
    private val storage: SelectedLanguageStorage
) {
    @ExperimentalCoroutinesApi
    suspend fun observe(): Flow<Language> {
        return storage.observe()
    }
}