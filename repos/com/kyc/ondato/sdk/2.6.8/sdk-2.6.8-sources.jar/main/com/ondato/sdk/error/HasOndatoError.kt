package com.ondato.sdk.error

internal interface HasOndatoError {
    val error: ApiError?
}