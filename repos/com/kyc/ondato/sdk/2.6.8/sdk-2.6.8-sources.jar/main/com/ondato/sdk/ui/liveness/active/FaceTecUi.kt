package com.ondato.sdk.ui.liveness.active

import android.app.Activity
import androidx.lifecycle.Observer
import com.facetec.sdk.*
import com.facetec.sdk.FaceTecSDK.InitializeCallback
import com.ondato.sdk.log.Logger
import com.ondato.sdk.usecase.liveness.LivenessLicenseInfo

internal class FaceTecUi(
    private val viewModel: FaceTecViewModel,
    private val onSuccess: () -> Unit,
    private val onFailure: (LivenessError) -> Unit
) {
    private var ui: FaceTecFaceScanResultCallback? = null
    private val failedObserver = Observer(::cancel)
    private val successObserver = Observer<Unit> { success() }

    init {
        viewModel.failed.observeForever(failedObserver)
        viewModel.completed.observeForever(successObserver)
    }

    fun start(info: LivenessLicenseInfo, activity: Activity) {
        FaceTecSDK.setCustomization(FaceTecUiConfig.get(activity))
        FaceTecSDK.setMaxAuditTrailImages(FaceTecAuditTrailImagesToReturn.UP_TO_SIX)
        FaceTecSDK.initializeInProductionMode(
            activity,
            info.key,
            info.deviceKeyIdentifier,
            info.publicFaceScanEncryptionKey,
            initializeCallback(activity, info.token)
        )
    }

    fun stop() {
        viewModel.completed.removeObserver(successObserver)
        viewModel.failed.removeObserver(failedObserver)
    }

    private fun initializeCallback(activity: Activity, token: String): InitializeCallback {
        return object : InitializeCallback {
            override fun onCompletion(isSuccess: Boolean) {
                FaceTecSessionActivity.createAndLaunchSession(
                    activity,
                    ::onInitialized,
                    token
                )
            }
        }
    }

    private fun onInitialized(
        result: FaceTecSessionResult,
        callback: FaceTecFaceScanResultCallback
    ) {
        ui = callback
        viewModel.onFaceTecResult(result)
    }

    // Default behaviour is retry
    private fun cancel(cause: LivenessError) {
        if (cause == LivenessError.MaxAttemptsReached || cause == LivenessError.Canceled) {
            ui?.cancel()
            onFailure(cause)
            stop()
        } else {
            ui?.retry()
        }
//        ui?.cancel()
//        ui = null
//        onFailure(cause)
//        stop()
    }

    private fun success() {
        ui?.succeed()
        onSuccess()
        stop()
    }
}