package com.ondato.sdk.api.token

import com.ondato.sdk.usecase.session.token.Token

internal object TokenResponseMapper {

    fun map(response: TokenResponseV2): Token {
        return Token(token = response.accessToken ?: "", type = response.tokenType ?: "")
    }
}