package com.ondato.sdk.enums

import androidx.annotation.Keep

@Keep
internal data class DocumentInfo(val type: Type, val parts: List<Part>) {

    enum class Type(val type: String) {
        Passport("PASSPORT"),
        IdCard("ID_CARD"),
        DriverLicense("DRIVER_LICENSE"),
        Unknown("Unknown");

        companion object {
            fun of(type: String): Type {
                return values().firstOrNull { it.type == type } ?: Unknown
            }
        }

    }

    enum class Part(val id: String) {
        Front("Front"),
        Back("Back"),
        Selfie("Selfie"),
        Address("Address"),
        MRZ("MRZ"),
    }
}