package com.ondato.sdk.ui.launcher

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings

object Settings {
    fun show(context: Context) {
        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        intent.data = Uri.fromParts("package", context.applicationContext.packageName, null)
        context.startActivity(intent)
    }
}