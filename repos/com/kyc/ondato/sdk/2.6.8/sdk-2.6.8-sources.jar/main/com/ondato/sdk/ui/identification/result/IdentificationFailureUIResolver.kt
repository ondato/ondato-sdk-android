package com.ondato.sdk.ui.identification.result

import com.ondato.sdk.R
import com.ondato.sdk.usecase.identification.RejectedStatus

internal object IdentificationFailureUIResolver {

    fun get(rejectedStatus: RejectedStatus): Data {
        return when (rejectedStatus) {
            RejectedStatus.MissingDocumentPhoto -> Data(
                title = R.string.ondato_missing_document_photo_primary,
                body = R.string.ondato_missing_document_photo_second,
                button = rejectedStatus.tryAgain.getButtonTitle(),
            )
            RejectedStatus.DocumentNotAccepted -> Data(
                title = R.string.ondato_document_not_accepted_primary,
                body = R.string.ondato_document_not_accepted_second,
                button = rejectedStatus.tryAgain.getButtonTitle(),
            )
            RejectedStatus.DataNotMatch -> Data(
                title = R.string.ondato_data_does_not_match_primary,
                body = R.string.ondato_data_does_not_match_second,
                button = rejectedStatus.tryAgain.getButtonTitle(),
            )
            RejectedStatus.Sanctioned -> Data(
                title = R.string.ondato_sanctioned_primary,
                body = R.string.ondato_sanctioned_second,
                button = rejectedStatus.tryAgain.getButtonTitle(),
            )
            RejectedStatus.MissingPersonPhoto -> Data(
                title = R.string.ondato_missing_selfie_photo_primary,
                body = R.string.ondato_missing_selfie_photo_second,
                button = rejectedStatus.tryAgain.getButtonTitle(),
            )
            RejectedStatus.FacesNotMatch -> Data(
                title = R.string.ondato_faces_does_not_match_primary,
                body = R.string.ondato_faces_does_not_match_second,
                button = rejectedStatus.tryAgain.getButtonTitle(),
            )
            RejectedStatus.PoorPhotoQuality -> Data(
                title = R.string.ondato_poor_photo_quality_primary,
                body = R.string.ondato_poor_photo_quality_second,
                button = rejectedStatus.tryAgain.getButtonTitle(),
            )
            RejectedStatus.PoorPhotoLighting -> Data(
                title = R.string.ondato_poor_photo_lighting_primary,
                body = R.string.ondato_poor_photo_lighting_second,
                button = rejectedStatus.tryAgain.getButtonTitle(),
            )
            RejectedStatus.MISCELLANEOUS -> Data(
                title = R.string.ondato_miscellaneous_primary,
                body = R.string.ondato_miscellaneous_second,
                button = rejectedStatus.tryAgain.getButtonTitle(),
            )
            RejectedStatus.PossibleFraudAttempt -> Data(
                title = R.string.ondato_possible_fraud_attempt_primary,
                body = R.string.ondato_possible_fraud_attempt_second,
                button = rejectedStatus.tryAgain.getButtonTitle(),
            )
            RejectedStatus.UnrelatedPhotoSubmit -> Data(
                title = R.string.ondato_unrelated_photo_primary,
                body = R.string.ondato_unrelated_photo_second,
                button = rejectedStatus.tryAgain.getButtonTitle(),
            )
            RejectedStatus.MoreThanOnePerson -> Data(
                title = R.string.ondato_more_than_one_person_primary,
                body = R.string.ondato_more_than_one_person_second,
                button = rejectedStatus.tryAgain.getButtonTitle(),
            )
            RejectedStatus.ProhibitedCountryOrState -> Data(
                title = R.string.ondato_prohibited_country_or_state_primary,
                body = R.string.ondato_prohibited_country_or_state_second,
                button = rejectedStatus.tryAgain.getButtonTitle(),
            )
            RejectedStatus.DocumentIsExpired -> Data(
                title = R.string.ondato_document_is_expired_primary,
                body = R.string.ondato_document_is_expired_second,
                button = rejectedStatus.tryAgain.getButtonTitle(),
            )
            RejectedStatus.DocumentWithNonLatinCharacters -> Data(
                title = R.string.ondato_document_with_non_latin_characters_primary,
                body = R.string.ondato_document_with_non_latin_characters_second,
                button = rejectedStatus.tryAgain.getButtonTitle(),
            )
            RejectedStatus.PartOfDocumentIsCovered -> Data(
                title = R.string.ondato_part_of_document_is_covered_primary,
                body = R.string.ondato_part_of_document_is_covered_second,
                button = rejectedStatus.tryAgain.getButtonTitle(),
            )
            RejectedStatus.PartOfFaceIsCovered -> Data(
                title = R.string.ondato_part_of_face_is_covered_primary,
                body = R.string.ondato_part_of_face_is_covered_second,
                button = rejectedStatus.tryAgain.getButtonTitle(),
            )
            RejectedStatus.UnderagePerson -> Data(
                title = R.string.ondato_underage_person_primary,
                body = R.string.ondato_underage_person_second,
                button = rejectedStatus.tryAgain.getButtonTitle(),
            )
            RejectedStatus.ProhibitedNationality -> Data(
                title = R.string.ondato_prohibited_nationality_primary,
                body = R.string.ondato_prohibited_nationality_second,
                button = rejectedStatus.tryAgain.getButtonTitle(),
            )
            RejectedStatus.DuplicatedInfo -> Data(
                title = R.string.ondato_duplicated_info_primary,
                body = R.string.ondato_duplicated_info_second,
                button = rejectedStatus.tryAgain.getButtonTitle(),
            )
            RejectedStatus.FacePhotoUploadFormat -> Data(
                title = R.string.ondato_bad_media_format_primary,
                body = R.string.ondato_bad_media_format_second,
                button = rejectedStatus.tryAgain.getButtonTitle()
            )
            RejectedStatus.TransferToVideoCall -> Data(
                title = R.string.ondato_transfer_video_call_primary,
                body = R.string.ondato_transfer_video_call_second,
                button = rejectedStatus.tryAgain.getButtonTitle()
            )
            RejectedStatus.Unfinished -> Data(
                title = R.string.ondato_something_went_wrong_primary,
                body = R.string.ondato_something_went_wrong_second,
                button = rejectedStatus.tryAgain.getButtonTitle()
            )
            RejectedStatus.Processing -> Data(
                title = R.string.ondato_something_went_wrong_primary,
                body = R.string.ondato_something_went_wrong_second,
                button = rejectedStatus.tryAgain.getButtonTitle()
            )
            RejectedStatus.AutomaticallyIdentified -> Data(
                title = R.string.ondato_something_went_wrong_primary,
                body = R.string.ondato_something_went_wrong_second,
                button = rejectedStatus.tryAgain.getButtonTitle()
            )
            RejectedStatus.ManuallyIdentified -> Data(
                title = R.string.ondato_something_went_wrong_primary,
                body = R.string.ondato_something_went_wrong_second,
                button = rejectedStatus.tryAgain.getButtonTitle()
            )
            RejectedStatus.SomethingWentWrong -> Data(
                title = R.string.ondato_something_went_wrong_primary,
                body = R.string.ondato_something_went_wrong_second,
                button = rejectedStatus.tryAgain.getButtonTitle()
            )
            RejectedStatus.BAD_MEDIA_FORMAT -> {
                Data(
                    title = R.string.ondato_bad_media_format_primary,
                    body = R.string.ondato_bad_media_format_second,
                    button = rejectedStatus.tryAgain.getButtonTitle()
                )
            }
        }
    }

    private fun Boolean.getButtonTitle(): Int {
        return if (this) {
            R.string.ondato_waiting_page_failure_try_again_title
        } else {
            R.string.ondato_waiting_page_failure_close_title
        }
    }

    data class Data(
        val title: Int,
        val body: Int,
        val button: Int,
    )
}