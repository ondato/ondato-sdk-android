package com.ondato.sdk.api.nfc

import com.ondato.sdk.api.BackendApi
import com.ondato.sdk.usecase.nfc.NFCApi

internal class NFCUploadApiService(private val api: BackendApi) : NFCApi {

    override suspend fun send(kycId: String, body: NFCUploadRequestV2) {
        api.sendNFCPersonalDetails(kycId, body)
    }
}