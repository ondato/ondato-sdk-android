package com.ondato.sdk.ui

import com.ondato.sdk.ui.base.LanguageController
import com.ondato.sdk.ui.compare.CompareViewModel
import com.ondato.sdk.ui.document.SelectDocumentViewModel
import com.ondato.sdk.ui.document.instructions.CaptureDocumentInstructionsViewModel
import com.ondato.sdk.ui.identification.result.IdentificationResultParameters
import com.ondato.sdk.ui.identification.result.IdentificationResultViewModel
import com.ondato.sdk.ui.identification.waiting.IdentificationWaitingViewModel
import com.ondato.sdk.ui.interrupted.InterruptedViewModel
import com.ondato.sdk.ui.launcher.LauncherViewModel
import com.ondato.sdk.ui.liveness.active.FaceTecViewModel
import com.ondato.sdk.ui.liveness.active.LivenessViewModel
import com.ondato.sdk.ui.liveness.pasive.PassiveCheckViewModel
import com.ondato.sdk.ui.main.MainViewModel
import com.ondato.sdk.ui.main.StepResolver
import com.ondato.sdk.ui.photo.PhotoViewModel
import com.ondato.sdk.ui.poa.UploadPoaViewModel
import com.ondato.sdk.ui.registration.RegistrationViewModel
import com.ondato.sdk.ui.splash.SplashViewModel
import com.ondato.sdk.ui.start.StartViewModel
import com.ondato.sdk.ui.terms.TermsViewModel
import com.ondato.sdk.ui.waiting.WaitingViewModel
import org.koin.androidx.viewmodel.dsl.viewModel
import org.koin.dsl.module

internal val uiModule = module {
    single { StepResolver(get()) }
    single { IdentificationResultParameters() }
    factory { LanguageController() }
    viewModel { MainViewModel(get(), get(), get()) }
    viewModel { SplashViewModel(get(), get()) }
    viewModel { LauncherViewModel(get(), get()) }
    viewModel { StartViewModel(get()) }
    viewModel { TermsViewModel(get()) }
    viewModel { SelectDocumentViewModel(get()) }
    viewModel { CaptureDocumentInstructionsViewModel(get()) }
    viewModel { PhotoViewModel(get(), get(), get()) }
    viewModel { CompareViewModel(get()) }
    viewModel { LivenessViewModel(get()) }
    viewModel { WaitingViewModel() }
    viewModel { FaceTecViewModel(get()) }
    viewModel { PassiveCheckViewModel(get()) }
    viewModel { IdentificationWaitingViewModel(get(), get(), get(), get()) }
    viewModel { IdentificationResultViewModel(get() ) }
    viewModel { InterruptedViewModel() }
    viewModel { RegistrationViewModel(get()) }
    viewModel { UploadPoaViewModel(get()) }
}