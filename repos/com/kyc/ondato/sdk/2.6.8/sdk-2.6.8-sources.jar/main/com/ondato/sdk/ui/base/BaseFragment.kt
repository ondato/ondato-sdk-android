package com.ondato.sdk.ui.base

import android.content.Intent
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import androidx.annotation.DrawableRes
import androidx.annotation.LayoutRes
import androidx.annotation.StringRes
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.fragment.app.Fragment
import androidx.fragment.app.commit
import androidx.lifecycle.LiveData
import com.ondato.sdk.di.DependencyInjectionEntry
import com.ondato.sdk.ui.main.ErrorConfig
import com.ondato.sdk.ui.main.ErrorUi

abstract class BaseFragment(
    @LayoutRes layoutId: Int
) : Fragment(layoutId), DependencyInjectionEntry {
    private val binding = ViewBinding { view }

    override fun onDestroyView() {
        binding.clear()
        super.onDestroyView()
    }

    protected fun <T> LiveData<T>.observe(action: (T) -> Unit) {
        this.observe(this@BaseFragment) { value -> value?.let(action) }
    }

    protected fun LiveData<Unit>.observe(action: () -> Unit) {
        this.observe(this@BaseFragment) { action() }
    }

    protected fun <T> LiveData<T>.observeOnView(action: (T) -> Unit) {
        this.observe(viewLifecycleOwner) { value -> value?.let(action) }
    }

    protected fun LiveData<Unit>.observeOnView(action: () -> Unit) {
        this.observe(viewLifecycleOwner) { action() }
    }

    protected open fun showError(errorMessage: ErrorConfig) {
        (activity as? ErrorUi)?.showError(errorMessage)
    }

    protected fun <T : View> Int.find(): T? {
        return binding.find(this)
    }

    protected fun Int.view(): View? {
        return binding.find(this)
    }

    protected fun View?.onClick(action: () -> Unit) {
        this?.setOnClickListener { action() }
    }

    protected fun Int.onClick(action: () -> Unit) {
        view()?.onClick(action)
    }

    protected fun Int.show() {
        view()?.visibility = View.VISIBLE
    }

    protected fun Int.show(isVisible: Boolean) {
        view()?.visibility = if (isVisible) View.VISIBLE else View.GONE
    }

    protected fun Int.hide() {
        view()?.visibility = View.GONE
    }

    protected fun Int.invisible() {
        view()?.visibility = View.INVISIBLE
    }

    protected fun Int.enable() {
        view()?.isEnabled = true
    }

    protected fun Int.disable() {
        view()?.isEnabled = false
    }

    protected fun Int.src(@DrawableRes drawableId: Int) {
        find<ImageView>()?.setImageResource(drawableId)
    }

    protected fun Int.bg(@DrawableRes drawableId: Int) {
        find<ConstraintLayout>()?.setBackgroundResource(drawableId)
    }

    protected fun Int.text(@StringRes stringId: Int) {
        find<TextView>()?.setText(stringId)
    }

    protected fun Int.text(string: String) {
        find<TextView>()?.text = string
    }

    protected fun Fragment.show(container: Int) {
        this@BaseFragment.childFragmentManager.commit { replace(container, this@show) }
    }

    open fun onNewIntent(intent: Intent) {
    }
}