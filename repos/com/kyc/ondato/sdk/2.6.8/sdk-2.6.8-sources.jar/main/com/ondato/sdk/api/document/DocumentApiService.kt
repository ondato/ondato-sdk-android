package com.ondato.sdk.api.document

import com.ondato.sdk.api.BackendApi
import com.ondato.sdk.usecase.document.DocumentApi

internal class DocumentApiService(private val api: BackendApi) : DocumentApi {

    override suspend fun send(
        documentType: String,
        identityVerificationId: String,
        imageBase64: String,
        imageFileType: String,
        side: String,
    ) {
        api.sendDocument(
            identityVerificationId,
            DocumentBody(documentType, side, imageBase64, imageFileType)
        )
    }
}