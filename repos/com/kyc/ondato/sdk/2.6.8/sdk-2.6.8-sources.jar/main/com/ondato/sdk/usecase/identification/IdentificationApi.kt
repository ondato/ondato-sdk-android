package com.ondato.sdk.usecase.identification

internal interface IdentificationApi {

    suspend fun getIdentification(kycId: String): Identification
}