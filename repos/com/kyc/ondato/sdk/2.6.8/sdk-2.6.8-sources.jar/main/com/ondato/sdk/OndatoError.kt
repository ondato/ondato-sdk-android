package com.ondato.sdk

import androidx.annotation.Keep

@Keep
enum class OndatoError(var message: String) {
    CANCELED("canceled by user"),
    BAD_SERVER_RESPONSE("bad response from server"),
    NFC_NOT_SUPPORTED("nfc is not supported in nfc mandatory or optional mode"),
    TOO_MANY_ATTEMPTS("number of max attempts reached when trying to authenticate face"),
    NO_AVAILABLE_DOCUMENT_TYPES("no available document types"),
    SESSION_ALREADY_RUNNING("an identification session is already running");

    override fun toString(): String {
        return "${this.name}(message=$message)"
    }
}