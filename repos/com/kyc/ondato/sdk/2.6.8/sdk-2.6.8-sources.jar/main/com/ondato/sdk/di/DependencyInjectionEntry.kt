package com.ondato.sdk.di

import org.koin.core.component.KoinComponent

interface DependencyInjectionEntry : KoinComponent {

    override fun getKoin() = Injector.get()
}