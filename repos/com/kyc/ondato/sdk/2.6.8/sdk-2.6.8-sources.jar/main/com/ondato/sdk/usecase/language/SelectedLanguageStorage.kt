package com.ondato.sdk.usecase.language

import com.ondato.sdk.enums.Language
import kotlinx.coroutines.flow.Flow

interface SelectedLanguageStorage {
    suspend fun set(language: Language)

    suspend fun get(): Language

    suspend fun observe(): Flow<Language>

    suspend fun clear()
}