package com.ondato.sdk.utils

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import androidx.annotation.Keep
import java.io.ByteArrayOutputStream

@Keep
object Base64 {
    @Keep
    fun encode(input: ByteArray): String {
        return Base64.encodeToString(input, Base64.NO_WRAP)
    }

    @Keep
    fun decode(input: String): ByteArray {
        return Base64.decode(input, Base64.DEFAULT)
    }

    internal fun String.resizeAndDecodeToBase64(
        compressFormat: Bitmap.CompressFormat = Bitmap.CompressFormat.PNG
    ): String {
        val image = BitmapFactory.decodeFile(this)

        val width = image.width
        val height = image.height
        val aspectRatio = width.toDouble() / height
        val targetHeight = 700
        val targetWidth = aspectRatio * targetHeight

        val resizedImage = Bitmap.createScaledBitmap(image, targetWidth.toInt(), targetHeight, false)

        val byteArrayOutputStream = ByteArrayOutputStream()
        resizedImage.compress(compressFormat, 100, byteArrayOutputStream)
        val byteArray = byteArrayOutputStream.toByteArray()

        return Base64.encodeToString(byteArray, Base64.DEFAULT)
    }

    fun String.decodeToBase64(
        compressFormat: Bitmap.CompressFormat = Bitmap.CompressFormat.PNG
    ): String {
        val image = BitmapFactory.decodeFile(this)

        val byteArrayOutputStream = ByteArrayOutputStream()
        image.compress(compressFormat, 100, byteArrayOutputStream)
        val byteArray = byteArrayOutputStream.toByteArray()

        return Base64.encodeToString(byteArray, Base64.DEFAULT)
    }
}