package com.ondato.sdk.usecase.session

import com.ondato.sdk.Ondato
import com.ondato.sdk.log.Event
import com.ondato.sdk.log.Logger
import com.ondato.sdk.usecase.session.verification.VerificationApi
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

class CompleteSessionUseCase(
    private val session: Session,
    private val api: CompleteApi,
    private val verificationApi: VerificationApi,
    private val dispatcher: CoroutineDispatcher = Dispatchers.IO,
) {
    suspend fun completeKYC() {
        withContext(dispatcher) {
            // logs and api#complete are sent at the same time and if api.complete finish first,
            // logs are not delivered to the backend, therefore api.complete is delayed.
            delay(1000)
            verificationApi.verify(session.kycId)
            api.completeKYCIdentification(session.kycId)
            Logger.log(Event.SessionCompleted)
        }
    }

    /**
     * To finalize the id verification process, complete should be called at the very end,
     * when there is no option for the user to update or GET data. After complete is called
     * accessToken gets revoked.
     */
    suspend fun complete() {
        if (!session.sessionCompleted) {
            withContext(dispatcher) {
                api.completeIdentification(Ondato.config.identityVerificationId)
                session.sessionCompleted = true
            }
        }
    }

    suspend fun abort() {
        withContext(dispatcher) {
            api.abortIdentification(Ondato.config.identityVerificationId)
            session.sessionCompleted = true
        }
    }
}