package com.ondato.sdk.ui.main

import com.ondato.sdk.ui.error.ErrorMessage

data class ErrorConfig(
    val message: ErrorMessage,
    val canContinue: Boolean = false
)