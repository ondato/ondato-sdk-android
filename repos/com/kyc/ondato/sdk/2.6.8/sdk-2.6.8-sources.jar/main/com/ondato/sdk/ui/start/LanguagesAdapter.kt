package com.ondato.sdk.ui.start

import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.ondato.sdk.enums.Language

internal class LanguagesAdapter(
    private val listener: (Language) -> Unit
) : RecyclerView.Adapter<LanguageViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): LanguageViewHolder {
        return LanguageViewHolder.inflate(parent)
    }

    override fun onBindViewHolder(holder: LanguageViewHolder, position: Int) {
        holder.bind(Language.values()[position], listener)
    }

    override fun getItemCount(): Int {
        return Language.values().size
    }
}