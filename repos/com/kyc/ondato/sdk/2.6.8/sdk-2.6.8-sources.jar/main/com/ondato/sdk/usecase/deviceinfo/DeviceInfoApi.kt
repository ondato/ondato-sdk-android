package com.ondato.sdk.usecase.deviceinfo

import com.ondato.sdk.api.session.DeviceInfoBodyV2

internal interface DeviceInfoApi {
    suspend fun sendDeviceInfoV2(identityVerificationId: String, info: DeviceInfoBodyV2)
}