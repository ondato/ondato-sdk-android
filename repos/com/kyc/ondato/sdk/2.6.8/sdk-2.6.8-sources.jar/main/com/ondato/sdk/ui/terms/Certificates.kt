package com.ondato.sdk.ui.terms

internal object Certificates {
    val urls = listOf(
        "https://kyc.ondato.com/public/images/certificates/iso-27001-02.png",
        "https://kyc.ondato.com/public/images/certificates/iso-30107-3-1.png",
        "https://kyc.ondato.com/public/images/certificates/gdpr.png",
        "https://kyc.ondato.com/public/images/certificates/iso-30107-3-2.png"
    )
}