package com.ondato.sdk.ui.document.instructions

import com.ondato.sdk.ui.base.BaseViewModel
import com.ondato.sdk.ui.base.event
import com.ondato.sdk.ui.base.set
import com.ondato.sdk.ui.base.state
import com.ondato.sdk.ui.main.Step
import com.ondato.sdk.usecase.document.DocumentType
import com.ondato.sdk.usecase.savephoto.Mode
import com.ondato.sdk.usecase.session.Session

internal class CaptureDocumentInstructionsViewModel(
    private val session: Session
) : BaseViewModel() {

    val data by state<InstructionsViewData>()
    val next by event<Step>()

    private var mode: Mode? = null

    fun init(mode: Mode) {
        this.mode = mode
        launch {
            val documentType = session.selectedType ?: DocumentType.Unknown
            val viewData = InstructionsScreenMapper.map(documentType, mode)
            data.set(viewData)

        }
    }

    fun onStartClicked() {
        val mode = mode ?: return
        when (mode) {
            Mode.Back -> next.set(Step.CAPTURE_DOCUMENT_BACK_INSTRUCTIONS)
            Mode.Front -> next.set(Step.CAPTURE_DOCUMENT_FRONT_INSTRUCTIONS)
            Mode.MRZ -> next.set(Step.CAPTURE_DOCUMENT_MRZ_INSTRUCTIONS)
            Mode.Address -> next.set(Step.CAPTURE_POA_INSTRUCTIONS)
            else -> next.set(Step.CAPTURE_FACE_INSTRUCTIONS)
        }
    }
}