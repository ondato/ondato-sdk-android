package com.ondato.sdk.utils

import android.app.Activity
import android.nfc.NfcAdapter

fun Activity.isNfcAvailable(): Boolean {
    var nfcAvailable = true
    try {
        val adapter = NfcAdapter.getDefaultAdapter(this)
        if (adapter == null) nfcAvailable = false
    } catch (e: UnsupportedOperationException) {
        nfcAvailable = false
    }
    return nfcAvailable
}
