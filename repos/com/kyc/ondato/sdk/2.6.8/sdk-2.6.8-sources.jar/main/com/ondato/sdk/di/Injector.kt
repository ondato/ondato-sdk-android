package com.ondato.sdk.di

import android.content.Context
import com.ondato.sdk.OndatoConfig
import com.ondato.sdk.android.androidModule
import com.ondato.sdk.api.apiModule
import com.ondato.sdk.storage.storageModule
import com.ondato.sdk.ui.uiModule
import com.ondato.sdk.usecase.useCaseModule
import com.ondato.sdk.utils.utilsModule
import org.koin.android.ext.koin.androidContext
import org.koin.core.Koin
import org.koin.core.KoinApplication
import org.koin.core.context.KoinContext
import org.koin.core.module.Module
import org.koin.core.parameter.ParametersDefinition
import org.koin.core.qualifier.Qualifier
import org.koin.dsl.KoinAppDeclaration

object Injector : KoinContext {

    private var mode: OndatoConfig.Mode? = null
    private var app: KoinApplication? = null

    fun init(context: Context, mode: OndatoConfig.Mode, vararg featureModules: Module) {
        if (app == null || mode != this.mode) {
            this.mode = mode
            stopKoin()
            startKoin {
                androidContext(context)
                modules(
                    apiModule(mode),
                    uiModule,
                    utilsModule,
                    useCaseModule,
                    storageModule,
                    androidModule,
                    *featureModules
                )
            }
        }
    }

    override fun get() = synchronized(this) { app?.koin ?: error("DI is not initialized") }

    override fun getOrNull(): Koin? = synchronized(this) { app?.koin }

    private fun register(koinApplication: KoinApplication) {
        if (app == null) app = koinApplication
    }

    override fun stopKoin() = synchronized(this) {
        app?.close()
        app = null
        mode = null
    }

    override fun startKoin(koinApplication: KoinApplication): KoinApplication = synchronized(this) {
        register(koinApplication)
        return koinApplication
    }

    override fun startKoin(
        appDeclaration: KoinAppDeclaration
    ): KoinApplication = synchronized(this) {
        val koinApplication = KoinApplication.init()
        register(koinApplication)
        appDeclaration(koinApplication)
        return koinApplication
    }

    override fun loadKoinModules(module: Module, createEagerInstances: Boolean) = synchronized(this) {
        get().loadModules(
            modules = listOf(module),
            createEagerInstances = createEagerInstances,
        )
    }

    override fun loadKoinModules(modules: List<Module>, createEagerInstances: Boolean) = synchronized(this) {
        get().loadModules(
            modules = modules,
            createEagerInstances = createEagerInstances,
        )
    }


    override fun unloadKoinModules(modules: List<Module>) = synchronized(this) {
        get().unloadModules(modules)
    }

    override fun unloadKoinModules(module: Module) = synchronized(this) {
        get().unloadModules(listOf(module))
    }

    inline fun <reified T : Any> DependencyInjectionEntry.koinInject(
        qualifier: Qualifier? = null,
        mode: LazyThreadSafetyMode = LazyThreadSafetyMode.SYNCHRONIZED,
        noinline parameters: ParametersDefinition? = null,
    ) = lazy(mode) { getKoin().get<T>(qualifier, parameters) }
}