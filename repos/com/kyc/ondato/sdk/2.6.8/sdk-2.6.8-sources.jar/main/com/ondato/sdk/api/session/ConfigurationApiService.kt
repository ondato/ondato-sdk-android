package com.ondato.sdk.api.session

import com.ondato.sdk.api.BackendApi
import com.ondato.sdk.usecase.session.ApiConfig
import com.ondato.sdk.usecase.session.configuration.ConfigurationApi
import com.ondato.sdk.usecase.session.configuration.SessionSetup
import retrofit2.http.Path

internal class ConfigurationApiService(private val api: BackendApi) : ConfigurationApi {

    override suspend fun getKycIdentificationSetup(identityVerificationId: String): SessionSetup {
        return api.getSetup(identityVerificationId)
            .toSessionSetup()
    }

    override suspend fun getKYCId(setupId: String, identityVerificationId: String): String {
        return api.getKYCId(KYCIdentificationBody(setupId, identityVerificationId)).id ?: ""
    }

    override suspend fun getConfig(KYCId: String): ApiConfig {
        return api.getConfig(KYCId).toApiConfig()
    }

    override suspend fun getFaceAuthConfig(@Path("id") faceAuthId: String): ApiFaceAuthStatusResponse {
        return api.getFaceAuthConfig(faceAuthId)
    }

}