package com.ondato.sdk.ui.photo

import androidx.annotation.DrawableRes
import androidx.annotation.StringRes
import com.ondato.sdk.R
import com.ondato.sdk.error.BadDocumentTypeException
import com.ondato.sdk.usecase.document.DocumentType
import com.ondato.sdk.usecase.savephoto.Mode

internal sealed class PhotoScreenData(
    @StringRes val titleId: Int,
    @StringRes val checkPhotoTitleId: Int,
    @StringRes val checkPhotoDescriptionId: Int,
    val isCameraFrameSquare: Boolean = false,
    @DrawableRes val documentIconId: Int
) {
    object PassportFront : PhotoScreenData(
        titleId = R.string.ondato_capture_passport_front_title,
        checkPhotoTitleId = R.string.ondato_capture_check_taken_photo,
        checkPhotoDescriptionId = R.string.ondato_capture_check_taken_photo_description,
        documentIconId = R.drawable.ondato_passport_icon
    )

    object IdCardFront : PhotoScreenData(
        titleId = R.string.ondato_capture_id_card_front_title,
        checkPhotoTitleId = R.string.ondato_capture_check_taken_photo,
        checkPhotoDescriptionId = R.string.ondato_capture_check_taken_photo_description,
        documentIconId = R.drawable.ondato_id_icon_front,
    )

    object IdCardBack : PhotoScreenData(
        titleId = R.string.ondato_capture_id_card_back_title,
        checkPhotoTitleId = R.string.ondato_capture_check_taken_photo,
        checkPhotoDescriptionId = R.string.ondato_capture_check_taken_photo_description,
        documentIconId = R.drawable.ondato_id_icon_back
    )

    object DriverLicenseFront : PhotoScreenData(
        titleId = R.string.ondato_capture_driver_licence_front_title,
        checkPhotoTitleId = R.string.ondato_capture_check_taken_photo,
        checkPhotoDescriptionId = R.string.ondato_capture_check_taken_photo_description,
        documentIconId = R.drawable.ondato_driving_license_icon_front
    )

    object DriverLicenseBack : PhotoScreenData(
        titleId = R.string.ondato_capture_driver_license_back_title,
        checkPhotoTitleId = R.string.ondato_capture_check_taken_photo,
        checkPhotoDescriptionId = R.string.ondato_capture_check_taken_photo_description,
        documentIconId = R.drawable.ondato_driving_license_icon_back
    )

    object Selfie : PhotoScreenData(
        titleId = R.string.ondato_capture_yourself_with_document_title,
        checkPhotoTitleId = R.string.ondato_capture_check_taken_photo_with_document,
        checkPhotoDescriptionId = R.string.ondato_capture_check_taken_photo_with_document_description,
        isCameraFrameSquare = true,
        documentIconId = R.drawable.ondato_selfie_with_document_icon
    )

    object ProofOfAddress : PhotoScreenData(
        titleId = R.string.ondato_capture_poa_document_title,
        checkPhotoTitleId = R.string.ondato_capture_check_taken_photo_with_document,
        checkPhotoDescriptionId = R.string.ondato_capture_check_taken_photo_with_document_description,
        documentIconId = 0
    )

    companion object {
        fun from(mode: Mode, documentType: DocumentType?): PhotoScreenData {
            if (mode == Mode.Selfie) return Selfie
            if (mode == Mode.Address) return ProofOfAddress
            return when (documentType) {
                DocumentType.IdCard -> if (mode is Mode.Front) IdCardFront else IdCardBack
                DocumentType.Passport -> PassportFront
                DocumentType.DriverLicense -> if (mode is Mode.Front) DriverLicenseFront else DriverLicenseBack
                else -> throw BadDocumentTypeException()
            }
        }
    }
}