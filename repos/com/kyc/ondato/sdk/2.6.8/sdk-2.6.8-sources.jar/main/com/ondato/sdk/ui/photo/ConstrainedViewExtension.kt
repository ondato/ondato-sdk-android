package com.ondato.sdk.ui.photo

import android.view.View
import androidx.annotation.IdRes
import androidx.constraintlayout.widget.ConstraintLayout

fun View.topToTop(@IdRes target: Int) {
    (layoutParams as? ConstraintLayout.LayoutParams)?.topToTop = target
    requestLayout()
}

fun View.bottomToBottom(@IdRes target: Int) {
    (layoutParams as? ConstraintLayout.LayoutParams)?.bottomToBottom = target
    requestLayout()
}

fun View.leftToLeft(@IdRes target: Int) {
    (layoutParams as? ConstraintLayout.LayoutParams)?.leftToLeft = target
    requestLayout()
}

fun View.rightToRight(@IdRes target: Int) {
    (layoutParams as? ConstraintLayout.LayoutParams)?.rightToRight = target
    requestLayout()
}

