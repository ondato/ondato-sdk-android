package com.ondato.sdk.ui.identification.result

import android.os.Bundle
import android.view.View
import com.ondato.sdk.R
import com.ondato.sdk.log.Logger
import com.ondato.sdk.ui.base.BaseFragment
import com.ondato.sdk.ui.main.Failure
import com.ondato.sdk.ui.main.MainViewModel
import com.ondato.sdk.ui.main.Step
import com.ondato.sdk.usecase.identification.RejectedStatus
import org.koin.androidx.viewmodel.ext.android.sharedViewModel
import org.koin.androidx.viewmodel.ext.android.viewModel

internal class IdentificationResultFragment : BaseFragment(
    layoutId = R.layout.ondato_fragment_identification_result
) {

    private val viewModel by viewModel<IdentificationResultViewModel>()
    private val mainViewModel by sharedViewModel<MainViewModel>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ((arguments?.getSerializable(KEY_STATUS) as? RejectedStatus)).let(viewModel::init)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel.state.observe {
            when (it) {
                is IdentificationResultViewModel.State.Failure -> setupFailure(it)
                is IdentificationResultViewModel.State.Success -> setupSuccess(it)
            }
        }

        viewModel.event.observe {
            when (it) {
                IdentificationResultViewModel.Event.Success -> {
                    mainViewModel.onStepSuccess(Step.IDENTIFICATION_WAITING_PAGE_RESULT)
                }
                is IdentificationResultViewModel.Event.Failure -> {
                    mainViewModel.onStepFailed(Failure.IdentificationFailure(it.tryAgain))
                }
                is IdentificationResultViewModel.Event.Close -> {
                    mainViewModel.onStepFailed(Failure.IdentificationFailure(false))
                }
            }
        }
    }

    private fun setupSuccess(state: IdentificationResultViewModel.State.Success) {
        R.id.ondatoWaitingPageResultButton.text(
            getString(
                R.string.ondato_waiting_page_success_continue_title,
                state.seconds.toString()
            )
        )

        R.id.ondatoWaitingPageResultButton.onClick {
            viewModel.onButtonClick(state)
        }

        R.id.ondatoWaitingPageResultTitle.text(R.string.ondato_waiting_page_success_title)
        R.id.ondatoWaitingPageResultBody.text(R.string.ondato_waiting_page_success_body)
        R.id.ondatoWaitingPageResultIcon.src(R.drawable.ondato_ic_nfc_identification_success)
        R.id.ondatoWaitingPageCloseButton.hide()
    }

    private fun setupFailure(state: IdentificationResultViewModel.State.Failure) {
        val uIData = IdentificationFailureUIResolver.get(state.rejectedStatus)

        R.id.ondatoWaitingPageResultTitle.text(uIData.title)
        R.id.ondatoWaitingPageResultBody.text(uIData.body)
        R.id.ondatoWaitingPageResultIcon.src(R.drawable.ondato_ic_error)

        R.id.ondatoWaitingPageResultButton.text(uIData.button)
        R.id.ondatoWaitingPageResultButton.onClick { viewModel.onButtonClick(state) }

        if (state.rejectedStatus.tryAgain) {
            R.id.ondatoWaitingPageCloseButton.show()
            R.id.ondatoWaitingPageCloseButton.text(R.string.ondato_close)
            R.id.ondatoWaitingPageCloseButton.onClick { viewModel.onCloseClick() }
        } else {
            R.id.ondatoWaitingPageCloseButton.hide()
        }
    }

    companion object {
        private const val KEY_STATUS = "key.status"

        fun newInstance(status: RejectedStatus?): IdentificationResultFragment {
            val bundle = Bundle().apply { putSerializable(KEY_STATUS, status) }
            val fragment =  IdentificationResultFragment()
            fragment.apply { arguments = bundle }
            return fragment
        }
    }
}