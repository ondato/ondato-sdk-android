package com.ondato.sdk.storage.file

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import androidx.core.graphics.scale
import com.ondato.sdk.usecase.savephoto.Mode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import kotlin.coroutines.CoroutineContext

internal class BitmapFactory(private val context: CoroutineContext = Dispatchers.Default) {

    suspend fun create(
        byteArray: ByteArray,
        mode: Mode,
        scaleToWidth: Int = -1
    ): Bitmap = withContext(context) {
        BitmapFactory.decodeByteArray(byteArray, 0, byteArray.size)
            .let { if (mode == Mode.Selfie) it.rotate() else it }
            .let { if (mode == Mode.MRZ) it.rotateMRZ() else it }
            .let { if(scaleToWidth > 0) scaleToWidth(it, scaleToWidth) else it }
            .updateConfig(Bitmap.Config.RGB_565)
    }

    private suspend fun scaleToWidth(bitmap: Bitmap, width: Int): Bitmap = withContext(context) {
        val ratio = bitmap.width.toFloat() / width
        if (ratio > 1) {
            val height = (bitmap.height.toFloat() / ratio).toInt()
            val result = bitmap.scale(width, height)
            bitmap.recycle()
            result
        } else {
            bitmap
        }
    }

    private fun Bitmap.updateConfig(config: Bitmap.Config): Bitmap {
        val result = this.copy(config, false)
        this.recycle()
        return result
    }

    private fun Bitmap.downgrade(quality: Int): Bitmap {
        val out = ByteArrayOutputStream()
        this.compress(Bitmap.CompressFormat.JPEG, quality, out)
        val result = BitmapFactory.decodeByteArray(out.toByteArray(), 0, out.size())
        this.recycle()
        return result
    }

    private fun Bitmap.rotate(): Bitmap {
        val matrix = Matrix()
        matrix.postRotate(0f)
        matrix.postScale(-1f, 1f)
        val result = Bitmap.createBitmap(this, 0, 0, width, height, matrix, true)
        this.recycle()
        return result
    }

    private fun Bitmap.rotateMRZ(): Bitmap {
        val matrix = Matrix()
        matrix.postRotate(90f)
        val result = Bitmap.createBitmap(this, 0, 0, width, height, matrix, true)
        this.recycle()
        return result
    }
}