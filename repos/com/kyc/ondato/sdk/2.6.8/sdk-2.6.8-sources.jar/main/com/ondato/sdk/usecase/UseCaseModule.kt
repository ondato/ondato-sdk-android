package com.ondato.sdk.usecase

import com.ondato.sdk.log.LogsSaver
import com.ondato.sdk.log.LogsSender
import com.ondato.sdk.usecase.additionalDocument.SendAdditionalDocumentUseCase
import com.ondato.sdk.usecase.deviceinfo.SendDeviceInfoUseCase
import com.ondato.sdk.usecase.document.SendDocumentUseCase
import com.ondato.sdk.usecase.identification.IdentificationUseCase
import com.ondato.sdk.usecase.installationid.InstallationIdUseCase
import com.ondato.sdk.usecase.language.ObserveLanguageChangesUseCase
import com.ondato.sdk.usecase.language.SelectedLanguage
import com.ondato.sdk.usecase.language.SelectedLanguageUseCase
import com.ondato.sdk.usecase.liveness.LivenessTokenUseCase
import com.ondato.sdk.usecase.liveness.active.ActiveLivenessCheckUseCase
import com.ondato.sdk.usecase.liveness.passive.PassiveLivenessCheckUseCase
import com.ondato.sdk.usecase.logs.LogsUseCase
import com.ondato.sdk.usecase.registration.RegistrationUseCase
import com.ondato.sdk.usecase.savephoto.SaveDocumentPhotoUseCase
import com.ondato.sdk.usecase.session.CompleteSessionUseCase
import com.ondato.sdk.usecase.session.GetV2TokenUseCase
import com.ondato.sdk.usecase.session.Session
import com.ondato.sdk.usecase.session.StartSessionUseCase
import com.ondato.sdk.usecase.session.restart.RestartSessionUseCase
import org.koin.dsl.binds
import org.koin.dsl.module

internal val useCaseModule = module {
    single { Session }
    factory { SendDeviceInfoUseCase(get(), get(), get(), get(), get(), get()) }
    factory { SendAdditionalDocumentUseCase(get(), get(), get()) }
    factory { SendDocumentUseCase(get(), get(), get()) }
    factory { PassiveLivenessCheckUseCase(get(), get(), get()) }
    factory { ActiveLivenessCheckUseCase(get(), get()) }
    factory { StartSessionUseCase(get(), get(), get(), get()) }
    factory { GetV2TokenUseCase(get()) }
    factory { SelectedLanguage(get()) }
    factory { SelectedLanguageUseCase(get()) }
    factory { ObserveLanguageChangesUseCase(get()) }
    factory { SaveDocumentPhotoUseCase(get(), get()) }
    factory { CompleteSessionUseCase(get(), get(), get()) }
    factory { LivenessTokenUseCase(get()) }
    factory { LogsUseCase(get(), get()) } binds (arrayOf(LogsSender::class, LogsSaver::class))
    factory { InstallationIdUseCase(get()) }
    factory { IdentificationUseCase(get()) }
    factory { RestartSessionUseCase(get(), get()) }
    factory { RegistrationUseCase(get()) }
}