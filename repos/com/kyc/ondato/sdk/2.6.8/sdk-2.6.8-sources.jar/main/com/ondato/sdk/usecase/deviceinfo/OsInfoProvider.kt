package com.ondato.sdk.usecase.deviceinfo

internal interface OsInfoProvider {
    suspend fun getName(): String

    suspend fun getSdkVersion(): String
}