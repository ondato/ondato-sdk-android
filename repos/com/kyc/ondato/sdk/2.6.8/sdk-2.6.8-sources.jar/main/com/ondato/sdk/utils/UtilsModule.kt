package com.ondato.sdk.utils

import org.koin.dsl.module

internal val utilsModule = module {
    factory { Base64 }
}