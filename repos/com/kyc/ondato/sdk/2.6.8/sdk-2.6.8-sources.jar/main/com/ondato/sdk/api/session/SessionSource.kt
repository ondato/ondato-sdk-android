package com.ondato.sdk.api.session

import androidx.annotation.Keep
import com.google.gson.annotations.SerializedName

@Keep
internal enum class SessionSource {
    @SerializedName("IdvWebDesktop") Desktop,
    @SerializedName("IdvWebMobile") WebMobile,
    @SerializedName("IdvMobileSdk") Mobile,
    @SerializedName("External") External,
}