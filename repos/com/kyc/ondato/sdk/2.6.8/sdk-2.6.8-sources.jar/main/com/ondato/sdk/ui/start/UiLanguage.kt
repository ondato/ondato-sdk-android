package com.ondato.sdk.ui.start

import com.ondato.sdk.enums.Language

internal interface UiLanguage {
    fun setLanguage(language: Language)
}