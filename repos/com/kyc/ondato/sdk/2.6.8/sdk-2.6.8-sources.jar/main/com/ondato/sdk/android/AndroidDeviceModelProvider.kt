package com.ondato.sdk.android

import android.os.Build
import com.ondato.sdk.usecase.deviceinfo.DeviceModelProvider
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

internal class AndroidDeviceModelProvider(
    private val dispatcher: CoroutineDispatcher = Dispatchers.Default
) : DeviceModelProvider {

    override suspend fun get() = withContext(dispatcher) {
        val manufacturer = Build.MANUFACTURER
        val model = Build.MODEL
        if (model.toLowerCase().startsWith(manufacturer.toLowerCase())) {
            capitalize(model)
        } else {
            capitalize(manufacturer) + " " + model
        }
    }


    private fun capitalize(s: String?): String {
        if (s == null || s.isEmpty()) return ""
        val first = s[0]
        return if (Character.isUpperCase(first)) {
            s
        } else {
            Character.toUpperCase(first).toString() + s.substring(1)
        }
    }
}