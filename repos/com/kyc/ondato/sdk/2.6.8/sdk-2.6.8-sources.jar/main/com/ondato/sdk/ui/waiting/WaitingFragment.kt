package com.ondato.sdk.ui.waiting

import android.os.Bundle
import android.view.View
import com.ondato.sdk.Ondato
import com.ondato.sdk.OndatoConfig
import com.ondato.sdk.R
import com.ondato.sdk.ui.base.BaseFragment
import com.ondato.sdk.ui.main.Failure
import com.ondato.sdk.ui.main.MainViewModel
import com.ondato.sdk.ui.main.Step
import com.ondato.sdk.ui.waiting.AuthError.Timeout
import org.koin.androidx.viewmodel.ext.android.sharedViewModel
import org.koin.androidx.viewmodel.ext.android.viewModel

internal class WaitingFragment : BaseFragment(R.layout.ondato_fragment_waiting) {
    private val mainViewModel: MainViewModel by sharedViewModel()
    private val viewModel: WaitingViewModel by viewModel()
    private val config: OndatoConfig = Ondato.config

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (savedInstanceState == null) viewModel.init(config)
        viewModel.completed.observe { mainViewModel.onStepSuccess(Step.WAITING) }
        viewModel.failed.observe { mainViewModel.onStepFailed(Failure.WaitingFailure(it)) }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        R.id.successButton.onClick { mainViewModel.onStepSuccess(Step.WAITING) }
        R.id.failedButton.onClick { mainViewModel.onStepFailed(Failure.WaitingFailure(Timeout)) }
        viewModel.time.observeOnView { time -> R.id.timeTextView.text(time) }
    }

    companion object {
        fun newInstance() = WaitingFragment()
    }
}