package com.ondato.sdk.usecase.identification

internal class IdentificationUseCase(
    private val identificationApi: IdentificationApi,
) {

    suspend fun getIdentification(kycId: String): Identification {
        return identificationApi.getIdentification(kycId)
    }
}