package com.ondato.sdk.usecase.registration

import com.ondato.sdk.Ondato
import com.ondato.sdk.api.registration.RegistrationRequest
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

internal class RegistrationUseCase(
    private val registrationApi: RegistrationApi,
    private val dispatcher: CoroutineDispatcher = Dispatchers.IO,
) {
    suspend fun sendRegistration(registrationRequest: List<RegistrationRequest>) {
        withContext(dispatcher) {
            registrationApi.sendRegistration(Ondato.config.identityVerificationId,
                registrationRequest)
        }
    }
}