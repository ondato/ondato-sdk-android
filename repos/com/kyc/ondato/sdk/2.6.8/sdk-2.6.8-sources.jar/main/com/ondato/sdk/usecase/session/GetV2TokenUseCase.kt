package com.ondato.sdk.usecase.session

import com.ondato.sdk.usecase.session.token.Token
import com.ondato.sdk.usecase.session.token.TokenApi

internal class GetV2TokenUseCase(private val tokenApi: TokenApi) {

    suspend fun getPartialAccessToken(identityVerificationId: String): Token {
        return tokenApi.getTokenV2(identityVerificationId)
    }

    suspend fun getFullAccessToken(identityVerificationId: String): Token {
        return tokenApi.getFullAccessTokenV2(identityVerificationId)
    }
}