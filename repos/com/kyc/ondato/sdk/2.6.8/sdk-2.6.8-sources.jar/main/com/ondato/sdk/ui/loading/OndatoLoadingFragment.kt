package com.ondato.sdk.ui.loading

import com.ondato.sdk.R
import com.ondato.sdk.ui.base.BaseFragment

internal class OndatoLoadingFragment : BaseFragment(R.layout.ondato_fragment_loading) {
    companion object {
        fun newInstance() = OndatoLoadingFragment()
    }
}