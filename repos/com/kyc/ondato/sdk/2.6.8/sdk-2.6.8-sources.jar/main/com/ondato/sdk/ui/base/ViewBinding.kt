package com.ondato.sdk.ui.base

import android.view.View
import androidx.lifecycle.LifecycleObserver

internal class ViewBinding(private val root: () -> View?) : LifecycleObserver {
    private val cache = mutableMapOf<Int, View?>()

    fun clear() {
        cache.clear()
    }

    fun <T : View> find(id: Int): T? {
        return cache.getOrPut(id) { root()?.findViewById<T>(id) } as T?
    }

}

