package com.ondato.sdk.api.complete

import com.ondato.sdk.api.BackendApi
import com.ondato.sdk.usecase.session.CompleteApi

internal class CompleteService(
    private val api: BackendApi,
) : CompleteApi {

    override suspend fun completeKYCIdentification(identityVerificationId: String) {
        api.completeKYCIdentification(identityVerificationId)
    }

    override suspend fun completeIdentification(identificationId: String) {
        api.completeIdentification(identificationId)
    }

    override suspend fun abortIdentification(identificationId: String) {
        api.abortIdentification(identificationId)
    }
}