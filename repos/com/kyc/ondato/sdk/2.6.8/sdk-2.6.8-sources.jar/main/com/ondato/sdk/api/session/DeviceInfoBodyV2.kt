package com.ondato.sdk.api.session

import com.google.gson.annotations.SerializedName

internal class DeviceInfoBodyV2(
    @SerializedName("sdkVersion") val sdkVersion: String,
    @SerializedName("source") val source: SessionSource,
    @SerializedName("deviceInformation") val deviceInformation: DeviceInformation,
)

internal class DeviceInformation(
    @SerializedName("model") val model: String,
    @SerializedName("osName") val osName: String,
    @SerializedName("osVersion") val osVersion: OsVersion,
    @SerializedName("installationId") val installationID: String,
)

internal class OsVersion(
    @SerializedName("major") val major: Int,
    @SerializedName("minor") val minor: Int,
    @SerializedName("patch") val patch: Int
)