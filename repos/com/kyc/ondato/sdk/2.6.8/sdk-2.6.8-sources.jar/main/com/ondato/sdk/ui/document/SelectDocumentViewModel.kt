package com.ondato.sdk.ui.document

import com.ondato.sdk.ui.base.*
import com.ondato.sdk.usecase.document.DocumentType
import com.ondato.sdk.usecase.session.Session

internal class SelectDocumentViewModel(
    private val session: Session
) : BaseViewModel() {

    val documents by state<List<DocumentType>>()
    val completed by event<Unit>()

    init {
        val available = session.availableDocumentTypes.map { it.type }
        if (available.size == 1) {
            onDocumentSelected(available.first())
        } else {
            documents.set(available)
        }
    }

    fun onDocumentSelected(documentType: DocumentType) {
        session.selectedType = documentType
        completed.call()
    }
}