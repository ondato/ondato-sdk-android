package com.ondato.sdk.ui.launcher

import android.Manifest.permission.CAMERA
import android.Manifest.permission.RECORD_AUDIO
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager.GET_PERMISSIONS
import android.content.pm.PackageManager.PERMISSION_GRANTED
import android.media.projection.MediaProjectionConfig
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import androidx.core.app.ActivityCompat.requestPermissions
import androidx.core.content.ContextCompat.checkSelfPermission
import com.ondato.sdk.Ondato
import com.ondato.sdk.OndatoError
import com.ondato.sdk.OndatoError.BAD_SERVER_RESPONSE
import com.ondato.sdk.OndatoError.CANCELED
import com.ondato.sdk.R
import com.ondato.sdk.di.Injector.koinInject
import com.ondato.sdk.error.FeatureNotIncludedException
import com.ondato.sdk.log.Logger
import com.ondato.sdk.log.LogsSaver
import com.ondato.sdk.log.LogsSender
import com.ondato.sdk.ui.base.BaseActivity
import com.ondato.sdk.ui.main.MainActivity
import com.ondato.sdk.ui.utils.PermissionsDialog
import com.ondato.sdk.usecase.session.Session
import org.koin.androidx.viewmodel.ext.android.viewModel

class LauncherActivity : BaseActivity() {
    private val session by koinInject<Session>()
    private val sender by koinInject<LogsSender>()
    private val saver by koinInject<LogsSaver>()

    private val viewModel: LauncherViewModel by viewModel()

    private var checkOnResume = false

    private var isRestart = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_launcher)
        if (savedInstanceState == null) {
            Logger.setSender(sender)
            Logger.setSaver(saver)
            viewModel.init(isRestart, Ondato.config)
        }
        viewModel.success.observe { checkPermissionsAndStart() }
        viewModel.showError.observe { showError() }

        if (Ondato.config.showSplashScreen) {
            R.id.ondatoLogoImageView.show(true)
            R.id.ondatoLogoDescription.show(true)
        } else {
            R.id.progressBar.show(true)
        }
        viewModel.isLoading.observe { isLoading ->
            if (!Ondato.config.showSplashScreen) R.id.progressBar.show(isLoading)
        }
    }

    override fun onResume() {
        super.onResume()
        if (checkOnResume) checkPermissionsAndStart()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray,
    ) {
        if (requestCode == RQ_PERM) {
            handlePermissionResult(grantResults)
        } else {
            super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        when (requestCode) {
            RQ_AUTH -> handleAuthResult(resultCode, data)
            RQ_REC -> {
                try {
                    if (resultCode == RESULT_OK) {
                        val intent = Intent()
                        intent.setClassName(this.packageName, "com.ondato.sdk.recorder.ui.RecorderActivity")
                        intent.putExtra("requestCode", RQ_AUTH)
                        intent.putExtra("resultCode", resultCode)
                        intent.putExtra("data", data)
                        intent.putExtra("session", session)
                        startActivityForResult(intent, RQ_AUTH)
                    } else {
                        handleAuthResult(resultCode, data)
                    }
                } catch (exception: RuntimeException) {
                    throw FeatureNotIncludedException("Screen recording SDK is not included inside build.gradle file")
                }
            }

            else -> super.onActivityResult(requestCode, resultCode, data)
        }
    }

    private fun handlePermissionResult(grantResults: IntArray) {
        if (grantResults.all { it == PERMISSION_GRANTED }) {
            start()
        } else {
            showPermissionsDialog()
        }
    }

    private fun handleAuthResult(resultCode: Int, data: Intent?) {
        if (resultCode == RESULT_OK) {
            Ondato.onSuccess(session.kycId)
            finish()
        } else {
            val shouldRestart = data?.getBooleanExtra(SHOULD_RESTART, false) ?: false
            val error = (data?.getSerializableExtra(KEY_ERROR) as? OndatoError) ?: CANCELED
            isRestart = shouldRestart
            if (shouldRestart) {
                viewModel.init(shouldRestart, Ondato.config)
            } else {
                Ondato.onError(session.kycId, error)
                finish()
            }
        }
    }

    private fun showError() {
        Ondato.onError(session.kycId, BAD_SERVER_RESPONSE)
        finish()
    }

    private fun checkPermissionsAndStart() {
        checkOnResume = false
        if (areAllPermissionsGranted()) {
            start()
        } else {
            val permissions = packageManager.getPackageInfo(packageName, GET_PERMISSIONS).requestedPermissions
            val required = listOfNotNull(
                if (Ondato.config.recordProcess && permissions?.any { it == "android.permission.RECORD_AUDIO" } == true) RECORD_AUDIO else null,
                CAMERA
            )
            requestPermissions(this, required.toTypedArray(), RQ_PERM)
        }
    }

    private fun areAllPermissionsGranted(): Boolean {
        return (!Ondato.config.recordProcess || isGranted(RECORD_AUDIO)) && isGranted(CAMERA)
    }

    private fun showPermissionsDialog() {
        PermissionsDialog.show(this, ::startSettings)
    }

    private fun startSettings() {
        checkOnResume = true
        Settings.show(this)
    }

    private fun start() {
        if (Ondato.config.recordProcess) requestRecordPermission() else startIdentification()
    }

    private fun requestRecordPermission() {
        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startActivityForResult(
                manager.createScreenCaptureIntent(
                    MediaProjectionConfig.createConfigForDefaultDisplay()
                ),
                RQ_REC
            )
        } else {
            startActivityForResult(manager.createScreenCaptureIntent(), RQ_REC)
        }
    }

    private fun startIdentification() {
        val intent = MainActivity.newIntent(context = this@LauncherActivity)
        intent.putExtra(KEY_IS_RESTART, isRestart)
        intent.putExtra("requestCode", RQ_AUTH)
        startActivityForResult(intent, RQ_AUTH)
        isRestart = false
    }

    private fun Context.isGranted(permission: String): Boolean {
        return checkSelfPermission(this, permission) == PERMISSION_GRANTED
    }

    companion object {
        // TODO: perhaps move to constants separate file?
        const val KEY_IS_RESTART = "IS_RESTART"
        const val RQ_AUTH = 10234
        const val RQ_REC = 10235
        private const val RQ_PERM = 10236
        const val SHOULD_RESTART = "ondato.key.restart"
        internal const val KEY_ERROR = "ondato.key.error"
        fun start(context: Context?) {
            val intent = Intent(context, LauncherActivity::class.java)
            if (context !is Activity) intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context?.startActivity(intent)
        }
    }
}