package com.ondato.sdk.ui.poa

import com.ondato.sdk.log.Event.SelfieWithDocumentPage
import com.ondato.sdk.log.Logger
import com.ondato.sdk.ui.base.BaseViewModel
import com.ondato.sdk.ui.base.call
import com.ondato.sdk.ui.base.event
import com.ondato.sdk.usecase.FileType
import com.ondato.sdk.usecase.additionalDocument.SendAdditionalDocumentUseCase
import com.ondato.sdk.usecase.savephoto.Mode

internal class UploadPoaViewModel(
    private val sendAdditionalDocumentUseCase: SendAdditionalDocumentUseCase,
) : BaseViewModel() {
    val completed by event<Unit>()

    private var photoBuffer: ByteArray = byteArrayOf()
    private var mode: Mode = Mode.Address

    fun init(mode: Mode) {
        this.mode = mode

    }

    fun onContinueClicked(bytes: ByteArray, type: String) {
        launch {
            if (type.lowercase().contains(FileType.Pdf.type.lowercase())) {
                sendAdditionalDocumentUseCase.sendAlreadyStoredPDF(bytes, mode)
            } else {
                sendAdditionalDocumentUseCase.sendAlreadyStoredImage(bytes, mode)

            }
            photoBuffer = byteArrayOf()
            onSuccessLog()
            completed.call()
        }
    }

    private fun onSuccessLog() {
        Logger.log(SelfieWithDocumentPage)
    }
}