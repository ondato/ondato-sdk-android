package com.ondato.sdk.api.session

import com.google.gson.annotations.SerializedName

internal data class KycIdentificationResponse(
    @SerializedName("id") var id: String? = null,
)