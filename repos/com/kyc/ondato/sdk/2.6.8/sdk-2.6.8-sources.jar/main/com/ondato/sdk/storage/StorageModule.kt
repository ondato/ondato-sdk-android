package com.ondato.sdk.storage

import android.content.Context
import com.ondato.sdk.storage.file.AndroidPhotoStorage
import com.ondato.sdk.storage.installationid.PrefsInstallationIdStorage
import com.ondato.sdk.storage.language.SelectedLanguagePrefs
import com.ondato.sdk.usecase.installationid.InstallationIdStorage
import com.ondato.sdk.usecase.language.SelectedLanguageStorage
import com.ondato.sdk.usecase.savephoto.PhotoStorage
import org.koin.core.qualifier.named
import org.koin.core.scope.Scope
import org.koin.dsl.bind
import org.koin.dsl.module
import java.io.File

internal const val CACHE = "cache"
internal const val DOCS = "docs"
const val REC = "rec"

internal val storageModule = module {
    single(named(CACHE)) { initCache() }
    single(named(DOCS)) { initDocs() }
    single(named(REC)) { initRec() }
    factory { SelectedLanguagePrefs(get()) } bind SelectedLanguageStorage::class
    factory { AndroidPhotoStorage(get(named(DOCS))) } bind PhotoStorage::class
    factory { PrefsInstallationIdStorage(get()) } bind InstallationIdStorage::class
}

private fun Scope.initCache(): File {
    return File(get<Context>(Context::class).cacheDir, "/ondato/").apply { mkdir() }
}

private fun Scope.initDocs(): File {
    return File(get<File>(named(CACHE)), "/$DOCS/").apply { mkdir() }
}

private fun Scope.initRec(): File {
    return File(get<File>(named(CACHE)), "/$REC/").apply { mkdir() }
}