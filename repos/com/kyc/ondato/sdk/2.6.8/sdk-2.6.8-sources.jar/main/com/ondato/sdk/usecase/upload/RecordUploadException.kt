package com.ondato.sdk.usecase.upload

import java.io.IOException

class RecordUploadException(override val cause: Throwable? = null) : IOException()
class RecordingNotFoundException() : IOException()