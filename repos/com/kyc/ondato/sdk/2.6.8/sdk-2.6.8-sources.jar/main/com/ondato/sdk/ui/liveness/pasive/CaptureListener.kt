package com.ondato.sdk.ui.liveness.pasive

internal interface CaptureListener {
    fun onCaptured(frames: List<ByteArray>)

    fun onCaptureFailed()
}