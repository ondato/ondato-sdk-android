package com.ondato.sdk.usecase.logs

import android.content.Context
import com.ondato.sdk.Ondato
import com.ondato.sdk.log.Log
import com.ondato.sdk.log.Logger
import com.ondato.sdk.log.LogsSaver
import com.ondato.sdk.log.LogsSender
import com.ondato.sdk.ui.utils.StorageHelper
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlin.coroutines.CoroutineContext

internal class LogsUseCase(
    private val api: LogsApi,
    private val context: Context,
    private val coroutineContext: CoroutineContext = Dispatchers.IO,
) : LogsSender, LogsSaver {
    private val activityLogBatchFactory = ActivityLogBatchFactory {
        Ondato.config.identityVerificationId
    }

    override fun send(logs: List<Log>, onSuccess: () -> Unit, onError: (Throwable) -> Unit) {
        // Bind the batch to the session that emitted it. Reading Ondato.config from inside the
        // coroutine would allow a later init/session to retarget an already queued log batch.
        val batch = activityLogBatchFactory.bind(logs)
        GlobalScope.launch(coroutineContext + CoroutineExceptionHandler { _, throwable ->
            Logger.d(throwable, "Logs error")
        }) {
            try {
                api.send(batch.identityVerificationId, batch.logs)
            } catch (error: Exception) {
                onError(error)
            }
            onSuccess()
        }
    }

    override fun save(logs: List<String>, onSuccess: () -> Unit, onError: (Throwable) -> Unit) {
        //Logs saver is available only for our internal app
        //TODO: Also include the package name of react native internal app?
        val packageName = context.packageName
        if (packageName.equals("com.ondato.sdk.test")) {
            val logLines = logs.joinToString(separator = "\n\n") { it }
            StorageHelper(context).saveLogToFile(logLines)
            onSuccess()
        }
    }
}

internal data class ActivityLogBatch(
    val identityVerificationId: String,
    val logs: List<Log>,
)

internal class ActivityLogBatchFactory(
    private val identityVerificationIdProvider: () -> String,
) {
    fun bind(logs: List<Log>) = ActivityLogBatch(
        identityVerificationId = identityVerificationIdProvider(),
        logs = logs,
    )
}