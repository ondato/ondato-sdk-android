package com.ondato.sdk

import androidx.annotation.Keep

@Keep
internal data class RecorderConfig(
    val fps: Int,
    val bitrate: Long,
    val resolutionRatio: Float
) {
    companion object {
        fun default() = RecorderConfig(
            fps = 10,
            bitrate = 250_000,
            resolutionRatio = 0.5f
        )
    }
}