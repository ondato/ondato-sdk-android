package com.ondato.sdk.android

import android.os.Build
import com.ondato.sdk.usecase.deviceinfo.OsInfoProvider

internal class AndroidOsInfoProvider() : OsInfoProvider {

    override suspend fun getName(): String = "$ANDROID ${Build.VERSION.RELEASE}"

    override suspend fun getSdkVersion(): String = Build.VERSION.SDK_INT.toString()

    companion object {
        private const val ANDROID = "Android"
    }
}