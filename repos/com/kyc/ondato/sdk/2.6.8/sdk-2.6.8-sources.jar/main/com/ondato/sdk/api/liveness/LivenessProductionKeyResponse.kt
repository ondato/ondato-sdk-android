package com.ondato.sdk.api.liveness

import com.google.gson.annotations.SerializedName
import com.ondato.sdk.usecase.liveness.LivenessLicenseInfo

internal data class LivenessProductionKeyResponse(
    @SerializedName("key") val key: String? = null,
    @SerializedName("appId") val appId: String? = null,
    @SerializedName("expiryDate") val expiryDate: String? = null,
    @SerializedName("deviceKeyIdentifier") val deviceKeyIdentifier: String? = null,
    @SerializedName("publicFaceScanEncryptionKey") val publicFaceScanEncryptionKey: String? = null,
) {

    fun toLivenessLicenseInfo(): LivenessLicenseInfo {
        return LivenessLicenseInfo(
            "appId = ${appId ?: "*"}\nexpiryDate = ${expiryDate ?: ""}\nkey = ${key ?: ""}",
            token = "",
            deviceKeyIdentifier ?: "",
            publicFaceScanEncryptionKey ?: ""
        )
    }
}