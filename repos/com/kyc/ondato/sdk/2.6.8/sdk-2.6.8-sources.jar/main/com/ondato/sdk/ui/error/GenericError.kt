package com.ondato.sdk.ui.error

import com.ondato.sdk.R

object GenericError : ErrorMessage {
    override val title: Int = R.string.ondato_error_default_title
    override val message: Int = R.string.ondato_error_something_wrong_title
}