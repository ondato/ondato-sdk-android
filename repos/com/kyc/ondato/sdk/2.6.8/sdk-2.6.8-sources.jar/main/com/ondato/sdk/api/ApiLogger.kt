package com.ondato.sdk.api

import com.ondato.sdk.log.Logger
import okhttp3.logging.HttpLoggingInterceptor

/**
 * Since we are sending base64 data of pictures, video recordings and we also persist logs in a file,
 * we need to truncate messages in order to avoid large sizes of log files.
 */
internal object ApiLogger : HttpLoggingInterceptor.Logger {
    private const val MAX_LOG_LENGTH = 4000
    private const val TRUNCATE_MESSAGE = "This response has been cut off because it exceeded 4000 character limit"
    override fun log(message: String) {
        val truncatedMessage = if (message.length > MAX_LOG_LENGTH) {
            message.substring(0, MAX_LOG_LENGTH).plus(TRUNCATE_MESSAGE)
        } else {
            message
        }
        Logger.d(truncatedMessage)
    }
}