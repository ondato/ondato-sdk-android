package com.ondato.sdk.screen

import androidx.annotation.Keep

@Keep
fun interface StartScreenCallback {
    fun start()
}