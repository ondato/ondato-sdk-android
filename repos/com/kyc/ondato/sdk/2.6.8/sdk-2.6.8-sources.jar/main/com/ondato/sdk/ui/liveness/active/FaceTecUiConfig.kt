package com.ondato.sdk.ui.liveness.active

import android.content.Context
import android.graphics.Color
import com.facetec.sdk.FaceTecCancelButtonCustomization
import com.facetec.sdk.FaceTecCustomization
import com.facetec.sdk.FaceTecFeedbackCustomization
import com.facetec.sdk.FaceTecFrameCustomization
import com.facetec.sdk.FaceTecGuidanceCustomization
import com.facetec.sdk.FaceTecOvalCustomization
import com.facetec.sdk.FaceTecOverlayCustomization
import com.facetec.sdk.FaceTecVocalGuidanceCustomization
import com.ondato.sdk.R
import com.ondato.sdk.ui.utils.color

internal object FaceTecUiConfig {
    fun get(context: Context): FaceTecCustomization {
        return FaceTecCustomization().apply {
            context.apply {
                guidanceCustomization = FaceTecGuidanceCustomization().apply {
                    backgroundColors = color(R.color.ondatoActiveLivenessCameraFilter)
                    buttonBackgroundNormalColor = color(R.color.ondatoColorButton)
                    buttonBackgroundHighlightColor = color(R.color.ondatoHighlightButtonColor)
                    buttonBackgroundDisabledColor = color(R.color.ondatoDisabledButtonColor)
                    readyScreenTextBackgroundColor = Color.WHITE
                    readyScreenOvalFillColor = color(android.R.color.transparent)
                    foregroundColor = color(R.color.ondatoTextColor)
                }

                frameCustomization = FaceTecFrameCustomization().apply {
                    backgroundColor = color(R.color.ondatoActiveLivenessCameraFilter)
                    cornerRadius = 0
                    borderWidth = 0
                }

                feedbackCustomization = FaceTecFeedbackCustomization().apply {
                    backgroundColors = color(R.color.ondatoActiveLivenessCameraFilter)
                    textColor = color(R.color.ondatoTextColor)
                }

                ovalCustomization = FaceTecOvalCustomization().apply {
                    progressColor1 = color(R.color.ondatoActiveLivenessOvalProgressColor)
                    progressColor2 = color(R.color.ondatoActiveLivenessOvalProgressColorSecondary)
                    strokeColor = color(R.color.ondatoColorAlmostTransparent)
                    progressStrokeWidth = 6
                    strokeWidth = 6
                    progressRadialOffset = 12
                }

                overlayCustomization = FaceTecOverlayCustomization().apply {
                    showBrandingImage = false
                    backgroundColor = Color.WHITE
                }

                resultScreenCustomization = resultScreenCustomization.apply {
                    activityIndicatorColor = color(R.color.ondatoActiveLivenessResultActivityIndicatorColor)
                    foregroundColor = color(R.color.ondatoActiveLivenessResultForegroundColor)
                    resultAnimationBackgroundColor = color(R.color.ondatoActiveLivenessResultAnimationBackgroundColor)
                    uploadProgressFillColor = color(R.color.ondatoActiveLivenessResultUploadProgressColor)
                    resultAnimationForegroundColor = color(R.color.ondatoActiveLivenessResultAnimationForegroundColor)
                    uploadProgressTrackColor = color(R.color.ondatoActiveLivenessResultUploadProgressTrackColor)
                }

                cancelButtonCustomization = FaceTecCancelButtonCustomization().apply {
                    customImage = R.drawable.ondato_close_white_icon
                    location = FaceTecCancelButtonCustomization.ButtonLocation.DISABLED
                }

                vocalGuidanceCustomization = FaceTecVocalGuidanceCustomization().apply {
                    mode = FaceTecVocalGuidanceCustomization.VocalGuidanceMode.NO_VOCAL_GUIDANCE
                }
            }
        }
    }
}