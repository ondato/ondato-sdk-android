package com.ondato.sdk.ui.base

import android.os.Looper
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData

fun <T> LiveData<T>.set(value: T) {
    if (shouldUpdate(value)) {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            when (this) {
                is MutableLiveData -> this.value = value
                is MutableLiveNonNullData -> this.value = value
            }
        } else {
            when (this) {
                is MutableLiveData -> this.postValue(value)
                is MutableLiveNonNullData -> this.postValue(value)
            }
        }
    }
}

fun LiveData<Unit>.call() {
    this.set(Unit)
}

private fun <T> LiveData<T>.shouldUpdate(value: T): Boolean {
    return this is SingleLiveEvent || this.value != value
}