package com.ondato.sdk.ui.liveness.active

import android.content.Context
import android.os.Bundle
import com.ondato.sdk.Ondato
import com.ondato.sdk.R
import com.ondato.sdk.ui.base.BaseFragment
import com.ondato.sdk.ui.main.Failure.LiveCheckFailure
import com.ondato.sdk.ui.main.MainViewModel
import com.ondato.sdk.ui.main.Step.FACE_AUTH
import com.ondato.sdk.ui.main.Step.TAKE_FACE
import com.ondato.sdk.usecase.liveness.LivenessLicenseInfo
import com.ondato.sdk.usecase.savephoto.LivenessMode
import com.ondato.sdk.utils.WakeLock
import org.koin.androidx.viewmodel.ext.android.sharedViewModel
import org.koin.androidx.viewmodel.ext.android.viewModel

internal class ActiveLivenessCheckFragment : BaseFragment(R.layout.ondato_fragment_liveness) {
    private val config = Ondato.config
    private val viewModel: LivenessViewModel by viewModel()
    private val faceTecViewModel: FaceTecViewModel by viewModel()
    private val mainViewModel: MainViewModel by sharedViewModel()
    private val faceTecUi by lazy { FaceTecUi(faceTecViewModel, ::showSuccess, ::showFailure) }
    private val mode: LivenessMode by lazy {
        (arguments?.getSerializable(KEY_MODE) as? LivenessMode) ?: LivenessMode.Liveness
    }

    private var lock: WakeLock? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        ((arguments?.getSerializable(KEY_MODE) as? LivenessMode) ?: LivenessMode.Liveness).let(
            faceTecViewModel::init
        )
        viewModel.licenseInfo.observe(::startFaceTec)
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        lock = WakeLock(context)
        lock?.lockScreen()
        config.loadingScreenProvider.get().show(R.id.loadingContainer)
    }

    private fun startFaceTec(licenseInfo: LivenessLicenseInfo) {
        faceTecUi.start(licenseInfo, requireActivity())
    }

    private fun showSuccess() {
        if (mode == LivenessMode.FaceAuth) {
            mainViewModel.onStepSuccess(FACE_AUTH)
        } else {
            mainViewModel.onStepSuccess(TAKE_FACE)
        }
    }

    private fun showFailure(error: LivenessError) {
        mainViewModel.onStepFailed(LiveCheckFailure(error))
    }

    override fun onDestroy() {
        super.onDestroy()
        lock?.unlock()
        faceTecUi.stop()
    }

    companion object {
        private const val KEY_MODE = "ondato.key.mode"

        fun newInstance(mode: LivenessMode): ActiveLivenessCheckFragment {
            val bundle = Bundle()
            bundle.putSerializable(KEY_MODE, mode)
            val fragment = ActiveLivenessCheckFragment()
            fragment.arguments = bundle
            return fragment
        }
    }
}