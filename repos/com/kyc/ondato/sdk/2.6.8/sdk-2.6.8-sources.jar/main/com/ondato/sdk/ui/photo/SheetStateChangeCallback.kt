package com.ondato.sdk.ui.photo

import android.view.View
import com.google.android.material.bottomsheet.BottomSheetBehavior

abstract class SheetStateChangeCallback: BottomSheetBehavior.BottomSheetCallback() {
    override fun onSlide(bottomSheet: View, slideOffset: Float) {
        // ignore
    }
}