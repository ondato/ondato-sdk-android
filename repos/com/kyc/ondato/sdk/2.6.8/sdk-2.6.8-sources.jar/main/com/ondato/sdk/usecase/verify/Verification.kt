package com.ondato.sdk.usecase.verify

import androidx.annotation.Keep

@Keep
internal data class Verification(
    val isFaceInDocument: Boolean,
    val isMrzInDocument: Boolean,
    val isDocumentNotExpired: Boolean,
    val hasBothDocumentSides: Boolean,
    val isOnePerson: Boolean,
    val isFaceInSelfie: Boolean,
    var isFaceMatching: Boolean
) {
    companion object {
        fun failed() = Verification(false, false, false, false, false, false, false)

        fun verified() = Verification(true, true, true, true, true, true, true)
    }
}