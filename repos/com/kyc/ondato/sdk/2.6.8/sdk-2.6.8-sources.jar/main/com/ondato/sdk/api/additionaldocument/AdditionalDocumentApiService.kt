package com.ondato.sdk.api.additionaldocument

import com.ondato.sdk.api.BackendApi
import com.ondato.sdk.usecase.additionalDocument.AdditionalDocumentApi
import com.ondato.sdk.usecase.savephoto.Mode

internal class AdditionalDocumentApiService(
    private val api: BackendApi,
) : AdditionalDocumentApi {

    override suspend fun send(
        identityVerificationId: String,
        imageBase64: String,
        imageFileType: String,
        mode: Mode,
    ) {
        api.sendAdditionalDocument(
            identityVerificationId,
            AdditionalDocumentBody(imageBase64, imageFileType, AdditionalDocumentType.of(mode))
        )
    }
}