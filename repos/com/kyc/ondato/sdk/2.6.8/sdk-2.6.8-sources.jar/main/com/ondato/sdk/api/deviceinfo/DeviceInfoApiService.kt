package com.ondato.sdk.api.deviceinfo

import com.ondato.sdk.api.BackendApi
import com.ondato.sdk.api.session.DeviceInfoBodyV2
import com.ondato.sdk.usecase.deviceinfo.DeviceInfoApi

internal class DeviceInfoApiService(
    private val api: BackendApi,
) : DeviceInfoApi {

    override suspend fun sendDeviceInfoV2(identityVerificationId: String, info: DeviceInfoBodyV2) {
        api.sendDeviceInfo(identityVerificationId, info)
    }
}