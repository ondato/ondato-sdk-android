package com.ondato.sdk.usecase.session.identification

internal interface RestartIdentificationApi {
    suspend fun restartIdentification(kycId: String)
}