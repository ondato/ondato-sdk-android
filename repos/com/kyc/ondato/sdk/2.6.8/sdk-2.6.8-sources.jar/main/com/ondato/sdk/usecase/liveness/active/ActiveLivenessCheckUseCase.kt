package com.ondato.sdk.usecase.liveness.active

import com.ondato.sdk.api.facetec.ActiveLivenessCheckBody
import com.ondato.sdk.usecase.liveness.LivenessApi
import com.ondato.sdk.usecase.session.Session

internal class ActiveLivenessCheckUseCase(
    private val session: Session,
    private val livenessapi: LivenessApi,
) {

    suspend fun check(
        sessionId: String,
        faceScanBase64: String,
        sessionUserAgent: String,
        auditImagesBase64: List<String>,
        lowQualityAuditImagesBase64: List<String>,
    ) {
        val activeLivenessCheckBody = ActiveLivenessCheckBody(
            sessionId,
            faceScanBase64,
            sessionUserAgent,
            auditImagesBase64,
            lowQualityAuditImagesBase64,
        )
        livenessapi.sendActiveCheck(session.kycId, activeLivenessCheckBody)
    }

    suspend fun checkFaceAuth(
        sessionId: String,
        faceScanBase64: String,
        sessionUserAgent: String,
        auditImagesBase64: List<String>,
        lowQualityAuditImagesBase64: List<String>,
    ) {
        val activeLivenessCheckBody = ActiveLivenessCheckBody(
            sessionId,
            faceScanBase64,
            sessionUserAgent,
            auditImagesBase64,
            lowQualityAuditImagesBase64,
        )
        val faceAuthId = session.faceAuthId
        print(session.faceAuthId)
        livenessapi.sendFaceAuth(faceAuthId ?: "", activeLivenessCheckBody)
    }}