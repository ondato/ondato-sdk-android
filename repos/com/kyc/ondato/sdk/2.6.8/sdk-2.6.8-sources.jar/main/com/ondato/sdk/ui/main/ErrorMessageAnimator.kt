package com.ondato.sdk.ui.main

import android.view.View

internal object ErrorMessageAnimator {
    private const val DURATION = 300L

    fun show(top: View?, bottom: View?, overlay: View?) {
        top.show()
        bottom.show()
        overlay.animateAlpha(0.3f)
        overlay?.isClickable = true
        overlay?.isFocusable = true
    }

    fun hide(top: View?, bottom: View?, overlay: View?) {
        top.hide(true)
        bottom.hide(false)
        overlay.animateAlpha(0f)
        overlay?.isClickable = false
        overlay?.isFocusable = false

    }

    private fun View?.show() {
        this?.apply {
            animate().translationY(0f).setDuration(DURATION).start()
        }
    }

    private fun View?.animateAlpha(alpha: Float) {
        this?.apply {
            animate().alpha(alpha).setDuration(DURATION).start()

        }
    }

    private fun View?.hide(moveUp: Boolean) {
        this?.apply {
            val direction = if (moveUp) -1 else 1
            animate()
                .translationY(direction * measuredHeight.toFloat())
                .setDuration(DURATION)
                .start()
        }
    }
}