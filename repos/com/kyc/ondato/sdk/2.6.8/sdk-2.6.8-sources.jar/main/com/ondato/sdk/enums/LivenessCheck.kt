package com.ondato.sdk.enums

import androidx.annotation.Keep

@Keep
enum class LivenessCheck { Active, Passive; }