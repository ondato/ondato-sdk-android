package com.ondato.sdk.api.identification

import com.ondato.sdk.api.BackendApi
import com.ondato.sdk.usecase.identification.Identification
import com.ondato.sdk.usecase.identification.IdentificationApi

internal class IdentificationService(
    private val backendApi: BackendApi,
): IdentificationApi {

    override suspend fun getIdentification(kycId: String): Identification {
        return IdentificationMapper.map(backendApi.getIdentificationData(kycId))
    }
}