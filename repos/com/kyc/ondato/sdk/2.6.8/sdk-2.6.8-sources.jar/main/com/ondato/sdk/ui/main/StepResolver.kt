package com.ondato.sdk.ui.main

import com.ondato.sdk.Ondato
import com.ondato.sdk.enums.NFCScan
import com.ondato.sdk.log.Logger
import com.ondato.sdk.usecase.document.DocumentPart
import com.ondato.sdk.usecase.document.DocumentPart.Companion.toStep
import com.ondato.sdk.usecase.document.DocumentType
import com.ondato.sdk.usecase.session.Session
import com.ondato.sdk.usecase.session.configuration.Steps

internal class StepResolver(private val session: Session) {

    var currentStep: Int = -1

    var steps = mutableListOf<Step>()

    fun generateSteps() {
        var stepList = mutableListOf<Step>()

        if (Ondato.config.showStartScreen) {
            stepList.add(Step.START)
        }

        session.kycSteps.forEach {
            when (it.type) {
                Steps.Type.Consent -> {
                    stepList.add(Step.TERMS)
                }
                Steps.Type.Registration -> {
                    stepList.add(Step.REGISTRATION)
                }
                Steps.Type.KycIdentification -> {

                    if (session.apiConfig?.documentsInfo?.enabled == true) {
                        if (session.apiConfig?.documentsInfo?.types.orEmpty().count() > 1) {
                            stepList.add(Step.SELECT_DOCUMENT)
                        } else {
                            session.selectedType = session.apiConfig?.documentsInfo?.types?.first()?.type ?: DocumentType.Unknown
                        }

                        if (Ondato.config.NFCScan != NFCScan.No) {
                            stepList.add(Step.CAPTURE_DOCUMENT_MRZ_INSTRUCTIONS)
                            stepList.add(Step.CAPTURE_DOCUMENT_NFC_INSTRUCTIONS)
                        }

                        var hasFront = false
                        var hasBack = false
                        session.apiConfig?.documentsInfo?.types.orEmpty().forEach {
                            if (it.parts.contains(DocumentPart.Front) ||
                                it.parts.contains(DocumentPart.FrontCover) ||
                                it.parts.contains(DocumentPart.DataPage)) {
                                hasFront = true
                            }

                            if (it.parts.contains(DocumentPart.Back)) {
                                hasBack = true
                            }
                        }

                        if (hasFront && Ondato.config.NFCScan == NFCScan.No) {
                            stepList.add(Step.CAPTURE_DOCUMENT_FRONT_INSTRUCTIONS)
                        }

                        if (hasBack && Ondato.config.NFCScan == NFCScan.No) {
                            stepList.add(Step.CAPTURE_DOCUMENT_BACK_INSTRUCTIONS)
                        }
                    }

                    if (session.apiConfig?.face?.enabled == true) {
                        stepList.add(Step.CAPTURE_FACE_INSTRUCTIONS)
                        stepList.add(Step.TAKE_FACE)
                    }

                    if (session.showProofOfAddressStep) {
                        stepList.add(Step.SELECT_POA_METHOD)
                    }

                    if (Ondato.config.showSelfieWithDocumentScreen) {
                        stepList.add(Step.CAPTURE_SELFIE_WITH_DOCUMENT_INSTRUCTIONS)
                    }

                }
                else -> return
            }
        }

        if (session.kycSteps.isNotEmpty()) {
            stepList.add(Step.COMPARE)
        }

        if (session.faceAuthId != null) {
            stepList.add(Step.CAPTURE_FACE_INSTRUCTIONS)
            stepList.add(Step.FACE_AUTH)
        }

        if (stepList.count() < 2) {
            // No steps have been generated
            steps = mutableListOf<Step>()
            return
        }

        if (session.apiConfig?.resultsWaiting?.enabled == true) {
            stepList.add(Step.IDENTIFICATION_WAITING_PAGE)
        }

        if (Ondato.config.showSuccess) {
            stepList.add(Step.SUCCESS)
        }

        stepList.add(Step.FINISH)

        steps = stepList

        Logger.d("Generated steps ${steps}")
    }

    fun nextStep(): Step {
        currentStep += 1
        return steps[currentStep]
    }

    fun previousStep(): Step {
        if (currentStep > 0) {
            currentStep -= 1
        }
        return steps[currentStep]
    }

    fun getPreviousStep(): Step {
        if (currentStep < 1) {
            return steps[currentStep]
        } else {
            return steps[currentStep - 1]
        }
    }

    fun getCurrentStep(): Step? {
        if (currentStep >= 1) {
            return steps[currentStep]
        }

        return null
    }

    fun restart() {
        currentStep = steps.indexOf(Step.SELECT_DOCUMENT)
    }

    fun disableNfc() {
        generateSteps()
        restart()
    }
}