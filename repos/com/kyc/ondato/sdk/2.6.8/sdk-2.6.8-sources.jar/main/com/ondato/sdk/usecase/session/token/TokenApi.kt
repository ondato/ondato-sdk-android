package com.ondato.sdk.usecase.session.token

internal interface TokenApi {

    suspend fun getTokenV2(identityVerificationId: String): Token

    suspend fun getFullAccessTokenV2(identityVerificationId: String): Token
}