package com.ondato.sdk.usecase.liveness

internal data class LivenessLicenseInfo(
    val key: String,
    val token: String,
    val deviceKeyIdentifier: String,
    val publicFaceScanEncryptionKey: String,
)