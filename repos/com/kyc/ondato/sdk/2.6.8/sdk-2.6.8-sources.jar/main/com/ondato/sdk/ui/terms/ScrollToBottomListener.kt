package com.ondato.sdk.ui.terms

import android.view.ViewTreeObserver
import android.widget.ScrollView

internal class ScrollToBottomListener(
    private val scrollview: ScrollView,
    private val callback: () -> Unit
) : ViewTreeObserver.OnScrollChangedListener {

    init {
        scrollview.viewTreeObserver.addOnScrollChangedListener(this)
    }

    override fun onScrollChanged() {
        if (scrollview.getChildAt(0).bottom <= scrollview.height + scrollview.scrollY) {
            callback()
            scrollview.viewTreeObserver.removeOnScrollChangedListener(this)
        }
    }
}

internal fun ScrollView.onScrollToBottom(callback: () -> Unit) {
    ScrollToBottomListener(this, callback)
}