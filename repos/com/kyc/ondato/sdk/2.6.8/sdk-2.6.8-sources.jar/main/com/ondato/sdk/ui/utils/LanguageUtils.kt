package com.ondato.sdk.ui.utils

import android.content.res.Resources
import androidx.core.os.ConfigurationCompat
import java.util.Locale

object LanguageUtils {
    fun getSystemLocale(): Locale = ConfigurationCompat.getLocales(
        Resources.getSystem().configuration
    ).get(0) ?: Locale.getDefault()
}