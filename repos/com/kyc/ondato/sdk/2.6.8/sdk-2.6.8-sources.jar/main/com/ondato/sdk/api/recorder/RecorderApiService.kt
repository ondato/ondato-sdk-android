package com.ondato.sdk.api.recorder

import androidx.annotation.Keep
import com.ondato.sdk.api.BackendApi
import com.ondato.sdk.usecase.recording.RecorderApi

@Keep
internal class RecorderApiService(private val api: BackendApi) : RecorderApi {

    @Keep
    override suspend fun send(kycId: String, videoBase64: String, videoFileType: String) {
        api.sendRecording(kycId, RecordingBody(videoBase64, videoFileType))
    }
}