package com.ondato.sdk.enums

import androidx.annotation.Keep

@Keep
enum class NFCScan {
    No,
    Optional,
    Mandatory;

    companion object {
        fun of(name: String): NFCScan {
            return values().firstOrNull { it.name.equals(name, ignoreCase = true) } ?: No
        }
    }
}