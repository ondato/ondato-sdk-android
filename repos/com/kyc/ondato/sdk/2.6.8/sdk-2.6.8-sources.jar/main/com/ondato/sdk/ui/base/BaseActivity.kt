package com.ondato.sdk.ui.base

import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.LiveData
import com.ondato.sdk.di.DependencyInjectionEntry

abstract class BaseActivity : AppCompatActivity(), DependencyInjectionEntry {

    private val binding = ViewBinding { findViewById(android.R.id.content) }

    override fun onDestroy() {
        binding.clear()
        super.onDestroy()
    }

    protected fun <T> LiveData<T>.observe(action: (T) -> Unit) {
        this.observe(this@BaseActivity) { value -> value?.let(action) }
    }

    protected fun LiveData<Unit>.observe(action: () -> Unit) {
        this.observe(this@BaseActivity) { action() }
    }

    protected fun <T : View> Int.find(): T? {
        return binding.find(this)
    }

    protected fun Int.view(): View? {
        return binding.find(this)
    }

    protected fun View?.onClick(action: () -> Unit) {
        this?.setOnClickListener { action() }
    }

    protected fun Int.onClick(action: () -> Unit) {
        view()?.onClick(action)
    }

    protected fun Int.show(isVisible: Boolean) {
        view()?.visibility = if (isVisible) View.VISIBLE else View.GONE
    }
}