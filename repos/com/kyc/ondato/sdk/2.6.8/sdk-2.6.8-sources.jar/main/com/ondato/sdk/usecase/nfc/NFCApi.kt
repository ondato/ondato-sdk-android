package com.ondato.sdk.usecase.nfc

import androidx.annotation.Keep
import com.ondato.sdk.api.nfc.NFCUploadRequestV2

@Keep
interface NFCApi {
    @Keep
    suspend fun send(kycId: String, body: NFCUploadRequestV2)
}