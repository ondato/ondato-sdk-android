package com.ondato.sdk.ui.main

import androidx.annotation.Keep

@Keep
enum class Step(val order: Int) {
    REGISTRATION(-1), // -1 means that order is driven by kycSetup
    TERMS(-1), // -1 means that order is driven by kycSetup

    INITIALIZE(0),  // KYC flow start
    START(1),
    FORCE_START(1),
    SELECT_DOCUMENT(2),
    CAPTURE_DOCUMENT_MRZ_INSTRUCTIONS(3),
    SCAN_MRZ(4),
    MRZ_SUCCESS(5),
    MRZ_FAILURE(5),
    CAPTURE_DOCUMENT_NFC_INSTRUCTIONS(6),
    SCAN_NFC(7),
    NFC_NOT_ALLOWED(8),
    FAILURE_NFC(9),
    CAPTURE_DOCUMENT_FRONT_INSTRUCTIONS(10),
    TAKE_DOCUMENT_FRONT(11),
    CAPTURE_DOCUMENT_BACK_INSTRUCTIONS(12),
    TAKE_DOCUMENT_BACK(13),

    CAPTURE_FACE_INSTRUCTIONS(14), // facetec start
    TAKE_FACE(15),
    CAPTURE_SELFIE_WITH_DOCUMENT_INSTRUCTIONS(16),
    TAKE_SELFIE_WITH_DOCUMENT(17), // facetec end

    SELECT_POA_METHOD(18), //todo: hardcoded order, should come from kycSetup
    UPLOAD_POA(19), //todo: hardcoded order, should come from kycSetup

    CAPTURE_POA_INSTRUCTIONS(20),
    CAPTURE_POA(21),

    FACE_AUTH(23),
    FACE_AUTH_SUCCESS(24),

    COMPARE(25), // KYC flow end (complete endpoint gets called)

    WAITING(26),
    IDENTIFICATION_WAITING_PAGE(27),
    IDENTIFICATION_WAITING_PAGE_RESULT(28),
    TOO_MANY_ATTEMPTS(29),
    SUCCESS(30),
    FINISH(31);

    companion object {
        fun next(step: Step?): Step? {
            if (step == null) return null

            val order = step.order + 1
            return values().firstOrNull { value -> order == value.order } ?: FINISH
        }
    }
}