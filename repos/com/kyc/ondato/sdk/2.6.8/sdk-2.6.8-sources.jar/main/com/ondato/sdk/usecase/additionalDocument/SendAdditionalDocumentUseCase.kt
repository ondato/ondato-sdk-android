package com.ondato.sdk.usecase.additionalDocument

import android.graphics.Bitmap
import android.util.Base64
import com.ondato.sdk.usecase.FileType
import com.ondato.sdk.usecase.ImageFileType
import com.ondato.sdk.usecase.savephoto.Mode
import com.ondato.sdk.usecase.savephoto.PhotoStorage
import com.ondato.sdk.usecase.session.Session
import com.ondato.sdk.utils.Base64.decodeToBase64
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

internal class SendAdditionalDocumentUseCase(
    private val session: Session,
    private val storage: PhotoStorage,
    private val additionalDocumentApi: AdditionalDocumentApi,
    private val dispatcher: CoroutineDispatcher = Dispatchers.Default,
) {
    suspend fun storeAndSendImage(photo: ByteArray, mode: Mode) = withContext(dispatcher) {
        val file = storage.save(photo, mode)
        additionalDocumentApi.send(
            session.kycId,
            file.path.decodeToBase64(Bitmap.CompressFormat.JPEG),
            ImageFileType.Jpeg.type,
            mode,
        )
    }

    suspend fun sendAlreadyStoredImage(photo: ByteArray, mode: Mode) = withContext(dispatcher) {
        additionalDocumentApi.send(
            session.kycId,
            Base64.encodeToString(photo, Base64.NO_WRAP),
            ImageFileType.Jpeg.type,
            mode,
        )
    }

    suspend fun sendAlreadyStoredPDF(pdf: ByteArray, mode: Mode) = withContext(dispatcher) {
        additionalDocumentApi.send(
            session.kycId,
            Base64.encodeToString(pdf, Base64.NO_WRAP),
            FileType.Pdf.type,
            mode,
        )
    }

}