package com.ondato.sdk.usecase.language

import com.ondato.sdk.enums.Language

internal class SelectedLanguageUseCase(
    private val storage: SelectedLanguageStorage
) {
    suspend fun get() = storage.get()

    suspend fun set(languages: Language) = storage.set(languages)

    suspend fun clear() = storage.clear()
}