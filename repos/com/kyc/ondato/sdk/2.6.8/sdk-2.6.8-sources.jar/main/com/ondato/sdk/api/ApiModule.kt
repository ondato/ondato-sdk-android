package com.ondato.sdk.api

import com.google.gson.GsonBuilder
import com.ondato.sdk.OndatoConfig
import com.ondato.sdk.OndatoConfig.Mode.TEST
import com.ondato.sdk.api.additionaldocument.AdditionalDocumentApiService
import com.ondato.sdk.api.complete.CompleteService
import com.ondato.sdk.api.deviceinfo.DeviceInfoApiService
import com.ondato.sdk.api.document.DocumentApiService
import com.ondato.sdk.api.facetec.FaceTecApiService
import com.ondato.sdk.api.facetec.LivenessApiService
import com.ondato.sdk.api.identification.IdentificationService
import com.ondato.sdk.api.interceptor.AuthInterceptor
import com.ondato.sdk.api.interceptor.ErrorInterceptor
import com.ondato.sdk.api.logs.LogsService
import com.ondato.sdk.api.nfc.NFCUploadApiService
import com.ondato.sdk.api.recorder.RecorderApiService
import com.ondato.sdk.api.registration.RegistrationService
import com.ondato.sdk.api.restart.RestartIdentificationApiService
import com.ondato.sdk.api.session.ConfigurationApiService
import com.ondato.sdk.api.session.VerificationApiService
import com.ondato.sdk.api.token.TokenApiService
import com.ondato.sdk.usecase.additionalDocument.AdditionalDocumentApi
import com.ondato.sdk.usecase.deviceinfo.DeviceInfoApi
import com.ondato.sdk.usecase.document.DocumentApi
import com.ondato.sdk.usecase.identification.IdentificationApi
import com.ondato.sdk.usecase.liveness.FaceTecApi
import com.ondato.sdk.usecase.liveness.LivenessApi
import com.ondato.sdk.usecase.logs.LogsApi
import com.ondato.sdk.usecase.nfc.NFCApi
import com.ondato.sdk.usecase.recording.RecorderApi
import com.ondato.sdk.usecase.session.CompleteApi
import com.ondato.sdk.usecase.registration.RegistrationApi
import com.ondato.sdk.usecase.session.configuration.ConfigurationApi
import com.ondato.sdk.usecase.session.identification.RestartIdentificationApi
import com.ondato.sdk.usecase.session.token.TokenApi
import com.ondato.sdk.usecase.session.verification.VerificationApi
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import okhttp3.logging.HttpLoggingInterceptor.Level.*
import org.koin.core.qualifier.named
import org.koin.core.scope.Scope
import org.koin.dsl.bind
import org.koin.dsl.module
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.converter.scalars.ScalarsConverterFactory
import java.util.concurrent.TimeUnit
import kotlin.reflect.KClass

private const val SANDBOX_API_URL = "https://sandbox-idvs.ondato.com"
private const val PROD_API_URL = "https://idvs.ondato.com"

private const val DEFAULT_TIME_OUT = 2L
private const val MAIN = "main"
private const val BASE = "base"

internal fun apiModule(mode: OndatoConfig.Mode) = module {
    factory { TokenApiService(get()) } bind TokenApi::class
    factory { ConfigurationApiService(get()) } bind ConfigurationApi::class
    factory { VerificationApiService(get()) } bind VerificationApi::class
    factory { CompleteService(get()) } bind CompleteApi::class
    factory { FaceTecApiService(get(), get()) } bind FaceTecApi::class
    factory { LogsService(get()) } bind LogsApi::class
    factory { DeviceInfoApiService(get()) } bind DeviceInfoApi::class
    factory {
        IdentificationService(get())
    } bind IdentificationApi::class
    factory {
        RestartIdentificationApiService(get())
    } bind RestartIdentificationApi::class
    factory { AdditionalDocumentApiService(get()) } bind AdditionalDocumentApi::class
    factory { RecorderApiService(get()) } bind RecorderApi::class
    factory { DocumentApiService(get()) } bind DocumentApi::class
    factory { LivenessApiService(get()) } bind LivenessApi::class
    factory { NFCUploadApiService(get()) } bind NFCApi::class
    factory { RegistrationService(get()) } bind RegistrationApi::class
    single { initRetrofit(mode) }
    single { initApi(BackendApi::class) }
    single(named(MAIN)) { initMainOkHttpClient() }
    single(named(BASE)) { initDefaultOkHttpClient() }
    single { initGson() }
}

private fun <T : Any> Scope.initApi(clazz: KClass<T>): T = get<Retrofit>().create(clazz.java)

private fun Scope.initMainOkHttpClient() = get<OkHttpClient>(named(BASE)).newBuilder()
    .addNetworkInterceptor(HttpLoggingInterceptor().apply { level = BODY })
    .addNetworkInterceptor(HttpLoggingInterceptor(ApiLogger).apply { level = BODY })
    .addNetworkInterceptor(AuthInterceptor(get()))
    .addNetworkInterceptor(ErrorInterceptor())
    .build()

private fun initDefaultOkHttpClient() = OkHttpClient.Builder()
    .readTimeout(DEFAULT_TIME_OUT, TimeUnit.MINUTES)
    .writeTimeout(DEFAULT_TIME_OUT, TimeUnit.MINUTES)
    .connectTimeout(DEFAULT_TIME_OUT, TimeUnit.MINUTES)
    .build()

private fun initGson() = GsonBuilder().setLenient().create()

private fun Scope.initRetrofit(mode: OndatoConfig.Mode) = Retrofit.Builder()
    .baseUrl(if (mode == TEST) SANDBOX_API_URL else PROD_API_URL)
    .client(get(named(MAIN)))
    .addConverterFactory(GsonConverterFactory.create(get()))
    .addConverterFactory(ScalarsConverterFactory.create())
    .build()