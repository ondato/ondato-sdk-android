package com.ondato.sdk.ui.photo

import com.ondato.sdk.log.Event
import com.ondato.sdk.log.Logger
import com.otaliastudios.cameraview.CameraException
import com.otaliastudios.cameraview.CameraListener
import com.otaliastudios.cameraview.CameraOptions
import com.otaliastudios.cameraview.PictureResult

internal class PhotoListener(private val callback: (ByteArray) -> Unit) : CameraListener() {
    override fun onPictureTaken(result: PictureResult) {
        callback(result.data)
    }

    override fun onCameraOpened(options: CameraOptions) {
        Logger.log(Event.CameraStarted)
    }

    override fun onCameraError(exception: CameraException) {
        Logger.log(Event.InactiveCameraSource)
    }
}