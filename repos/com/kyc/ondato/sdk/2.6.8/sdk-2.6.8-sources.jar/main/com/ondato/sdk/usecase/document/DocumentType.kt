package com.ondato.sdk.usecase.document

import androidx.annotation.Keep
import com.ondato.sdk.error.BadDocumentTypeException

@Keep
enum class DocumentType(val type: String) {
    Passport("Passport"),
    IdCard("IdCard"),
    DriverLicense("DriverLicense"),
    Unknown("unknown");

    companion object {
        fun of(type: String): DocumentType {
            return values().firstOrNull { it.type == type } ?: Unknown
        }
    }
}