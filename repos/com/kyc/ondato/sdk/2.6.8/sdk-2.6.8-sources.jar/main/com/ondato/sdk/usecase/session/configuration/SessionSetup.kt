package com.ondato.sdk.usecase.session.configuration

import androidx.annotation.Keep

@Keep
internal data class SessionSetup(
    val id: String,
    val applicationId: String,
    val resourceDirectoryName: String,
    val generalAppSetting: GeneralAppSetting,
    val webAppSetting: WebAppSetting,
    val omnichannel: Omnichannel,
    val sessionScreenRecording: SessionScreenRecording,
    val steps: List<Steps> = emptyList(),
) {

    companion object {
        internal val EMPTY = SessionSetup(
            "",
            "",
            "",
            GeneralAppSetting.EMPTY,
            WebAppSetting.EMPTY,
            Omnichannel.EMPTY,
            SessionScreenRecording.EMPTY,
            steps = emptyList()
        )
    }
}

@Keep
internal data class GeneralAppSetting(val supportEmail: String) {

    companion object {

        internal val EMPTY = GeneralAppSetting("")
    }
}

@Keep
internal data class LocalisationSettings(
    val language: String,
    val successRedirectUrl: String,
    val consentDeclinedRedirectUrl: String,
    val failureRedirectUrl: String,
    val pageTitle: String,
) {

    companion object {

        internal val EMPTY = LocalisationSettings("", "", "", "", "")
    }
}

@Keep
data class Steps(
    val type: Type,
    val order: Int,
    val setupId: String,
) {

    enum class Type(val type: String) {
        Consent("Consent"),
        Registration("Registration"),
        KycIdentification("KycIdentification"),
        FaceAuthentication("FaceAuthentication"),
        Unknown("");

        companion object {
            fun of(name: String) = values().firstOrNull { it.name == name } ?: Unknown
        }
    }
}

@Keep
internal data class WebAppSetting(
    val baseUrl: String,
    val declinedBrowserPermissionsBaseUrl: String,
    val localisationSettings: List<LocalisationSettings> = emptyList(),
) {

    companion object {

        internal val EMPTY = WebAppSetting("", "")
    }
}

@Keep
internal data class SessionScreenRecording(val enabled: Boolean) {

    companion object {

        internal val EMPTY = SessionScreenRecording(false)
    }
}

@Keep
internal data class Omnichannel(val enabled: Boolean, val appStoreEnabled: Boolean) {

    companion object {

        internal val EMPTY = Omnichannel(false, false)
    }
}