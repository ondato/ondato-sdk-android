package com.ondato.sdk.ui.main

import android.app.Activity
import com.ondato.sdk.log.Log
import com.ondato.sdk.log.Logger
import com.ondato.sdk.ui.error.ErrorMessage

internal object ErrorHandler {

    fun handle(activity: MainActivity, error: ErrorMessage) {
        activity.setResult(Activity.RESULT_CANCELED)
        activity.finish()
    }

}