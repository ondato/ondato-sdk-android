package com.ondato.sdk.storage.language

import android.content.SharedPreferences
import android.content.SharedPreferences.OnSharedPreferenceChangeListener
import com.ondato.sdk.enums.Language
import com.ondato.sdk.usecase.language.SelectedLanguageStorage
import kotlinx.coroutines.Dispatchers.IO
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.withContext

internal class SelectedLanguagePrefs(
    private val prefs: SharedPreferences
) : SelectedLanguageStorage {

    override suspend fun get() = withContext(IO) { getOrDefault() }

    override suspend fun set(language: Language) = withContext(IO) {
        prefs.edit().putString(KEY_LANGUAGE, language.languageString).apply()
    }

    override suspend fun clear() = withContext(IO) {
        prefs.edit().putString(KEY_LANGUAGE, null).apply()
    }

    @ExperimentalCoroutinesApi
    override suspend fun observe() = withContext(IO) {
        callbackFlow {
            val listener = OnSharedPreferenceChangeListener { _, key ->
                if (key == KEY_LANGUAGE) this.trySend(getOrDefault()).isSuccess
            }
            prefs.registerOnSharedPreferenceChangeListener(listener)
            awaitClose { prefs.unregisterOnSharedPreferenceChangeListener(listener) }
        }
    }

    private fun getOrDefault(default: Language = Language.English): Language {
        val lang = prefs.getString(KEY_LANGUAGE, default.languageString) ?: return default
        return Language.of(lang)
    }

    companion object {
        private const val KEY_LANGUAGE = "key.language"
    }
}