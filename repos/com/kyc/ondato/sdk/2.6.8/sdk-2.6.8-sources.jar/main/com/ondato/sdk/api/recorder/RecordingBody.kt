package com.ondato.sdk.api.recorder

import com.google.gson.annotations.SerializedName

internal class RecordingBody(
    @SerializedName("videoBase64") val videoBase64: String,
    @SerializedName("videoFileType") val videoFileType: String,
)