package com.ondato.sdk.usecase.liveness

sealed class LivenessResult {
    data class Success(
        val body: String?,
        val ageEstimateGroup: String?,
        val enrollmentId: String?
    ) : LivenessResult()

    data class Uploading(val progress: Float) : LivenessResult()
    sealed class Failure(val body: String?) : LivenessResult() {
        class ServerError(body: String?) : Failure(body)
        class LivenessCheckFailed(body: String?) : Failure(body)
    }
}

