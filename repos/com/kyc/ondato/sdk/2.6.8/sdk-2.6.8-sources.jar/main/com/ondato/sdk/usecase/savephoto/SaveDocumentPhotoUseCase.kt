package com.ondato.sdk.usecase.savephoto

import com.ondato.sdk.usecase.session.Session
import com.ondato.sdk.usecase.upload.Upload
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.coroutines.CoroutineContext

internal class SaveDocumentPhotoUseCase(
    private val session: Session,
    private val storage: PhotoStorage,
    private val context: CoroutineContext = Dispatchers.IO
) {
    suspend fun save(photo: ByteArray, mode: Mode) = withContext(context) {
        val file = storage.save(photo, mode)
        val documentType = session.selectedType ?: return@withContext
        session.uploads.add(Upload.FileUpload.DocumentUpload(file, documentType, mode))
    }
}