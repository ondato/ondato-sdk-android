package com.ondato.sdk.ui.success

import androidx.fragment.app.Fragment
import com.ondato.sdk.screen.SuccessScreenCallback
import com.ondato.sdk.screen.SuccessScreenProvider

internal object DefaultSuccessScreenProvider : SuccessScreenProvider {
    override fun get(callback: SuccessScreenCallback): Fragment {
        return SuccessFragment.newInstance(callback)
    }
}