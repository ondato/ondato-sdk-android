package com.ondato.sdk.ui.liveness.pasive

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View
import com.ondato.sdk.R

class PunchHoleView(context: Context, attrs: AttributeSet? = null) : View(context, attrs) {
    private var cutout: Bitmap? = null
    private val elWidth = resources.getDimensionPixelOffset(R.dimen.ondato_face_clip_width)
    private val elHeight = resources.getDimensionPixelOffset(R.dimen.ondato_face_clip_height)

    override fun onDraw(canvas: Canvas) {
        if (canvas == null) {
            super.onDraw(canvas)
        } else {
            canvas.drawBitmap(getCutout(), 0f, 0f, null)
        }
    }

    override fun onDetachedFromWindow() {
        cutout?.recycle()
        cutout = null
        super.onDetachedFromWindow()
    }

    private fun getCutout(): Bitmap {
        val res = cutout
        return if (res == null) {
            val bitmap = create()
            cutout = bitmap
            bitmap
        } else {
            res
        }
    }

    private fun create(): Bitmap {
        val parentWidth = measuredWidth
        val parenHeight = measuredHeight
        val x = (parentWidth / 2 - elWidth / 2).toFloat()
        val y = (parenHeight / 2 - elHeight / 2).toFloat()

        val bitmap = Bitmap.createBitmap(measuredWidth, measuredHeight, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(Color.WHITE)
        val paint = Paint()
        paint.color = Color.WHITE
        paint.xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
        val rect = RectF(x, y, x + elWidth.toFloat(), y + elHeight.toFloat())
        canvas.drawOval(rect, paint)
        return bitmap
    }
}