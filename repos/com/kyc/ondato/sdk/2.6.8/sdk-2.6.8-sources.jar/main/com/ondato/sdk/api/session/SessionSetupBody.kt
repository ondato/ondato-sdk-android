package com.ondato.sdk.api.session

import androidx.annotation.Keep
import com.google.gson.annotations.SerializedName

@Keep
internal class SessionSetupBody(
    @SerializedName("identityVerificationId") val identityVerificationId: String,
//    @SerializedName("identificationId") val identificationId: String = "b49a522b2b124d16b70285e8b990e8d4",
//    @SerializedName("faceAuthenticationId") val faceAuthenticationId: String = "3fa85f64-5717-4562-b3fc-2c963f66afa6",
//    @SerializedName("accessCode") val accessCode: String = "3fa85f64-5717-4562-b3fc-2c963f66afa6",
)