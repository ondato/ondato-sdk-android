package com.ondato.sdk.ui.interrupted

import android.os.Bundle
import android.view.View
import com.ondato.sdk.R
import com.ondato.sdk.ui.base.BaseFragment
import com.ondato.sdk.ui.base.BaseViewModel
import com.ondato.sdk.ui.base.event
import com.ondato.sdk.ui.base.set
import com.ondato.sdk.ui.main.Failure
import com.ondato.sdk.ui.main.MainViewModel
import org.koin.androidx.viewmodel.ext.android.sharedViewModel
import org.koin.androidx.viewmodel.ext.android.viewModel

internal class InterruptedFragment: BaseFragment (
    layoutId = R.layout.ondato_fragment_identification_result
) {

    private val viewModel by viewModel<InterruptedViewModel>()
    private val mainViewModel by sharedViewModel<MainViewModel>()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupView()

        viewModel.event.observe {
            when (it) {
                is InterruptedViewModel.Event.TryAgain -> {
                    mainViewModel.onStepFailed(Failure.IdentificationFailure(tryAgain = true))
                }
                is InterruptedViewModel.Event.Close -> {
                    mainViewModel.onStepFailed(Failure.IdentificationFailure(tryAgain = false))
                }
            }
        }
    }

    private fun setupView() {
        R.id.ondatoWaitingPageResultIcon.src(R.drawable.ondato_ic_interrupted)

        R.id.ondatoWaitingPageResultTitle.text(R.string.ondato_interrupted_title)
        R.id.ondatoWaitingPageResultBody.text(R.string.ondato_interrupted_description)

        R.id.ondatoWaitingPageResultButton.text(R.string.ondato_try_again)
        R.id.ondatoWaitingPageResultButton.onClick { viewModel.onButtonClick() }

        R.id.ondatoWaitingPageCloseButton.hide()
    }
}