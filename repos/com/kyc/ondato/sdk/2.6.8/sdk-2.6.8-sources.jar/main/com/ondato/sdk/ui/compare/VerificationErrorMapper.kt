package com.ondato.sdk.ui.compare

import com.ondato.sdk.ui.compare.VerificationError.*
import com.ondato.sdk.usecase.verify.Verification

internal object VerificationErrorMapper {

    fun map(verification: Verification): List<VerificationError> {
        return listOfNotNull(
            verification.isFaceInSelfie.nullOrFailed(PersonPhotoContainsFace),
            verification.isFaceInDocument.nullOrFailed(DocContainsFace),
            verification.isFaceMatching.nullOrFailed(PersonAndDocPhotoMatch),
            verification.isOnePerson.nullOrFailed(ContainsMultipleFaces),
            verification.hasBothDocumentSides.nullOrFailed(DocumentContainsBothSides),
            verification.isMrzInDocument.nullOrFailed(DocContainsMrz),
            verification.isDocumentNotExpired.nullOrFailed(DocExpireDateInFuture)
        )
    }

    private fun Boolean.nullOrFailed(error: VerificationError): VerificationError? {
        return if (this) null else error
    }
}