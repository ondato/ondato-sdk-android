package com.ondato.sdk.api

import com.ondato.sdk.api.additionaldocument.AdditionalDocumentBody
import com.ondato.sdk.api.document.DocumentBody
import com.ondato.sdk.api.facetec.ActiveLivenessCheckBody
import com.ondato.sdk.api.facetec.PassiveLivenessCheckBody
import com.ondato.sdk.api.identification.IdentificationResponse
import com.ondato.sdk.api.liveness.LivenessProductionKeyResponse
import com.ondato.sdk.api.liveness.LivenessUserAgentResponse
import com.ondato.sdk.api.logs.LogRequest
import com.ondato.sdk.api.nfc.NFCUploadRequestV2
import com.ondato.sdk.api.recorder.RecordingBody
import com.ondato.sdk.api.registration.RegistrationRequest
import com.ondato.sdk.api.session.*
import com.ondato.sdk.api.token.FullAccessTokenBody
import com.ondato.sdk.api.token.TokenResponseV2
import retrofit2.Response
import retrofit2.http.*

internal interface BackendApi {

    @POST("/v1/sessions")
    suspend fun getAccessToken(@Body body: SessionSetupBody): TokenResponseV2

    @POST("/v1/sessions/{identityVerificationId}/full-access-token")
    suspend fun getFullAccessToken(
        @Path("identityVerificationId") identityVerificationId: String,
        @Body body: FullAccessTokenBody,
    ): TokenResponseV2

    @GET("/v1/identity-verifications/{id}/setup")
    suspend fun getSetup(
        @Path("id") identityVerificationId: String,
    ): SessionSetupResponse

    @PUT("/v1/identity-verifications/{id}/customer-audits")
    suspend fun sendDeviceInfo(
        @Path("id") identityVerificationId: String,
        @Body body: DeviceInfoBodyV2,
    ): Response<Unit>

    @Headers("Content-Type: application/json-patch+json")
    @PATCH("/v1/identity-verifications/{id}")
    suspend fun sendRegistration(
        @Path("id") identityVerificationId: String,
        @Body body: List<RegistrationRequest>,
    ): Response<Unit>

    @POST("/v1/kyc-identifications")
    suspend fun getKYCId(@Body body: KYCIdentificationBody): KycIdentificationResponse

    @GET("/v1/kyc-identifications/{id}/setup")
    suspend fun getConfig(@Path("id") kycId: String): ApiConfigResponse

    @GET("/v1/identity-verifications/{id}")
    suspend fun getFaceAuthConfig(@Path("id") faceAuthId: String): ApiFaceAuthStatusResponse

    @PUT("/v1/kyc-identifications/{id}/additional-document")
    suspend fun sendAdditionalDocument(
        @Path("id") identityVerificationId: String,
        @Body body: AdditionalDocumentBody,
    ): Response<Unit>

    @PUT("/v1/kyc-identifications/{id}/document")
    suspend fun sendDocument(
        @Path("id") identityVerificationId: String,
        @Body body: DocumentBody,
    ): Response<Unit>

    @PUT("/v1/kyc-identifications/{id}/face-tec-liveness-2d")
    suspend fun sendPassiveLivenessCheck(
        @Path("id") kycId: String,
        @Body body: PassiveLivenessCheckBody,
    ): Response<Unit>

    @GET("/v1/face-tec/mobile-license")
    suspend fun getLivenessLicenseInfo(): LivenessProductionKeyResponse

    @GET("/v1/face-tec/sessions")
    suspend fun getLivenessToken(): LivenessUserAgentResponse

    @PUT("/v1/kyc-identifications/{id}/complete")
    suspend fun completeKYCIdentification(@Path("id") identityVerificationId: String): Response<Unit>

    @PUT("/v1/identity-verifications/{id}/complete")
    suspend fun completeIdentification(@Path("id") identificationId: String): Response<Unit>

    @PUT("/v1/identity-verifications/{id}/abort")
    suspend fun abortIdentification(@Path("id") identificationId: String): Response<Unit>

    @POST("/v1/identity-verifications/{id}/activity-logs")
    suspend fun sendLogs(
        @Path("id") identificationId: String,
        @Body logs: LogRequest
    ): Response<Unit>

    @PUT("/v1/kyc-identifications/{id}/verification")
    suspend fun verification(@Path("id") kycId: String): Response<Unit>

    @PUT("/v1/kyc-identifications/{id}/face-tec-enrollment-3d")
    suspend fun sendActiveLivenessPhoto(
        @Path("id") kycId: String,
        @Body body: ActiveLivenessCheckBody,
    ): Response<Unit>

    @PUT("/v1/face-authentications/{id}/authenticate")
    suspend fun sendFaceAuthPhoto(
        @Path("id") kycId: String,
        @Body body: ActiveLivenessCheckBody,
    ): Response<Unit>

    @GET("/v1/kyc-identifications/{id}")
    suspend fun getIdentificationData(
        @Path("id") kycId: String
    ): IdentificationResponse

    @PUT("/v1/kyc-identifications/{id}/resubmit")
    suspend fun retryIdentification(@Path("id") kycId: String): Response<Unit>

    @PUT("/v1/kyc-identifications/{id}/nfc")
    suspend fun sendNFCPersonalDetails(
        @Path("id") kycId: String,
        @Body body: NFCUploadRequestV2,
    ): Response<Unit>

    @PUT("/v1/kyc-identifications/{id}/session-screen-recording")
    suspend fun sendRecording(
        @Path("id") kycId: String,
        @Body body: RecordingBody,
    ): Response<Unit>
}