package com.ondato.sdk.usecase.liveness

import com.ondato.sdk.utils.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.coroutines.CoroutineContext

internal class Decoder(
    private val base64: Base64 = Base64,
    private val context: CoroutineContext = Dispatchers.IO
) {
    suspend fun decode(photo: String): ByteArray = withContext(context) {
        base64.decode(photo)
    }
}