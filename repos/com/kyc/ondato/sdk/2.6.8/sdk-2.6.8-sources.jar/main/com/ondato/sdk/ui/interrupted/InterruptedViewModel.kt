package com.ondato.sdk.ui.interrupted

import com.ondato.sdk.ui.base.BaseViewModel
import com.ondato.sdk.ui.base.event
import com.ondato.sdk.ui.base.set

internal class InterruptedViewModel(): BaseViewModel() {
    val event by event<Event>()

    fun onButtonClick() {
        event.set(Event.TryAgain)
    }

    sealed class Event {
        object TryAgain: Event()
        object Close: Event()
    }
}