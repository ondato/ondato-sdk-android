package com.ondato.sdk.usecase.deviceinfo

internal data class DeviceInfo(
    val model: String,
    val os: String,
    val installationId: String,
    val sdkVersion: String
)