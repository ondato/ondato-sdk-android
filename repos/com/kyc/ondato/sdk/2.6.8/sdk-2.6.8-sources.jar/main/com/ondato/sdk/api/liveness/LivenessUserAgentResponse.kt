package com.ondato.sdk.api.liveness

import com.google.gson.annotations.SerializedName

internal data class LivenessUserAgentResponse(
    @SerializedName("sessionToken") val sessionToken: String? = null,
)