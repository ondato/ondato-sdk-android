package com.ondato.sdk.storage.file

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.ByteArrayOutputStream

class Compressor {

    fun compress(frame: ByteArray): ByteArray {
        val out = ByteArrayOutputStream()
        val bitmap = BitmapFactory.decodeByteArray(frame, 0, frame.size)
        bitmap.compress(Bitmap.CompressFormat.PNG, 50, out)
        bitmap.recycle()
        return out.toByteArray()
    }

    companion object {
        private const val DEFAULT_WIDTH = 420
    }
}