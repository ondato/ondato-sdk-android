package com.ondato.sdk.ui.start

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.ondato.sdk.R
import com.ondato.sdk.enums.Language

internal class LanguageViewHolder(
    view: View,
    private val languageMapper: LanguageMapper = LanguageMapper
) : RecyclerView.ViewHolder(view) {

    fun bind(languages: Language, listener: (Language) -> Unit) {
        itemView.setOnClickListener { listener(languages) }
        itemView.findViewById<TextView>(R.id.ondatoLanguageTextView)
            ?.setText(languageMapper.map(languages))
    }

    companion object {
        fun inflate(parent: ViewGroup): LanguageViewHolder {
            val inflater = LayoutInflater.from(parent.context)
            val view = inflater.inflate(R.layout.ondato_item_language, parent, false)
            return LanguageViewHolder(view)
        }
    }
}