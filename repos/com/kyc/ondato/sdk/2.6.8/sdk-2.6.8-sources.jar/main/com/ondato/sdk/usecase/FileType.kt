package com.ondato.sdk.usecase

internal enum class FileType(val type: String) {
    Pdf("Pdf")
}